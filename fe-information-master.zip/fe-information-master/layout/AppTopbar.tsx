/* eslint-disable @next/next/no-img-element */

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Avatar } from 'primereact/avatar';
import { Menu } from 'primereact/menu';
import { MenuItem } from 'primereact/menuitem';
import { Toast } from 'primereact/toast';
import { classNames } from 'primereact/utils';
import React, { forwardRef, useContext, useImperativeHandle, useRef } from 'react';
import { AppTopbarRef } from '../types/types';
import { useAuth } from './context/AuthContext';
import { LayoutContext } from './context/layoutcontext';
import { appName } from '../app/constants/constants';

const AppTopbar = forwardRef<AppTopbarRef>((props, ref) => {
    const { layoutConfig, layoutState, onMenuToggle, showProfileSidebar } = useContext(LayoutContext);
    const menubuttonRef = useRef(null);
    const topbarmenuRef = useRef(null);
    const topbarmenubuttonRef = useRef(null);
    const menuRight = useRef<Menu>(null);
    const { logout } = useAuth();
    const toast = useRef<Toast>(null);
    const { user } = useAuth();
    const router = useRouter();

    useImperativeHandle(ref, () => ({
        menubutton: menubuttonRef.current,
        topbarmenu: topbarmenuRef.current,
        topbarmenubutton: topbarmenubuttonRef.current
    }));

    const handleLogout = () => {
        logout({ severity: 'success', summary: 'Success', detail: 'Logout Success', life: 10000 });
    };

    let items: MenuItem[] = [
        { separator: true },
        {
            command: () => {
                toast.current?.show({ severity: 'info', summary: 'Info', detail: 'Logout', life: 3000 });
            },
            template: (item: any, options: { onClick: (arg0: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void; className: any }) => {
                return (
                    <button onClick={handleLogout} className={classNames(options.className, 'w-full p-link flex align-items-center p-2 pl-4 text-color hover:surface-200 border-noround')}>
                        <Avatar image={user?.image} className="mr-2" shape="circle" />
                        <div className="flex flex-column align">
                            <span className="font-bold">Logout</span>
                            <span className="text-sm">{user?.name}</span>
                        </div>
                    </button>
                );
            }
        }
    ];

    return (
        <>
            {user ? (
                <div className="layout-topbar">
                    <Toast ref={toast}></Toast>

                    <Link href="/" className="layout-topbar-logo">
                        <img src={`/layout/images/logo-${layoutConfig.colorScheme !== 'light' ? 'white' : 'dark'}.png`} width="80" height={'100%'} alt="logo" />
                        {/* <span><b className=''>hi</b>bank</span> */}
                    </Link>
                    <button ref={menubuttonRef} type="button" className="p-link layout-topbar-button" onClick={onMenuToggle}>
                        <i className="pi pi-bars" />
                    </button>

                    <button ref={topbarmenubuttonRef} type="button" className="p-link layout-topbar-menu-button layout-topbar-button" onClick={(e) => menuRight.current?.toggle(e)}>
                        <i className="pi pi-user" />
                    </button>

                    <span className="font-bold text-lg text-gray-500">{appName}</span>

                    <Menu model={items} popup ref={menuRight} id="popup_menu_right" popupAlignment="right" />
                    <Avatar
                        image={user.image}
                        size="large"
                        shape="circle"
                        label=""
                        ref={topbarmenubuttonRef}
                        className={classNames('layout-topbar-menu', { 'layout-topbar-menu-mobile-active': layoutState.profileSidebarVisible })}
                        onClick={(e) => menuRight.current?.toggle(e)}
                        aria-controls="popup_menu_right"
                        aria-haspopup
                    />
                </div>
            ) : null}
        </>
    );
});

AppTopbar.displayName = 'AppTopbar';

export default AppTopbar;
