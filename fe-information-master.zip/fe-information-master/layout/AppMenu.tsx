/* eslint-disable @next/next/no-img-element */

import { Button } from 'primereact/button';
import { useMountEffect } from 'primereact/hooks';
import { Skeleton } from 'primereact/skeleton';
import { Toast } from 'primereact/toast';
import { useEffect, useRef, useState } from 'react';
import { appName } from '../app/constants/constants';
import { UserService } from '../app/services/UserService';
import { AppMenuItem } from '../types/types';
import AppMenuitem from './AppMenuitem';
import { useAuth } from './context/AuthContext';
import { MenuProvider } from './context/menucontext';

const AppMenu = () => {
    const [menuItems, setMenuItems] = useState<AppMenuItem[] | undefined>([]);
    const [isRefresh, setIsRefresh] = useState<boolean>(false);
    const { user } = useAuth();
    const toast = useRef<Toast>(null);

    function getMenu() {
        setIsRefresh(true);
        UserService.userHasMenus(user?.email!, user?.token!)
            .then(async (res) => {
                const data = (await res.json()) as unknown as AppMenuItem[];
                if (res.ok) {
                    const model = [{ label: appName, items: data }];
                    setMenuItems(model);
                } else {
                    toast.current?.clear();
                    //@ts-ignore
                    toast.current?.show({ severity: 'error', summary: 'error', detail: res.message, life: 3000 });
                }
            })
            .catch((ex) => {
                toast.current?.show({ severity: 'error', summary: 'error', detail: ex.message, life: 3000 });
            })
            .finally(() => {
                setIsRefresh(false);
            });
    }

    useMountEffect(() => {
        getMenu();
    });

    useEffect(() => {
        if (isRefresh || !menuItems) {
            setMenuItems([]);
            getMenu();
        }
    }, [isRefresh]);

    return (
        <>
            <Toast ref={toast} />
            {menuItems ? (
                <MenuProvider>
                    <ul className="layout-menu">
                        <div className="flex justify-content-between">
                            <div></div>
                            <Button id="btn-refresh-menu" icon="pi pi-refresh" severity="info" tooltip="Refresh Menu" text onClick={(e) => setIsRefresh(true)} />
                        </div>
                        <div className="col-12" hidden={!isRefresh}>
                            <Skeleton className="mb-2" borderRadius="16px"></Skeleton>
                            <Skeleton width="10rem" className="mb-2" borderRadius="16px"></Skeleton>
                            <Skeleton width="5rem" borderRadius="16px" className="mb-2"></Skeleton>
                            <Skeleton height="2rem" className="mb-2" borderRadius="16px"></Skeleton>
                            <Skeleton className="mb-2" borderRadius="16px"></Skeleton>
                            <Skeleton width="10rem" className="mb-2" borderRadius="16px"></Skeleton>
                            <Skeleton width="10rem" className="mb-2" borderRadius="16px"></Skeleton>
                            <Skeleton width="5rem" borderRadius="16px" className="mb-2"></Skeleton>
                            <Skeleton height="2rem" className="mb-2" borderRadius="16px"></Skeleton>
                            <Skeleton className="mb-2" borderRadius="16px"></Skeleton>
                            <Skeleton width="10rem" className="mb-2" borderRadius="16px"></Skeleton>
                            <Skeleton width="5rem" borderRadius="16px" className="mb-2"></Skeleton>
                            <Skeleton height="2rem" className="mb-2" borderRadius="16px"></Skeleton>
                        </div>
                        {menuItems?.map((item, i) => {
                            return !item?.seperator ? <AppMenuitem item={item} root={true} index={i} key={item.label} /> : <li className="menu-separator"></li>;
                        })}
                    </ul>
                </MenuProvider>
            ) : null}
        </>
    );
};

export default AppMenu;
