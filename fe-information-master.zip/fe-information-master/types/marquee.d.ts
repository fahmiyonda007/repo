import { Menu } from "primereact/menu";
import { JsonResponse, MetaModel } from "./metamodel";

export interface Marquee extends JsonResponse {
    id: number;
   text: string;
   rowInfo?: MetaModel;
};