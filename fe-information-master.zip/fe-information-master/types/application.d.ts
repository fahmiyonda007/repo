import { Menu } from "primereact/menu";
import { JsonResponse, MetaModel } from "./metamodel";

export interface Application extends JsonResponse {
    id: number;
    applicationName: string;
    applicationCode: string;
    url?: string;
    description?: string;
    rowInfo?: MetaModel;
};

export interface ApplicationHasMenu {
    application: Application;
    menu: Menu[];
};