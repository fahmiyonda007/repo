import { JsonResponse, MetaModel } from "./metamodel";

export interface VideoImage extends JsonResponse {
    id: number;
    type: string;
    typeOptions?: {
        id: number;
        name: string;
        format: string;
    };
    description: string;
    filename: string;
    file: string;
    rowInfo?: MetaModel;
};