import React from 'react';
import { Button } from 'primereact/button';

export const deleteItemDialogFooter = (hideDeleteItemDialog: React.MouseEventHandler<HTMLButtonElement> | undefined, deleteItem: React.MouseEventHandler<HTMLButtonElement> | undefined) => (
    <React.Fragment>
        <Button label="No" icon="pi pi-times" outlined onClick={hideDeleteItemDialog} />
        <Button label="Yes" icon="pi pi-check" severity="danger" onClick={deleteItem} />
    </React.Fragment>
);

export const deleteItemsDialogFooter = (hideDeleteItemsDialog: React.MouseEventHandler<HTMLButtonElement> | undefined, deleteSelectedItems: React.MouseEventHandler<HTMLButtonElement> | undefined) => (
    <React.Fragment>
        <Button label="No" icon="pi pi-times" outlined onClick={hideDeleteItemsDialog} />
        <Button label="Yes" icon="pi pi-check" severity="danger" onClick={deleteSelectedItems} />
    </React.Fragment>
);
