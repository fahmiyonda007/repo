import { Dialog, DialogProps } from 'primereact/dialog';
import { ReactElement, JSXElementConstructor, ReactNode, ReactPortal, PromiseLikeOfReactNode } from 'react';

interface metaProps {
    deleteItemDialog: boolean | undefined;
    deleteItemDialogFooter: string | number | boolean | ReactElement<any, string | JSXElementConstructor<any>> | Iterable<ReactNode> | ReactPortal | PromiseLikeOfReactNode | ((props: DialogProps) => ReactNode) | null | undefined;
    hideDeleteItemDialog: () => void;
    item: any;
    name: string | number | boolean | ReactElement<any, string | JSXElementConstructor<any>> | Iterable<ReactNode> | ReactPortal | PromiseLikeOfReactNode | null | undefined;
}

const DeleteDialog = (props: metaProps) => {
    return (
        <Dialog visible={props.deleteItemDialog} style={{ width: '32rem' }} breakpoints={{ '960px': '75vw', '641px': '90vw' }} header="Confirm" modal footer={props.deleteItemDialogFooter} onHide={props.hideDeleteItemDialog}>
            <div className="confirmation-content">
                <i className="pi pi-exclamation-triangle mr-3" style={{ fontSize: '2rem' }} />
                {props.item && (
                    <span>
                        Are you sure you want to delete <b>{props.name}</b>?
                    </span>
                )}
            </div>
        </Dialog>
    );
};

export default DeleteDialog;
