import React from 'react';
import { Calendar } from 'primereact/calendar';
import { classNames } from 'primereact/utils';
import { Nullable } from 'primereact/ts-helpers';

interface metaProps {
    inputId: string | undefined;
    name: string | undefined;
    label: string | number | boolean | React.ReactElement<any, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode> | React.ReactPortal | React.PromiseLikeOfReactNode | null | undefined;
    formik: { values: { date: string | Date | Date[] | null | undefined }; setFieldValue: (arg0: any, arg1: Nullable<string | Date | Date[]>) => void };
    isFormFieldInvalid: (arg0: any) => any;
    getFormErrorMessage: (arg0: any) => any;
}
export default function FormikDoc(props: metaProps) {
    return (
        <>
            <label htmlFor={props.inputId}>{props.label}</label>
            <Calendar
                inputId={props.inputId}
                name={props.name}
                value={props.formik.values.date}
                className={classNames({ 'p-invalid': props.isFormFieldInvalid(props.name) })}
                onChange={(e) => {
                    props.formik.setFieldValue(props.name, e.target.value);
                }}
                dateFormat="DD dd M, yy"
                showIcon
                readOnlyInput
                showButtonBar
            />
            {props.getFormErrorMessage(props.name)}
        </>
    );
}
