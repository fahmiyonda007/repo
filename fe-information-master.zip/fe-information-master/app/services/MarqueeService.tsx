import { Marquee } from '../../types/marquee';
import { JsonRequest } from '../../types/metamodel';
import { apiUrl } from '../constants/constants';
import { informationApi } from '../constants/constants';

interface MetaPage {
    limit?: number;
    skip?: number;
    search?: string;
}

export const MarqueeService = {
    async getMarqueText(prop: MetaPage, req: JsonRequest) {
        const res = await fetch(`${informationApi}v1/marquee?search=${prop.search}&limit=${prop.limit}&skip=${prop.skip}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Request-Path': req.requestPath,
                'Cache-Control': 'no-cache',
                'Content-Type': 'application/json'
            }
        });
        return res;
    },

    async addMarqueText(form: Marquee, req: JsonRequest) {
        const res = await fetch(`${informationApi}v1/marquee`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Request-Path': req.requestPath,
                'Content-Type': 'application/json;charset=utf-8'
            },
            body: JSON.stringify(form)
        });
        return res;
    },

    async updateMarqueText(id: number, prop: Marquee, req: JsonRequest) {
        const res = await fetch(`${informationApi}v1/marquee`, {
            method: 'PUT',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Request-Path': req.requestPath,
                'Content-Type': 'application/json;charset=utf-8'
            },
            body: JSON.stringify(prop)
        });
        return res;
    }
};
