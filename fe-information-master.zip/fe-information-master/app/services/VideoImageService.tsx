import { JsonRequest } from '../../types/metamodel';
import { VideoImage } from '../../types/video-image';
import { apiUrl } from '../constants/constants';
import { informationApi } from '../constants/constants';

interface MetaPage {
    limit?: number;
    skip?: number;
    search?: string;
}

export const VideoImageService = {
    async getVideoImages(prop: MetaPage, req: JsonRequest) {
        const res = await fetch(`${informationApi}v1/videoimages?search=${prop.search}&limit=${prop.limit}&skip=${prop.skip}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Request-Path': req.requestPath,
                'Content-Type': 'application/json',
                'Cache-Control': 'no-cache'
            }
        });
        const data = await res.json();
        return data as VideoImage[];
    },

    async getVideoImage(id: any, req: JsonRequest ) {
        const res = await fetch(`${apiUrl}v1/videoimages/${id}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Request-Path': req.requestPath,
                'Content-Type': 'application/json',
                'Cache-Control': 'no-cache'
            }
        });
        return res;
    },

    async addVideoImage(form: VideoImage, req: JsonRequest) {
        const res = await fetch(`${informationApi}v1/videoimages`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Request-Path': req.requestPath,
                'Content-Type': 'application/json;charset=utf-8'
            },
            body: JSON.stringify(form)
        });
        return res;
    },

    async deleteVideoImage(id: number, req: JsonRequest) {
        const res = await fetch(`${informationApi}v1/videoimages/${id}`, {
            method: 'DELETE',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Request-Path': req.requestPath,
                'Content-Type': 'application/json'
            }
        });
        const data = await res.json();
        return data as VideoImage;
    }
};
