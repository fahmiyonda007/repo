import { AppMenuItem } from '../../types/layout';
import { apiUrl, appName } from '../constants/constants';

export const UserService = {
    async userHasMenus(email: string, token: string) {
        const res = await fetch(`${apiUrl}users/menus`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email: email, application: appName })
        });
        return res;
    }
};
