'use client';
import Cookies from 'js-cookie';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { Button } from 'primereact/button';
import { useMountEffect } from 'primereact/hooks';
import { Messages } from 'primereact/messages';
import { Toast } from 'primereact/toast';
import { classNames } from 'primereact/utils';
import React, { useContext, useEffect, useRef, useState } from 'react';
import { useAuth } from '../../../layout/context/AuthContext';
import { LayoutContext } from '../../../layout/context/layoutcontext';
import { apiUrl, appUrl } from '../../constants/constants';

const LoginPage: React.FC = () => {
    const msgs = useRef<Messages>(null);
    const { layoutConfig } = useContext(LayoutContext);
    const [token, setToken] = useState<string | null>('');
    const toast = useRef<Toast>(null);
    const { user, loginGoogle } = useAuth();
    const router = useRouter();
    const containerClassName = classNames('surface-ground flex align-items-center justify-content-center min-h-screen min-w-screen overflow-hidden', { 'p-input-filled': layoutConfig.inputStyle === 'filled' });

    const searchParams = useSearchParams();

    useEffect(() => {
        if (!user?.email) {
            if (searchParams.get('redirectUrl')) {
                Cookies.set('redirect-url', searchParams.get('redirectUrl')!, { secure: true, path: '/' });
            }

            setToken(searchParams.get('token'));
            if (token) {
                loginGoogle(token!);
            }
        } else {
            if (Cookies.get('redirect-url')) {
                router.push(Cookies.get('redirect-url')!);
            }
        }
    }, [loginGoogle, router, searchParams, token, user]);

    useMountEffect(() => {
        if (user?.email) {
            router.back();
        }
    });

    return (
        <>
            {!user?.email && !token ? (
                <div className={containerClassName}>
                    <Toast ref={toast}></Toast>
                    <Messages ref={msgs} />
                    <div className="flex flex-column align-items-center justify-content-center">
                        <div
                            style={{
                                borderRadius: '56px',
                                padding: '0.3rem',
                                background: 'linear-gradient(180deg, #006A81 10%, rgba(33, 150, 243, 0) 30%)'
                            }}
                        >
                            <div className="w-full surface-card py-5 px-5 sm:px-8" style={{ borderRadius: '53px' }}>
                                <div className="flex justify-content-between align-items-center mb-5">
                                    <img src={`/layout/images/BNI.png`} alt="BNI Logo" className="w-4rem" height={'50%'} style={{ margin: '0 0 0 -3rem' }} />
                                    <img src={`/layout/images/bumn-3.png`} alt="BUMN Logo" className="w-7rem" style={{ margin: '0 -3rem 0 0' }} />
                                </div>
                                <div className="text-center">
                                    <img src={`/layout/images/logo-${layoutConfig.colorScheme === 'light' ? 'dark' : 'white'}.png`} alt="Logo" className="mb-5 w-30rem flex-shrink-0" />
                                </div>
                                <div className="flex justify-content-center">
                                    <Link href={`${apiUrl}auth/login?callback=${appUrl}/auth/login`} className="w-full">
                                        <Button className="bg-gray-100 hover:bg-primary-100 border-gray-700 text-teal-900 justify-content-center align-items-center w-full">
                                            <img
                                                alt="logo"
                                                src="https://fonts.gstatic.com/s/i/productlogos/googleg/v6/24px.svg
"
                                            ></img>
                                            <span> &nbsp; Sign In with Google</span>
                                        </Button>
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            ) : (
                <div className="surface-ground flex align-items-center justify-content-center min-h-screen min-w-screen overflow-hidden">
                    <div className="flex flex-column align-items-center justify-content-center">
                        <img src={`/layout/images/logo-${layoutConfig.colorScheme === 'light' ? 'dark' : 'white'}.png`} alt="Logo" className="mb-3 w-16rem flex-shrink-0" />
                        <div
                            style={{
                                borderRadius: '56px',
                                padding: '0.3rem',
                                background: 'linear-gradient(180deg, rgba(247, 149, 48, 0.4) 10%, rgba(247, 149, 48, 0) 30%)'
                            }}
                        >
                            <div className="w-full surface-card py-8 px-5 sm:px-8 flex flex-column align-items-center" style={{ borderRadius: '53px' }}>
                                <div className="flex justify-content-center align-items-center bg-pink-500 border-circle" style={{ height: '3.2rem', width: '3.2rem' }}>
                                    <i className="pi pi-fw pi-exclamation-circle text-2xl text-white"></i>
                                </div>
                                <h1 className="text-900 font-bold text-5xl mb-2">Access Already Granted</h1>
                                <div className="text-600 mb-5">You can use this application now.</div>
                                <Button icon="pi pi-arrow-left" label="Go to Dashboard" text onClick={() => router.push('/')} />
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
};

export default LoginPage;
