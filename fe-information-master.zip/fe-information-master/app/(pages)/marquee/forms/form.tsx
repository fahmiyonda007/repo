import { format } from 'date-fns';
import { useFormik } from 'formik';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { Button } from 'primereact/button';
import { Chip } from 'primereact/chip';
import { Fieldset } from 'primereact/fieldset';
import { Message } from 'primereact/message';
import { Toast } from 'primereact/toast';
import { classNames } from 'primereact/utils';
import React, { useContext, useEffect, useRef, useState } from 'react';
import { useAuth } from '../../../../layout/context/AuthContext';
import { LayoutContext } from '../../../../layout/context/layoutcontext';
import { Marquee } from '../../../../types/marquee';
import PrivateRoute from '../../../components/PrivateRoute';
import { MarqueeService } from '../../../services/MarqueeService';
import { MarqueeSchema } from './validation';
import { InputTextarea } from 'primereact/inputtextarea';
import { useMountEffect } from 'primereact/hooks';
import { request } from 'http';

const MarqueeFormPage = () => {
    const toast = useRef<Toast>(null);
    const [btnLoading, setBtnLoading] = useState(false);
    const { setMessage } = useContext(LayoutContext);
    const router = useRouter();
    const { user } = useAuth();
    const [valuetext, setValue] = useState('');
    const [data, setData] = useState<Marquee | null>(null);
    const [isRefresh, setIsRefresh] = useState<boolean>(false)
    const pathName = usePathname();


    const legendTemplate = (
        <div className="flex align-items-center text-primary">
            <span className="pi pi-plus mr-2"></span>
            <span className="font-bold text-lg">Form {!data?.id ? 'Create' : `Edit`}</span>
        </div>
    );

    const formik = useFormik({
        initialValues: {
            id: data?.id || 0,
            text: data?.text || ''
        },
        enableReinitialize: true,
        validationSchema: MarqueeSchema,
        onSubmit: (form: Marquee) => {
            setBtnLoading(true);
            if (!data) {
                MarqueeService.addMarqueText(form, { token: user?.token!, requestPath: pathName })
                    .then(async (res) => {
                        const data = (await res.json()) as unknown as Marquee;
                        if (res.ok) {
                            setIsRefresh(true);
                            toast.current?.show({ severity: 'success', summary: 'Success', detail: data.message });
                        } else {
                            toast.current?.show({ severity: 'error', summary: 'Error', detail: data.message });
                        }
                    })
                    .catch((ex) => {
                        toast.current?.show({ severity: 'error', summary: 'Error', detail: 'Failed!' });
                    })
                    .finally(() => {
                        setBtnLoading(false);
                    });
            } else {
                MarqueeService.updateMarqueText(data?.id, form, { token: user?.token!, requestPath: pathName })
                    .then(async (res) => {
                        const data = (await res.json()) as unknown as Marquee;
                        if (res.ok) {
                            setMessage({
                                sticky: false,
                                life: 5000,
                                severity: 'success',
                                content: (
                                    <React.Fragment>
                                        <i className="pi pi-check"></i>
                                        <div className="ml-2">{`Marquee text has been updated`}</div>
                                    </React.Fragment>
                                ),
                                closable: true
                            });
                            router.push('/marquee');
                        } else {
                            toast.current?.show({ severity: 'error', summary: 'Error', detail: data.message });
                        }
                    })
                    .catch((ex) => {
                        toast.current?.show({ severity: 'error', summary: 'Error', detail: 'Failed!' });
                    })
                    .finally(() => {
                        setBtnLoading(false);
                    });
            }
        }
    });
    const { errors, touched, values, handleChange, handleSubmit } = formik;

    //@ts-ignore
    const isFormFieldInvalid = (name) => !!(touched[name] && errors[name]);

    const getFormErrorMessage = (name: any) => {
        return isFormFieldInvalid(name) ? (
            <>
                {/* @ts-ignore */}
                <Message severity="error" text={errors[name]} className="justify-content-start" />
            </>
        ) : (
            ''
        );
    };

    useEffect(() => {
        MarqueeService.getMarqueText({}, { token: user?.token!, requestPath: pathName })
            .then(async (res) => {
                const resData = (await res.json()) as unknown as Marquee;
                if (res.ok) {
                    setData(
                        //@ts-ignore
                        resData.data[0]
                    );
                } else {
                    toast.current?.show({ severity: 'error', summary: 'error', detail: resData.message, life: 3000 });
                }
            })
            .catch((res) => {
                if (res) {
                    toast.current?.show({ severity: 'error', summary: 'error', detail: 'Failed!', life: 3000 });
                }
            })
            .finally(() => {});
    }, [isRefresh, pathName, user?.token]);

    return (
        <PrivateRoute>
            <form onSubmit={handleSubmit}>
                <div className="grid">
                    <Toast ref={toast}></Toast>
                    <div className={classNames(!data ? 'col-12' : 'col-8')}>
                        <Fieldset legend={legendTemplate}>
                            <div className="col-12">
                                <div className="p-fluid formgrid grid">
                                    <span className="p-float-label">
                                        <InputTextarea
                                            id="text"
                                            value={values.text}
                                            onChange={(e) => {
                                                formik.setFieldValue('text', e.target.value);
                                            }}
                                            rows={5}
                                            cols={50}
                                            className={classNames({ 'p-invalid': isFormFieldInvalid('text') })}
                                        />
                                        <label htmlFor="marquee">Marquee Text</label>
                                    </span>
                                </div>
                            </div>
                            <div className="col-12">
                                <div className="p-fluid formgrid grid flex flex-wrap gap-2">
                                    <div className="field">
                                        <Link href={'/'}>
                                            <Button type="button" label="Cancel" icon="pi pi-times" severity="danger" loading={btnLoading} outlined></Button>
                                        </Link>
                                    </div>

                                    <div className="field">
                                        <Button type="submit" label={data?.id ? 'Update' : 'Save'} icon="pi pi-check" severity="info" loading={btnLoading}></Button>
                                    </div>
                                </div>
                            </div>
                        </Fieldset>
                    </div>
                    <div className={classNames('col-4', !data ? 'hidden' : '')}>
                        <Fieldset legend="Information">
                            <div className="card flex flex-wrap gap-2">
                                <Chip label={`Created by: ${data?.rowInfo?.createdBy}`} />
                                <Chip label={`Created at: ${data?.rowInfo?.createdAt?.Time! ? format(new Date(data?.rowInfo?.createdAt?.Time!), 'dd-MM-yyyy') : null}`} />
                                <Chip label={`Updated by: ${data?.rowInfo?.updatedBy}`} />
                                <Chip label={`Updated at: ${data?.rowInfo?.updatedAt?.Time! ? format(new Date(data?.rowInfo?.updatedAt?.Time!), 'dd-MM-yyyy') : null}`} />
                            </div>
                        </Fieldset>
                    </div>
                </div>
            </form>
        </PrivateRoute>
    );
};

export default MarqueeFormPage;
