import * as Yup from 'yup';

export const MarqueeSchema = Yup.object().shape({
    text: Yup.string().required('Required!'),
});
