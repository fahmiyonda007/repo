'use client';

import { useMountEffect } from 'primereact/hooks';
import { Messages } from 'primereact/messages';
import { useContext, useRef } from 'react';
import { LayoutContext } from '../../../layout/context/layoutcontext';
import PrivateRoute from '../../components/PrivateRoute';
import MarqueeFormPage from './forms/form';

const MarqueePage = () => {
    const msgs = useRef<Messages>(null);
    const {
        layoutConfig: { message },
        clearMessage
    } = useContext(LayoutContext);

    useMountEffect(() => {
        clearMessage();

        msgs.current?.clear();
        if (message) {
            msgs.current?.show(message);
        }
    });

    return (
        <PrivateRoute>
            <div className="grid">
                <div className="col-12">
                    <Messages ref={msgs} />
                    <div className="card">
                        <MarqueeFormPage />
                    </div>
                </div>
            </div>
        </PrivateRoute>
    );
};

export default MarqueePage;
