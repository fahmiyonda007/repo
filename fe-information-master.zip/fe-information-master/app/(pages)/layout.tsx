import { Metadata, Viewport } from 'next';
import { Suspense } from 'react';
import Layout from '../../layout/layout';
import { appName } from '../constants/constants';

interface AppLayoutProps {
    children: React.ReactNode;
}

export const metadata: Metadata = {
    metadataBase: new URL('https://hibank.co.id'),
    title: appName,
    description: 'The ultimate collection of design-agnostic, flexible and accessible React UI Components.',
    robots: { index: false, follow: false },
    openGraph: {
        type: 'website',
        title: appName,
        url: 'https://hibank.co.id/',
        description: 'The ultimate collection of design-agnostic, flexible and accessible React UI Components.',
        images: ['https://hibank.co.id/_nuxt/img/logo.7a11c80.svg'],
        ttl: 604800
    },
    icons: {
        icon: '/favicon.ico'
    }
};

export const viewport: Viewport = {
    width: 'device-width',
    initialScale: 1,
    maximumScale: 1
};

export default function AppLayout({ children }: AppLayoutProps) {
    return (
        <Layout>
            <Suspense fallback={<p>Loading ...</p>}>{children}</Suspense>
        </Layout>
    );
}
