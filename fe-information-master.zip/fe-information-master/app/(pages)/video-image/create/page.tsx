'use client';

import VideoImageFormPage from '../forms/form';

const VideoImageCreatePage = () => {
    return <VideoImageFormPage />;
};

export default VideoImageCreatePage;
