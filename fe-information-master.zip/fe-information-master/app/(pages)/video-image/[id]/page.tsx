'use client';

import { useRouter } from 'next/navigation';
import { Toast } from 'primereact/toast';
import React, { useContext, useEffect, useRef, useState } from 'react';
import { useAuth } from '../../../../layout/context/AuthContext';
import { LayoutContext } from '../../../../layout/context/layoutcontext';
import { VideoImage } from '../../../../types/video-image';
import FormSkeleteton from '../../../components/form/FormSkeleton';
import { VideoImageService } from '../../../services/VideoImageService';
import VideoImageFormPage from '../forms/form';

export default function Page({ params }: { params: { id: number } }) {
    const { id } = params;
    const toast = useRef<Toast>(null);
    const [data, setData] = useState<VideoImage | undefined>();
    const [msg, setMsg] = useState('');
    const { user } = useAuth();
    const router = useRouter();
    const { setMessage } = useContext(LayoutContext);

    useEffect(() => {
        if (!data) {
            VideoImageService.getVideoImage({ id: id, token: user?.token })
                .then(async (res) => {
                    const data = (await res.json()) as unknown as VideoImage;
                    if (res.ok) {
                        setData(data);
                    } else {
                        setMsg(data.message!);
                    }
                })
                .catch((e) => {
                    if (e) {
                        toast.current?.show({ severity: 'error', summary: 'error', detail: e.message, life: 3000 });
                    }
                });
        }
    }, [data, id, user?.token]);

    if (msg) {
        setMessage({
            sticky: false,
            life: 5000,
            severity: 'error',
            content: (
                <React.Fragment>
                    <i className="pi pi-times"></i>
                    <div className="ml-2">{msg}</div>
                </React.Fragment>
            ),
            closable: true
        });
        router.push('/video-image');
    }

    if (data) {
        return (
            <div>
                <Toast ref={toast}></Toast>
                <VideoImageFormPage data={data} />
            </div>
        );
    }

    return <FormSkeleteton show={true} />;
}
