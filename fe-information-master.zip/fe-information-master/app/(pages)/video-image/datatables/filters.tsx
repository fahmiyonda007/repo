import { FilterMatchMode, FilterOperator } from 'primereact/api';

export const videoImageFilter = {
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    description: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }]
    }
};
