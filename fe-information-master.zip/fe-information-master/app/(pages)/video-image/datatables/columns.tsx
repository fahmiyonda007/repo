import { ColumnProps } from 'primereact/column';
import { VideoImage } from '../../../../types/video-image';
import { rowinfo } from '../../../components/rowinfo';

const columns: ColumnProps[] = [
    {
        field: 'type',
        header: 'Type',
        filterField: 'type',
        filterPlaceholder: 'Search by application type',
        sortable: false,
        filter: false,
        frozen: false,
        showFilterMenu: false,
        body: (rowData: VideoImage) => {
            return <div>{rowData.type}</div>;
        }
    },
    {
        field: 'description',
        header: 'Description',
        filterField: 'description',
        filterPlaceholder: 'Search by description',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'filename',
        header: 'Filename',
        filterField: 'filename',
        filterPlaceholder: 'Search by filename',
        sortable: false,
        filter: false,
        frozen: false
    }
];

export const videoImageColumns = [...columns, ...rowinfo];
