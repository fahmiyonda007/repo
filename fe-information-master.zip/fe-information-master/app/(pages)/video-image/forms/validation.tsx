import * as Yup from 'yup';

export const VideoImageSchema = Yup.object().shape({});
