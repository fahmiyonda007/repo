import { format } from 'date-fns';
import { useFormik } from 'formik';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { Button } from 'primereact/button';
import { Chip } from 'primereact/chip';
import { Dropdown, DropdownChangeEvent } from 'primereact/dropdown';
import { Fieldset } from 'primereact/fieldset';
import { FileUpload, FileUploadHeaderTemplateOptions, FileUploadSelectEvent } from 'primereact/fileupload';
import { InputText } from 'primereact/inputtext';
import { Message } from 'primereact/message';
import { Toast } from 'primereact/toast';
import { classNames } from 'primereact/utils';
import { useContext, useRef, useState } from 'react';
import { useAuth } from '../../../../layout/context/AuthContext';
import { LayoutContext } from '../../../../layout/context/layoutcontext';
import { VideoImage } from '../../../../types/video-image';
import PrivateRoute from '../../../components/PrivateRoute';
import { VideoImageService } from '../../../services/VideoImageService';
import { VideoImageSchema } from './validation';
import React from 'react';

interface metaProps {
    data?: VideoImage;
}

const VideoImageFormPage = (props: metaProps) => {
    const toast = useRef<Toast>(null);
    const { data } = props;
    const [btnLoading, setBtnLoading] = useState(false);
    const { setMessage } = useContext(LayoutContext);
    const router = useRouter();
    const { user } = useAuth();
    const pathName = usePathname();

    const legendTemplate = (
        <div className="flex align-items-center text-primary">
            <span className="pi pi-plus mr-2"></span>
            <span className="font-bold text-lg">Form {!data?.id ? 'Create' : `Edit`}</span>
        </div>
    );

    const formik = useFormik({
        initialValues: {
            id: data?.id || 0,
            type: data?.type || '',
            typeOptions: data?.typeOptions || undefined,
            description: data?.description || '',
            filename: data?.filename || '',
            file: data?.file || ''
        },
        enableReinitialize: true,
        validationSchema: VideoImageSchema,
        onSubmit: (form: VideoImage) => {
            setBtnLoading(true);
            if (!data) {
                VideoImageService.addVideoImage(form, { token: user?.token!, requestPath: pathName })
                    .then(async (res) => {
                        const data = (await res.json()) as unknown as VideoImage;
                        if (res.ok) {
                            setMessage({
                                sticky: false,
                                life: 5000,
                                severity: 'success',
                                content: (
                                    <React.Fragment>
                                        <i className="pi pi-check"></i>
                                        <div className="ml-2">{`Video Images ${data.description} has been created`}</div>
                                    </React.Fragment>
                                ),
                                closable: true
                            });                            router.push('/video-image');
                        } else {
                            toast.current?.show({ severity: 'error', summary: 'Error', detail: data.message });
                        }
                    })
                    .catch((ex) => {
                        toast.current?.show({ severity: 'error', summary: 'Error', detail: 'Failed!' });
                    })
                    .finally(() => {
                        setBtnLoading(false);
                    });
            }
        }
    });
    const { errors, touched, values, handleChange, handleSubmit } = formik;

    //@ts-ignore
    const isFormFieldInvalid = (name) => !!(touched[name] && errors[name]);

    const getFormErrorMessage = (name: any) => {
        return isFormFieldInvalid(name) ? (
            <>
                {/* @ts-ignore */}
                <Message severity="error" text={errors[name]} className="justify-content-start" />
            </>
        ) : (
            ''
        );
    };

    const headerTemplate = (options: FileUploadHeaderTemplateOptions) => {
        const { className, chooseButton, uploadButton, cancelButton } = options;
        return (
            <>
                <div className={className} style={{ backgroundColor: 'transparent', display: 'flex', alignItems: 'center' }}>
                    {chooseButton}
                    {cancelButton}
                </div>
            </>
        );
    };

    const uploadHandler = (files: FileUploadSelectEvent) => {
        const file = files.files[0];
        formik.setFieldValue('filename', files.files[0].name);

        const filereader = new FileReader();
        filereader.onload = (e) => {
            formik.setFieldValue('file', e.target?.result);
        };
        filereader.readAsDataURL(file);
    };

    return (
        <PrivateRoute>
            <form onSubmit={handleSubmit}>
                <div className="grid">
                    <Toast ref={toast}></Toast>
                    <div className={classNames(!data ? 'col-12' : 'col-8')}>
                        <Fieldset legend={legendTemplate}>
                            <div className="col-12">
                                <div className="p-fluid formgrid grid">
                                    <div className="field col-12 md:col-6">
                                        <label htmlFor="type">Type</label>
                                        <Dropdown
                                            value={values.typeOptions}
                                            onChange={(e: DropdownChangeEvent) => {
                                                formik.setFieldValue('typeOptions', e.value);
                                                formik.setFieldValue('type', e.value != undefined ? e.value.name : '');
                                            }}
                                            options={[
                                                {
                                                    id: 1,
                                                    name: 'Video',
                                                    format: '.mp4,.wmv'
                                                },
                                                {
                                                    id: 2,
                                                    name: 'Image',
                                                    format: '.png,.jpg,.jpeg'
                                                },
                                                {
                                                    id: 3,
                                                    name: 'Suku Bunga',
                                                    format: '.png,.jpg,.jpeg'
                                                }
                                            ]}
                                            optionLabel="name"
                                            placeholder="Select a type"
                                            className={classNames({ 'p-invalid': isFormFieldInvalid('typeOptions') })}
                                            virtualScrollerOptions={{ itemSize: 38 }}
                                            filter
                                            showClear
                                        />
                                    </div>
                                    <div className="field col-12 md:col-6">
                                        <label htmlFor="description">Description</label>
                                        <InputText id="description" type="text" value={values.description} onChange={handleChange} className={classNames({ 'p-invalid': isFormFieldInvalid('description') })} />
                                        {getFormErrorMessage('description')}
                                    </div>
                                    <div className="field col-12 md:col-6">
                                        {<label htmlFor="upload">Upload</label>}
                                        <FileUpload
                                            disabled={!values.typeOptions?.format ? true : false}
                                            mode="advanced"
                                            name="uploaddata[]"
                                            accept={values.typeOptions?.format}
                                            customUpload={true}
                                            headerTemplate={headerTemplate}
                                            onSelect={uploadHandler}
                                            maxFileSize={900000000000000}
                                        />
                                        {getFormErrorMessage('upload')}
                                    </div>
                                </div>
                            </div>
                            <div className="col-12">
                                <div className="p-fluid formgrid grid flex flex-wrap gap-2">
                                    <div className="field">
                                        <Link href={'/video-image'}>
                                            <Button type="button" label="Cancel" icon="pi pi-times" severity="danger" loading={btnLoading} outlined></Button>
                                        </Link>
                                    </div>

                                    <div className="field">
                                        <Button type="submit" label={data?.id ? 'Update' : 'Save'} icon="pi pi-check" severity="info" loading={btnLoading}></Button>
                                    </div>
                                </div>
                            </div>
                        </Fieldset>
                    </div>
                    <div className={classNames('col-4', !data ? 'hidden' : '')}>
                        <Fieldset legend="Information">
                            <div className="card flex flex-wrap gap-2">
                                <Chip label={`Created by: ${data?.rowInfo?.createdBy}`} />
                                <Chip label={`Created at: ${data?.rowInfo?.createdAt?.Time! ? format(new Date(data?.rowInfo?.createdAt?.Time!), 'dd-MM-yyyy') : null}`} />
                                <Chip label={`Updated by: ${data?.rowInfo?.updatedBy}`} />
                                <Chip label={`Updated at: ${data?.rowInfo?.updatedAt?.Time! ? format(new Date(data?.rowInfo?.updatedAt?.Time!), 'dd-MM-yyyy') : null}`} />
                            </div>
                        </Fieldset>
                    </div>
                </div>
            </form>
        </PrivateRoute>
    );
};

export default VideoImageFormPage;
