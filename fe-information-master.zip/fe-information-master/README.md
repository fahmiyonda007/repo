<!-- PROJECT LOGO -->
<br />
<p align="center">
  <a href="https://hibank.co.id">
    <img src="public/layout/images/logo-light.png" alt="Logo" width="200" height="100">
  </a>

  <h3 align="center">Internal Apps</h3>

  <p align="center">
    Information - version 1.0.0
  </p>
  <br />
</p>

# [Changelog](http://10.100.2.46:57532/hibank-revamp/fe-starter/-/blob/master/CHANGELOG.md)
# [Sakai Demo](https://sakai.primereact.org/)

This is a [Next.js](https://nextjs.org/) project bootstrapped with [`create-next-app`](https://github.com/vercel/next.js/tree/canary/packages/create-next-app)

## 1. Getting Started

Sakai is an application template for Next.js based on the popular Next.js framework with new App Router. 

1.  First, clone this repo: 

- **ssh**
```bash
 git clone git@10.100.2.46:hibank-revamp/fe-information.git
```
- *or* **http**
```bash
 git clone http://10.100.2.46:57532/hibank-revamp/fe-information.git
```
2. copy `.env.example` to `.env`
   
3. Install depedencies:
```bash
 npm install
``` 
   
4. run the development server: 

*Configuration port and host already in package.json file*

```bash
npm run dev
```

## 2. Extension VsCode
-  [Auto Renam Tag](https://marketplace.visualstudio.com/items?itemName=formulahendry.auto-rename-tag)
-  [Better Comments](https://marketplace.visualstudio.com/items?itemName=aaron-bond.better-comments)
-  [DotENV](https://marketplace.visualstudio.com/items?itemName=mikestead.dotenv)
-  [Error Lens](https://marketplace.visualstudio.com/items?itemName=usernamehw.errorlens)
-  [ESLint](https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint)
-  [ES7+ React/Redux/React-Native snippets](https://marketplace.visualstudio.com/items?itemName=dsznajder.es7-react-js-snippets)
-  [Git Graph](https://marketplace.visualstudio.com/items?itemName=mhutchie.git-graph)
-  [Git History](https://marketplace.visualstudio.com/items?itemName=donjayamanne.githistory)
-  [GitLens — Git supercharged](https://marketplace.visualstudio.com/items?itemName=eamodio.gitlens)
-  [Live Share](https://marketplace.visualstudio.com/items?itemName=MS-vsliveshare.vsliveshare)
-  [Prettier - Code formatter](https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode)
-  [Prettier - JavaScript formatter](https://marketplace.visualstudio.com/items?itemName=bysabi.prettier-vscode-standard)
-  [React Native Tools](https://marketplace.visualstudio.com/items?itemName=msjsdiag.vscode-react-native)
-  [Tailwind CSS Intellisense](https://marketplace.visualstudio.com/items?itemName=bradlc.vscode-tailwindcss)
-  [Turbo Console Log](https://marketplace.visualstudio.com/items?itemName=ChakrounAnas.turbo-console-log)
-  [Typescript React code snippets](https://marketplace.visualstudio.com/items?itemName=infeng.vscode-react-typescript)


<!-- CONTRIBUTING -->
## 3. Contributing

Contributions are what make the open source community such an amazing place to be learn, inspire, and create. Any contributions you make are **greatly appreciated**.

1. Create your Feature Branch (`git checkout -b feature/AmazingFeature`)
2. Commit your Changes (`git commit -m 'Add some AmazingFeature'`)
3. Push to the Branch (`git push origin feature/AmazingFeature`)
4. Open a Pull Request


## 4. Built With

To learn more about this project, take a look at the following resources:

- [Sakai Template](https://sakai.primereact.org/) - Default template next.js + PrimeReact
- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [PrimeReact Component](https://primereact.org/autocomplete/) - Open source UI components for React.
- [PrimeReact Icons](https://primereact.org/icons/) - Default icon library of PrimeReact.
- [formik](https://formik.org/docs/overview) - Validation, error messages and handling form submission
- [Yup](https://github.com/jquense/yup) - object schema validation

## 5. Integration with Existing Next.js Applications

Only the folders related to the layout need to be moved into your project. Integration of pages involves moving the files under those folders. Make sure that the using page is defined under the related group layout.

## 6. License
Distributed under the MIT `License`. See LICENSE for more information.
