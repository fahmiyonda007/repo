'use client';
import { format } from 'date-fns';
import { id as indonesia } from 'date-fns/locale';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import { Button } from 'primereact/button';
import { useMountEffect } from 'primereact/hooks';
import { Toast } from 'primereact/toast';
import { useLayoutEffect, useRef, useState } from 'react';
import { useAuth } from '../../../../layout/context/AuthContext';
import { PrintPayroll } from '../../../../types/print-payroll';
import { PrintPayrollService } from '../../../services/PrintPayrollService';
import jsPDF from 'jspdf';

export default function Page() {
    const searchParams = useSearchParams();
    const noPrint = searchParams.get('noPrint');
    const download = searchParams.get('download');
    const router = useRouter();
    const [stateData, setStateData] = useState<PrintPayroll>();
    const pathName = usePathname();
    const { user } = useAuth();
    const jsonReqBody = { token: user?.token!, requestPath: pathName };
    const toast = useRef<Toast>(null);
    const content = useRef<any>(null);

    const handleDownload = (filename: string) => {
        const pdf = new jsPDF();

        pdf.html(content.current, {
            callback: function (doc) {
                // Save the PDF
                doc.save(filename + '.pdf');
            },
            x: 15,
            y: 15,
            width: 170, //target width in the PDF document
            windowWidth: 650 //window width in CSS pixels
        });
    };

    useMountEffect(() => {
        PrintPayrollService.getPrintPayroll({ id: noPrint }, jsonReqBody)
            .then(async (res) => {
                const data = (await res.json()) as unknown as PrintPayroll[];
                if (res.ok) {
                    setStateData(data[0]);
                } else {
                    router.push('/print');
                }
            })
            .catch((ex) => {
                toast.current?.show({ severity: 'error', summary: 'Error', detail: ex.message, life: 3000 });
            });
    });

    useLayoutEffect(() => {
        if (download == 'true' && stateData) {
            handleDownload(`payroll-${stateData?.noPrint.replace('\\', '_')}`);
            router.back();
        }
    });

    return (
        <div>
            <Toast ref={toast}></Toast>
            <div className="flex gap-2">
                <Button label="Back" className="mb-3" outlined onClick={() => router.push('/print')}></Button>
                <Button label="Download" severity="success" className="mb-3" outlined onClick={() => handleDownload(`payroll-${stateData?.noPrint.replace('\\', '_')!}`)}></Button>
            </div>
            <div className="card">
                <div className="col-12" ref={content}>
                    <table cellSpacing="0" cellPadding="4">
                        <tbody>
                            <tr>
                                <td>Nomor</td>
                                <td>&nbsp;:&nbsp;</td>
                                <td>{stateData?.noPrint}</td>
                            </tr>
                            <tr>
                                <td>Tanggal</td>
                                <td>&nbsp;:&nbsp;</td>
                                <td>{format(new Date(), 'dd-MM-yyyy')}</td>
                            </tr>
                            <tr>
                                <td>Printed By</td>
                                <td>&nbsp;:&nbsp;</td>
                                <td>{user?.email}</td>
                            </tr>
                        </tbody>
                    </table>
                    <br />
                    <p>
                        <b>
                            KEPADA PT. BANK HIBANK INDONESIA - KANTOR PUSAT <br />
                            JL. TOMANG RAYA 21-23 JAKARTA
                        </b>
                    </p>
                    <p>
                        PERIHAL : PEMBAYARAN GAJI {format(new Date(), 'MMMM yyyy', { locale: indonesia }).toUpperCase()} {stateData?.company}
                    </p>
                    <p>
                        Dengan Hormat,
                        <br /> Sehubungan dengan diadakan kerjasama payroll gaji antara {stateData?.company} dan PT. HiBank Indonesia - Kantor Pusat,
                        <br /> dengan ini kami sampaikan data payroll untuk dapat diproses dengan informasi sebagai berikut:
                    </p>
                    <br />
                    <table cellSpacing="0" cellPadding="4">
                        <tbody>
                            <tr>
                                <td>Bulan Pembayaran</td>
                                <td>&nbsp;:&nbsp;</td>
                                <td>{format(new Date(), 'MMMM yyyy', { locale: indonesia })}</td>
                            </tr>
                            <tr>
                                <td>Tanggal Proses</td>
                                <td>&nbsp;:&nbsp;</td>
                                <td>{stateData?.valueDate}</td>
                            </tr>
                            <tr>
                                <td>Total Rekening</td>
                                <td>&nbsp;:&nbsp;</td>
                                <td>{stateData?.totalRekening}</td>
                            </tr>
                            <tr>
                                <td>Total Nominal</td>
                                <td>&nbsp;:&nbsp;</td>
                                <td>{stateData?.totalNominal.toLocaleString()}</td>
                            </tr>
                            <tr>
                                <td>Beban Rekening</td>
                                <td>&nbsp;:&nbsp;</td>
                                <td>{stateData?.bebanRekening}</td>
                            </tr>
                        </tbody>
                    </table>
                    <br />

                    <table border={1} cellSpacing="0" cellPadding="4">
                        <thead>
                            <tr>
                                <td>No Batch</td>
                                <td>Keterangan</td>
                                <td>Total Rekening</td>
                                <td>Total Nominal</td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>{stateData?.noBatch}</td>
                                <td>{stateData?.keterangan}</td>
                                <td>{stateData?.totalRekening}</td>
                                <td>{stateData?.totalNominal}</td>
                            </tr>
                        </tbody>
                    </table>
                    <br />
                    <p>
                        Data dimaksud telah kami periksa dan diyakini kebenarannya. <br />
                        Demikian kami sampaikan, atas perhatian dan kerjasamanya kami ucapkan terima kasih.
                    </p>
                    <p>Hormat kami,</p>
                    <br />
                    <br />
                    <br />
                    <p>
                        <b>{stateData?.company}</b>
                    </p>
                </div>
            </div>
        </div>
    );
}
