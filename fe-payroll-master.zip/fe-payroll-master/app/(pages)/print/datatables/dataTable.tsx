import { format } from 'date-fns';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { usePathname, useRouter } from 'next/navigation';
import { Button } from 'primereact/button';
import { Column } from 'primereact/column';
import { DataTable, DataTableFilterMeta } from 'primereact/datatable';
import { Dropdown } from 'primereact/dropdown';
import { useMountEffect } from 'primereact/hooks';
import { Toast } from 'primereact/toast';
import { Toolbar } from 'primereact/toolbar';
import React, { useRef, useState } from 'react';
import { useAuth } from '../../../../layout/context/AuthContext';
import { PrintPayroll } from '../../../../types/print-payroll';
import { renderHeader } from '../../../components/DataTableHeader';
import { PrintPayrollService } from '../../../services/PrintPayrollService';
import { printPayrollColumns } from './columns';
import { printPayrollFilter } from './filters';

interface NoPrint {
    noPrint: string;
}

const PrintPayrollDataTable = () => {
    const [loading, setLoading] = useState(false);
    const [stateDatas, setStateDatas] = useState<PrintPayroll[]>([]);
    const defaultFilters: DataTableFilterMeta = printPayrollFilter;
    const [filters, setFilters] = useState<DataTableFilterMeta>(defaultFilters);
    const [selectedDatas, setSelectedDatas] = useState<PrintPayroll[]>([]);
    const [rows, setRows] = useState<number>(5);
    const pathName = usePathname();
    const { user } = useAuth();
    const jsonReqBody = { token: user?.token!, requestPath: pathName };
    const toast = useRef<Toast>(null);
    const columns = printPayrollColumns;
    const router = useRouter();
    const [selectedNoPrint, setSelectedNoPrint] = useState<NoPrint | null>(null);
    const [noPrints, setNoPrints] = useState<NoPrint[]>([]);

    const onGlobalFilterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        let _filters = { ...filters };

        // @ts-ignore
        _filters['global'].value = value;

        setFilters(_filters);
    };

    const previewHandler = () => {
        if (!selectedNoPrint) {
            toast.current?.show({ severity: 'error', summary: 'Error', detail: `No data to preview.`, life: 3000 });
            return;
        }

        router.push(`/print/preview?noPrint=${selectedNoPrint?.noPrint}&download=false`);
    };

    const leftToolbar = () => {
        return (
            <div className="flex flex-row gap-2">
                <div className="flex flex-column">
                    <Dropdown
                        value={selectedNoPrint}
                        filter
                        showClear
                        onChange={(e) => {
                            setSelectedNoPrint(e.value);
                            setStateDatas([]);
                            if (e.value) {
                                setLoading(true);

                                PrintPayrollService.getPrintPayroll({ id: e.value.noPrint }, jsonReqBody)
                                    .then(async (res) => {
                                        const data = (await res.json()) as unknown as PrintPayroll[];
                                        if (res.ok) {
                                            setStateDatas(data);
                                            toast.current?.show({ severity: 'success', summary: 'success', detail: `Selected ${e.value.noPrint}`, life: 3000 });
                                        } else {
                                            toast.current?.show({
                                                severity: 'error',
                                                summary: 'Error',
                                                detail:
                                                    //@ts-ignore
                                                    data.message,
                                                life: 3000
                                            });
                                        }
                                    })
                                    .catch((ex) => {
                                        toast.current?.show({ severity: 'error', summary: 'Error', detail: ex.message, life: 3000 });
                                    })
                                    .finally(() => {
                                        setLoading(false);
                                    });
                            }
                        }}
                        options={noPrints}
                        optionLabel="noPrint"
                        placeholder="Select a No. Print"
                        className="w-full md:w-14rem"
                    />
                    <small id="username-help">Enter no print first for display data.</small>
                </div>
                <Button icon="pi pi-eye" tooltip="Preview" onClick={previewHandler} tooltipOptions={{ position: 'top' }} rounded outlined />
                <Button icon="pi pi-download" tooltip="Download" onClick={handleDownload} tooltipOptions={{ position: 'top' }} rounded outlined severity="success" />
            </div>
        );
    };

    const handleImportPdf = () => {
        if (stateDatas.length == 0) {
            toast.current?.show({ severity: 'error', summary: 'Error', detail: `No data to download.`, life: 3000 });
            return;
        }

        setLoading(true);
        const generatePDF = () => {
            const pdf = new jsPDF();

            autoTable(pdf, {
                head: [['No Batch', 'Keterangan', 'Total Rekening', 'Total Nominal']],
                body: stateDatas.map((x) => [x.noBatch, x.keterangan, x.totalRekening, x.totalNominal]),
                tableWidth: 'auto',
                theme: 'grid'
            });

            const dt = format(new Date(), 'ddMMyyyyHHmmss');
            pdf.save(`print payrol ${dt}.pdf`);
            setLoading(false);
        };

        generatePDF();
    };

    const handleDownload = () => {
        router.push(`/print/preview?noPrint=${selectedNoPrint?.noPrint}&download=true`);
    };

    const header = renderHeader('Data Payroll Group List', onGlobalFilterChange);

    useMountEffect(() => {
        //@ts-ignore
        defaultFilters.global.value = null;

        PrintPayrollService.getNoPrints(jsonReqBody)
            .then(async (res) => {
                const data = (await res.json()) as unknown as NoPrint[];
                if (res.ok) {
                    setNoPrints(data);
                } else {
                    toast.current?.show({
                        severity: 'error',
                        summary: 'Error',
                        detail:
                            //@ts-ignore
                            data.message,
                        life: 3000
                    });
                }
            })
            .catch((ex) => {
                toast.current?.show({ severity: 'error', summary: 'Error', detail: ex.message, life: 3000 });
            });
    });

    return (
        <>
            <Toast ref={toast}></Toast>
            <div className="card">
                <Toolbar className="mb-4" start={leftToolbar}></Toolbar>
                <DataTable
                    value={stateDatas}
                    size="normal"
                    dataKey="noRekening"
                    globalFilterFields={Object.keys(filters)}
                    filters={filters}
                    filterDelay={1000}
                    filterDisplay="menu"
                    paginator
                    rows={rows}
                    rowsPerPageOptions={[5, 10, 25, 50]}
                    loading={loading}
                    header={header}
                    stripedRows
                    removableSort
                    scrollable
                    resizableColumns
                    columnResizeMode="expand"
                    tableStyle={{ minWidth: '50rem' }}
                    selection={selectedDatas}
                    selectionMode={'checkbox'}
                    onSelectionChange={(e) => {
                        if (Array.isArray(e.value)) {
                            setSelectedDatas(e.value);
                        }
                    }}
                >
                    {columns.map((col, i) => (
                        <Column key={col.field} field={col.field} header={col.header} filterPlaceholder={col.filterPlaceholder} sortable={col.sortable} filter={col.filter} body={col.body} frozen={col.frozen} showFilterMenu={col.showFilterMenu} />
                    ))}
                </DataTable>
            </div>
        </>
    );
};

export default PrintPayrollDataTable;
