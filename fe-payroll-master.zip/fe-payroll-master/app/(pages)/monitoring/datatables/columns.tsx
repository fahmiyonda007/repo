import { ColumnProps } from 'primereact/column';
import { MonitoringPayroll } from '../../../../types/monitoring-payroll';

const columns: ColumnProps[] = [
    {
        field: 'noBatch',
        header: 'No Batch',
        filterField: 'noBatch',
        filterPlaceholder: 'Search by no batch',
        sortable: false,
        filter: false,
        frozen: false,
        showFilterMenu: false,
        body: (rowData: MonitoringPayroll) => {
            return <div>{rowData.noBatch}</div>;
        }
    },
    {
        field: 'keterangan',
        header: 'Keterangan',
        filterField: 'keterangan',
        filterPlaceholder: 'Search by keterangan',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'totalRekening',
        header: 'Total Rekening',
        filterField: 'totalRekening',
        filterPlaceholder: 'Search by total rekening',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'totalNominal',
        header: 'Total Nominal',
        filterField: 'totalNominal',
        filterPlaceholder: 'Search by total nominal',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'noPrint',
        header: 'No Print',
        filterField: 'noPrint',
        filterPlaceholder: 'Search by no print',
        sortable: false,
        filter: false,
        frozen: false
    }
];

export const monitoringPayrollColumns = [...columns];
