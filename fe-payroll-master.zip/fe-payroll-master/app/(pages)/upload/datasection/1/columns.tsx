import { ColumnProps } from 'primereact/column';
import { UploadPayroll } from '../../../../../types/upload-payroll';

const columns: ColumnProps[] = [
    {
        field: 'reference',
        header: 'Reference',
        filterField: 'reference',
        filterPlaceholder: 'Search by reference',
        sortable: false,
        filter: false,
        frozen: false
    }
];

export const Columns = [...columns];
