import { ColumnProps } from 'primereact/column';

const columns: ColumnProps[] = [
    {
        field: 'filename',
        header: 'Filename',
        filterField: 'filename',
        filterPlaceholder: 'Search by filename',
        sortable: false,
        filter: false,
        frozen: false
    }
];

export const Columns = [...columns];
