import { FilterMatchMode, FilterOperator } from 'primereact/api';

export const Filter = {
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    bankId: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }]
    }
};
