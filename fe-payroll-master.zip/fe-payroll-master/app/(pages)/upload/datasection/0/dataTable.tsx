import _ from 'lodash';
import { Column } from 'primereact/column';
import { DataTable, DataTableFilterMeta } from 'primereact/datatable';
import { useMountEffect } from 'primereact/hooks';
import React, { useState } from 'react';
import { UploadDataSection, UploadPayroll } from '../../../../../types/upload-payroll';
import { renderHeader } from '../../../../components/DataTableHeader';
import { Columns } from './columns';
import { Filter } from './filters';

const DataTableSection0 = (prop: UploadDataSection) => {
    const { data } = prop;
    const defaultFilters: DataTableFilterMeta = Filter;
    const [filters, setFilters] = useState<DataTableFilterMeta>(defaultFilters);
    const [selectedDatas, setSelectedDatas] = useState<UploadPayroll[]>([]);
    const columns = Columns;

    const onGlobalFilterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        let _filters = { ...filters };

        // @ts-ignore
        _filters['global'].value = value;

        setFilters(_filters);
    };

    const debouncedOnChange = _.debounce(onGlobalFilterChange, 1000);

    const header = renderHeader('Duplikasi Referensi', debouncedOnChange);

    useMountEffect(() => {
        //@ts-ignore
        defaultFilters.global.value = null;
    });

    return (
        <>
            <div className="card">
                <DataTable
                    value={data}
                    size="normal"
                    dataKey="id"
                    globalFilterFields={Object.keys(filters)}
                    filters={filters}
                    header={header}
                    stripedRows
                    removableSort
                    scrollable
                    resizableColumns
                    // reorderableColumns
                    columnResizeMode="expand"
                    tableStyle={{ minWidth: '50rem' }}
                    selection={selectedDatas}
                    selectionMode={'checkbox'}
                    onSelectionChange={(e) => {
                        if (Array.isArray(e.value)) {
                            setSelectedDatas(e.value);
                        }
                    }}
                >
                    {columns.map((col, i) => (
                        <Column key={col.field} field={col.field} header={col.header} filterPlaceholder={col.filterPlaceholder} sortable={col.sortable} filter={col.filter} body={col.body} frozen={col.frozen} showFilterMenu={col.showFilterMenu} />
                    ))}
                </DataTable>
            </div>
        </>
    );
};

export default DataTableSection0;
