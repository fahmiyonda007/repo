import * as Yup from 'yup';

export const UploadPayrollSchema = Yup.object().shape({
    bankId: Yup.string().min(1, 'Too Short!').max(50, 'Too Long!').required('Required!'),
    via: Yup.string().min(1, 'Too Short!').max(50, 'Too Long!').required('Required!'),
    noRekeningTujuan: Yup.string().required('Required!'),
    namaNasabahTujuan: Yup.string().required('Required!'),
    nominal: Yup.string().required('Required!'),
    reference: Yup.string().required('Required!'),
    keterangan: Yup.string().required('Required!'),
    alamat: Yup.string().required('Required!'),
    kodeKota: Yup.string().required('Required!'),
    filename: Yup.string().required('Required!')
});
