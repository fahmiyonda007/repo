import { ColumnProps } from 'primereact/column';
import { UploadPayroll } from '../../../../types/upload-payroll';

const columns: ColumnProps[] = [
    {
        field: 'bankId',
        header: 'Name',
        filterField: 'bankId',
        filterPlaceholder: 'Search by uploadPayroll name',
        sortable: false,
        filter: false,
        frozen: false,
        showFilterMenu: false,
        body: (rowData: UploadPayroll) => {
            return <div>{rowData.bankId}</div>;
        }
    },
    {
        field: 'via',
        header: 'Via',
        filterField: 'via',
        filterPlaceholder: 'Search by via',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'noRekeningTujuan',
        header: 'No Rekening Tujuan',
        filterField: 'noRekeningTujuan',
        filterPlaceholder: 'Search by no rekening tujuan',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'namaNasabahTujuan',
        header: 'Nama Nasabah Tujuan',
        filterField: 'namaNasabahTujuan',
        filterPlaceholder: 'Search by nama nasabah tujuan',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'nominal',
        header: 'Nominal',
        filterField: 'nominal',
        filterPlaceholder: 'Search by nominal',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'reference',
        header: 'Reference',
        filterField: 'reference',
        filterPlaceholder: 'Search by reference',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'keterangan',
        header: 'Keterangan',
        filterField: 'keterangan',
        filterPlaceholder: 'Search by keterangan',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'alamat',
        header: 'Alamat',
        filterField: 'alamat',
        filterPlaceholder: 'Search by alamat',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'kodeKota',
        header: 'Kode Kota',
        filterField: 'kodeKota',
        filterPlaceholder: 'Search by kode kota',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'filename',
        header: 'Filename',
        filterField: 'filename',
        filterPlaceholder: 'Search by filename',
        sortable: false,
        filter: false,
        frozen: false
    }
];

export const uploadPayrollColumns = [...columns];
