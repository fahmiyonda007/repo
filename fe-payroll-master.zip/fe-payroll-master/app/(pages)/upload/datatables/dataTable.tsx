import { usePathname } from 'next/navigation';
import { Badge } from 'primereact/badge';
import { Button } from 'primereact/button';
import { Column } from 'primereact/column';
import { ConfirmPopup, confirmPopup } from 'primereact/confirmpopup';
import { DataTable, DataTableFilterMeta } from 'primereact/datatable';
import { FileUpload, FileUploadHandlerEvent, FileUploadHeaderTemplateOptions } from 'primereact/fileupload';
import { useMountEffect } from 'primereact/hooks';
import { ProgressBar } from 'primereact/progressbar';
import { TabPanel, TabPanelHeaderTemplateOptions, TabView } from 'primereact/tabview';
import { Toast } from 'primereact/toast';
import { classNames } from 'primereact/utils';
import React, { useRef, useState } from 'react';
import * as XLSX from 'xlsx';
import { useAuth } from '../../../../layout/context/AuthContext';
import { JsonResponse } from '../../../../types/metamodel';
import { UploadFormat, UploadPayroll, UploadResponse } from '../../../../types/upload-payroll';
import { renderHeader } from '../../../components/DataTableHeader';
import { UploadPayrollService } from '../../../services/UploadPayrollService';
import DataTableSection0 from '../datasection/0/dataTable';
import DataTableSection1 from '../datasection/1/dataTable';
import DataTableSection2 from '../datasection/2/dataTable';
import DataTableSection3 from '../datasection/3/dataTable';
import DataTableSection4 from '../datasection/4/dataTable';
import DataTableSection5 from '../datasection/5/dataTable';
import DataTableSection6 from '../datasection/6/dataTable';
import DataTableSection7 from '../datasection/7/dataTable';
import { uploadPayrollColumns } from './columns';
import { uploadPayrollFilter } from './filters';

const UploadPayrollDataTable = () => {
    const [loading, setLoading] = useState(false);
    const [stateDatas, setStateDatas] = useState<UploadPayroll[]>([]);
    const defaultFilters: DataTableFilterMeta = uploadPayrollFilter;
    const [filters, setFilters] = useState<DataTableFilterMeta>(defaultFilters);
    const [selectedDatas, setSelectedDatas] = useState<UploadPayroll[]>([]);
    const pathName = usePathname();
    const { user } = useAuth();
    const toast = useRef<Toast>(null);
    const fileUploadRef = useRef<FileUpload>(null);
    const columns = uploadPayrollColumns;
    const [uploadResponse, setUploadResponse] = useState<UploadResponse>();
    const [uploadDisabled, setUploadDisabled] = useState<boolean>(false);
    const [totalError, setTotalError] = useState<number>(0);
    const [activeIndex, setActiveIndex] = useState<number>(0);
    const jsonReqBody = { token: user?.token!, requestPath: pathName };

    const onGlobalFilterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        let _filters = { ...filters };

        // @ts-ignore
        _filters['global'].value = value;

        setFilters(_filters);
    };

    const header = renderHeader('Upload Payroll Detail List', onGlobalFilterChange);

    function UploadHandler(event: FileUploadHandlerEvent) {
        setUploadDisabled(true);

        const file = event.files[0];

        if (!(file.type.includes('csv') || file.type.includes('sheet'))) {
            toast.current?.show({ severity: 'error', summary: 'error', detail: 'File not support', life: 3000 });
            setUploadDisabled(false);
            return;
        }

        const reader = new FileReader();
        reader.readAsArrayBuffer(file);

        reader.onloadend = (e) => {
            const res = e.target?.result;
            const workbook = XLSX.read(res);
            const sheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];
            const data = XLSX.utils.sheet_to_json<UploadFormat>(worksheet);

            UploadPayrollService.uploadPayroll({ filename: file.name, data: data }, jsonReqBody)
                .then(async (res) => {
                    const data = (await res.json()) as unknown as UploadResponse;
                    if (res.ok) {
                        setUploadResponse(data);
                        setStateDatas(data.data);
                        setTotalError(data.listError.listErrorCount);
                        fileUploadRef.current?.clear();
                        toast.current?.show({ severity: 'success', summary: 'success', detail: 'Upload File Success', life: 3000 });
                    } else {
                        toast.current?.show({ severity: 'error', summary: 'error', detail: data.message, life: 3000 });
                    }
                })
                .catch((ex: any) => {
                    toast.current?.show({ severity: 'error', summary: 'error', detail: 'Failed!', life: 3000 });
                })
                .finally(() => {
                    setUploadDisabled(false);
                });
        };
    }

    const headerTemplate = (options: FileUploadHeaderTemplateOptions) => {
        const { className, chooseButton, uploadButton, cancelButton } = options;
        return (
            <>
                <div className={className} style={{ backgroundColor: 'transparent', display: 'flex', alignItems: 'center' }}>
                    <div className={classNames(uploadDisabled ? 'p-disabled' : '')}>{chooseButton}</div>
                    <div className={classNames(uploadDisabled ? 'p-disabled' : '')}>{uploadButton}</div>
                    <div className={classNames(uploadDisabled ? 'p-disabled' : '')}>{cancelButton}</div>
                </div>
                <ProgressBar hidden={!uploadDisabled} mode="indeterminate" style={{ height: '5px' }}></ProgressBar>
            </>
        );
    };

    const uploadBatchHandler = (event: any) => {
        const accept = () => {
            setLoading(true);
            UploadPayrollService.addUploadPayrolls(stateDatas, jsonReqBody)
                .then(async (res) => {
                    const data = (await res.json()) as unknown as JsonResponse;
                    if (res.ok) {
                        setStateDatas([]);
                        toast.current?.show({ severity: 'success', summary: 'success', detail: 'Upload Batch Success', life: 3000 });
                    } else {
                        toast.current?.show({ severity: 'error', summary: 'error', detail: data.message, life: 3000 });
                    }
                })
                .catch((ex) => {
                    toast.current?.show({ severity: 'error', summary: 'error', detail: ex.message, life: 3000 });
                })
                .finally(() => {
                    setLoading(false);
                });
        };

        const reject = () => {
            toast.current?.show({ severity: 'warn', summary: 'Rejected', detail: 'You have rejected', life: 3000 });
        };

        confirmPopup({
            target: event.currentTarget,
            message: 'Are you sure you want to proceed?',
            icon: 'pi pi-exclamation-triangle',
            dismissable: false,
            accept,
            reject
        });
    };

    useMountEffect(() => {
        //@ts-ignore
        defaultFilters.global.value = null;
    });

    return (
        <>
            <Toast ref={toast}></Toast>
            <ConfirmPopup />
            <TabView activeIndex={activeIndex} onTabChange={(e) => setActiveIndex(e.index)}>
                <TabPanel leftIcon={'pi pi-home mr-2'} header="Action">
                    <div className="card">
                        <div className="mb-4">
                            <FileUpload
                                ref={fileUploadRef}
                                name="data[]"
                                accept=".csv, .xlsx"
                                maxFileSize={2000000}
                                emptyTemplate={<p className="m-0">Drag and drop files to here to upload.</p>}
                                chooseLabel="Browse"
                                headerTemplate={headerTemplate}
                                customUpload
                                uploadHandler={UploadHandler}
                            />
                        </div>

                        <div className="my-5">
                            <Button label="Upload Batch" severity="success" loading={loading} onClick={uploadBatchHandler} className={classNames({ hidden: !(stateDatas.length > 0 && totalError == 0) })} />
                            <Button
                                label="Check Error"
                                severity="danger"
                                loading={loading}
                                onClick={() => {
                                    setActiveIndex(1);
                                }}
                                className={classNames({ hidden: totalError == 0 })}
                            />
                        </div>

                        <DataTable
                            value={stateDatas}
                            size="normal"
                            dataKey="noRekeningTujuan"
                            globalFilterFields={Object.keys(filters)}
                            filters={filters}
                            filterDelay={1000}
                            filterDisplay="menu"
                            paginator
                            rows={10}
                            rowsPerPageOptions={[5, 10, 25, 50]}
                            loading={loading}
                            header={header}
                            stripedRows
                            removableSort
                            scrollable
                            resizableColumns
                            columnResizeMode="expand"
                            tableStyle={{ minWidth: '50rem' }}
                            selection={selectedDatas}
                            selectionMode={'checkbox'}
                            onSelectionChange={(e) => {
                                if (Array.isArray(e.value)) {
                                    setSelectedDatas(e.value);
                                }
                            }}
                        >
                            {columns.map((col, i) => (
                                <Column
                                    key={col.field}
                                    field={col.field}
                                    header={col.header}
                                    filterPlaceholder={col.filterPlaceholder}
                                    sortable={col.sortable}
                                    filter={col.filter}
                                    body={col.body}
                                    frozen={col.frozen}
                                    showFilterMenu={col.showFilterMenu}
                                />
                            ))}
                        </DataTable>
                    </div>
                </TabPanel>
                <TabPanel leftIcon={'pi pi-list mr-2'} header="Data Section Detail">
                    <div className="card">
                        <TabView scrollable>
                            <TabPanel
                                headerTemplate={(options: TabPanelHeaderTemplateOptions) => {
                                    return (
                                        <div className="flex align-items-center gap-2 p-3" style={{ cursor: 'pointer' }} onClick={options.onClick}>
                                            <span className="white-space-nowrap">Duplikasi Referensi</span>
                                            {uploadResponse?.listError.dupeReffCount! > 0 ? <Badge value={uploadResponse?.listError.dupeReffCount} severity="danger"></Badge> : null}
                                        </div>
                                    );
                                }}
                            >
                                <DataTableSection0 data={uploadResponse?.listError.dupeReff!} />
                            </TabPanel>
                            <TabPanel
                                headerTemplate={(options: TabPanelHeaderTemplateOptions) => {
                                    return (
                                        <div className="flex align-items-center gap-2 p-3" style={{ cursor: 'pointer' }} onClick={options.onClick}>
                                            <span className="white-space-nowrap">Referensi Sudah di Upload</span>
                                            {uploadResponse?.listError.reffExistsCount! > 0 ? <Badge value={uploadResponse?.listError.reffExistsCount} severity="danger"></Badge> : null}
                                        </div>
                                    );
                                }}
                            >
                                <DataTableSection1 data={uploadResponse?.listError.reffExists!} />
                            </TabPanel>
                            <TabPanel
                                headerTemplate={(options: TabPanelHeaderTemplateOptions) => {
                                    return (
                                        <div className="flex align-items-center gap-2 p-3" style={{ cursor: 'pointer' }} onClick={options.onClick}>
                                            <span className="white-space-nowrap">{`Referensi > 15 Char`}</span>
                                            {uploadResponse?.listError.reffMoreThan15Count! > 0 ? <Badge value={uploadResponse?.listError.reffMoreThan15Count} severity="danger"></Badge> : null}
                                        </div>
                                    );
                                }}
                            >
                                <DataTableSection2 data={uploadResponse?.listError.reffMoreThan15!} />
                            </TabPanel>
                            <TabPanel
                                headerTemplate={(options: TabPanelHeaderTemplateOptions) => {
                                    return (
                                        <div className="flex align-items-center gap-2 p-3" style={{ cursor: 'pointer' }} onClick={options.onClick}>
                                            <span className="white-space-nowrap">{`Nominal Tidak Valid`}</span>
                                            {uploadResponse?.listError.nominalNotValidCount! > 0 ? <Badge value={uploadResponse?.listError.nominalNotValidCount} severity="danger"></Badge> : null}
                                        </div>
                                    );
                                }}
                            >
                                <DataTableSection3 data={uploadResponse?.listError.nominalNotValid!} />
                            </TabPanel>
                            <TabPanel
                                headerTemplate={(options: TabPanelHeaderTemplateOptions) => {
                                    return (
                                        <div className="flex align-items-center gap-2 p-3" style={{ cursor: 'pointer' }} onClick={options.onClick}>
                                            <span className="white-space-nowrap">{`Bank ID Tidak Valid`}</span>
                                            {uploadResponse?.listError.bankNotValidCount! > 0 ? <Badge value={uploadResponse?.listError.bankNotValidCount} severity="danger"></Badge> : null}
                                        </div>
                                    );
                                }}
                            >
                                <DataTableSection4 data={uploadResponse?.listError.bankNotValid!} />
                            </TabPanel>
                            <TabPanel
                                headerTemplate={(options: TabPanelHeaderTemplateOptions) => {
                                    return (
                                        <div className="flex align-items-center gap-2 p-3" style={{ cursor: 'pointer' }} onClick={options.onClick}>
                                            <span className="white-space-nowrap">{`Company Tidak Valid`}</span>
                                            {uploadResponse?.listError.companyNotValidCount! > 0 ? <Badge value={uploadResponse?.listError.companyNotValidCount} severity="danger"></Badge> : null}
                                        </div>
                                    );
                                }}
                            >
                                <DataTableSection5 data={uploadResponse?.listError.companyNotValid!} />
                            </TabPanel>
                            <TabPanel
                                headerTemplate={(options: TabPanelHeaderTemplateOptions) => {
                                    return (
                                        <div className="flex align-items-center gap-2 p-3" style={{ cursor: 'pointer' }} onClick={options.onClick}>
                                            <span className="white-space-nowrap">{`No. Rekening Tidak Valid`}</span>
                                            {uploadResponse?.listError.rekeningNotValidCount! > 0 ? <Badge value={uploadResponse?.listError.rekeningNotValidCount} severity="danger"></Badge> : null}
                                        </div>
                                    );
                                }}
                            >
                                <DataTableSection6 data={uploadResponse?.listError.rekeningNotValid!} />
                            </TabPanel>
                            <TabPanel
                                headerTemplate={(options: TabPanelHeaderTemplateOptions) => {
                                    return (
                                        <div className="flex align-items-center gap-2 p-3" style={{ cursor: 'pointer' }} onClick={options.onClick}>
                                            <span className="white-space-nowrap">{`Nama Penerima Tidak Match`}</span>
                                            {uploadResponse?.listError.penerimaNotMatchCount! > 0 ? <Badge value={uploadResponse?.listError.penerimaNotMatchCount} severity="danger"></Badge> : null}
                                        </div>
                                    );
                                }}
                            >
                                <DataTableSection7 data={uploadResponse?.listError.penerimaNotMatch!} />
                            </TabPanel>
                        </TabView>
                    </div>
                </TabPanel>
            </TabView>
        </>
    );
};

export default UploadPayrollDataTable;
