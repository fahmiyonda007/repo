'use client';

import CompanyFormPage from '../forms/form';

const CompanyCreatePage = () => {
    return <CompanyFormPage />;
};

export default CompanyCreatePage;
