import { FilterMatchMode, FilterOperator } from 'primereact/api';

export const companyFilter = {
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    companyName: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }]
    }
};
