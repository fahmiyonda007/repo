import { ColumnProps } from 'primereact/column';
import { rowinfo } from '../../../../components/rowinfo';

const columns: ColumnProps[] = [
    {
        field: 'companyName',
        header: ' Company Name',
        filterField: 'companyName',
        filterPlaceholder: 'Search by company name',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'cmsType',
        header: ' CMS Type',
        filterField: 'cmsType',
        filterPlaceholder: 'Search by cms type',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'coAccountNo',
        header: 'Co Account No',
        filterField: 'coAccountNo',
        filterPlaceholder: 'Search by co account no',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'isSewa',
        header: 'Is Sewa',
        filterField: 'isSewa',
        filterPlaceholder: 'Search by is sewa',
        sortable: false,
        filter: false,
        frozen: false
    }
];

export const companyColumns = [...columns, ...rowinfo];
