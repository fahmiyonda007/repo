import * as Yup from 'yup';

export const CompanySchema = Yup.object().shape({
    companyName: Yup.string().min(1, 'Too Short!').max(50, 'Too Long!').required('Required!'),
    cmsType: Yup.string().required('Required!'),
    coAccountNo: Yup.string().required('Required!'),
    isSewa: Yup.boolean().required('Required!')
});
