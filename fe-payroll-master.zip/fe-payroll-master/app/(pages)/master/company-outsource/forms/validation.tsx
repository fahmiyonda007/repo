import * as Yup from 'yup';

export const CompanyOutsourceSchema = Yup.object().shape({
    outsourceName: Yup.string().min(1, 'Too Short!').max(50, 'Too Long!').required('Required!'),
    outsourceCode: Yup.string().min(1, 'Too Short!').max(50, 'Too Long!').required('Required!')
});
