'use client';

import CompanyOutsourceFormPage from '../forms/form';

const CompanyOutsourceCreatePage = () => {
    return <CompanyOutsourceFormPage />;
};

export default CompanyOutsourceCreatePage;
