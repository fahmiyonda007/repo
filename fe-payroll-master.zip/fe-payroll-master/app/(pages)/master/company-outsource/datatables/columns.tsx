import { ColumnProps } from 'primereact/column';
import { CompanyOutsource } from '../../../../../types/company-outsource';
import { rowinfo } from '../../../../components/rowinfo';

const columns: ColumnProps[] = [
    {
        field: 'outsourceCode',
        header: 'Outsource Code',
        filterField: 'outsourceCode',
        filterPlaceholder: 'Search by outsource code',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'outsourceName',
        header: 'Outsource Name',
        filterField: 'outsourceName',
        filterPlaceholder: 'Search by outsource name',
        sortable: false,
        filter: false,
        frozen: false,
        showFilterMenu: false,
        body: (rowData: CompanyOutsource) => {
            return <div>{rowData.outsourceName}</div>;
        }
    }
];

export const companyOutsourceColumns = [...columns, ...rowinfo];
