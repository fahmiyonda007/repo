import _ from 'lodash';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { Button } from 'primereact/button';
import { Column } from 'primereact/column';
import { DataTable, DataTableFilterMeta } from 'primereact/datatable';
import { useMountEffect } from 'primereact/hooks';
import { Toast } from 'primereact/toast';
import { Toolbar } from 'primereact/toolbar';
import React, { useEffect, useRef, useState } from 'react';
import { useAuth } from '../../../../../layout/context/AuthContext';
import { CompanyOutsource } from '../../../../../types/company-outsource';
import { renderHeader } from '../../../../components/DataTableHeader';
import { deleteItemDialogFooter, deleteItemsDialogFooter } from '../../../../components/DeleteDialogFooter';
import DeleteDialog from '../../../../components/DeleteDialogTemplate';
import DeleteSelectedDialog from '../../../../components/DeleteSelectedDialogTemplate';
import PaginatorTemplate from '../../../../components/PaginatorTemplate';
import { CompanyOutsourceService } from '../../../../services/CompanyOutsourceService';
import { companyOutsourceColumns } from './columns';
import { companyOutsourceFilter } from './filters';

const CompanyOutsourceDataTable = () => {
    const [loading, setLoading] = useState(true);
    const [refresh, setRefresh] = useState(0);
    const [stateDatas, setStateDatas] = useState<CompanyOutsource[]>([]);
    const [stateData, setStateData] = useState<CompanyOutsource>();
    const defaultFilters: DataTableFilterMeta = companyOutsourceFilter;
    const [filters, setFilters] = useState<DataTableFilterMeta>(defaultFilters);
    const [globalFilterValue, setGlobalFilterValue] = useState<string>('');
    const [selectedDatas, setSelectedDatas] = useState<CompanyOutsource[]>([]);
    const [deleteDatasDialog, setDeleteDatasDialog] = useState<boolean>(false);
    const [deleteDataDialog, setDeleteDataDialog] = useState<boolean>(false);
    const [first, setFirst] = useState<number>(0);
    const [rows, setRows] = useState<number>(5);

    const router = useRouter();
    const { user } = useAuth();
    const toast = useRef<Toast>(null);
    const columns = companyOutsourceColumns;
    const pathName = usePathname();

    const onGlobalFilterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        let _filters = { ...filters };

        // @ts-ignore
        _filters['global'].value = value;

        setFilters(_filters);
        setGlobalFilterValue(value);
    };

    const debouncedOnChange = _.debounce(onGlobalFilterChange, 1000);

    const confirmDeleteSelected = () => {
        setDeleteDatasDialog(true);
    };

    const editData = (data: CompanyOutsource) => {
        router.push(`/master/company-outsource/${data.id}`);
    };

    const confirmDeleteData = (data: CompanyOutsource) => {
        setStateData(data);
        setDeleteDataDialog(true);
    };

    const hideDeleteDataDialog = () => {
        setDeleteDataDialog(false);
    };

    const hideDeleteDatasDialog = () => {
        setDeleteDatasDialog(false);
    };

    const deleteData = () => {
        setDeleteDataDialog(false);
        setLoading(true);
        CompanyOutsourceService.deleteCompanyOutsource(stateData?.id!, { token: user?.token!, requestPath: pathName }).then((res) => {
            if (res) {
                onRefresh();
                toast.current?.show({ severity: 'success', summary: 'Success', detail: 'Company outsource Deleted', life: 3000 });
            }
        });
    };

    const deleteSelectedDatas = () => {
        setDeleteDatasDialog(false);
        setSelectedDatas([]);
        onRefresh();
        //TODO: Create endpoint bulk delete with json params body
        // UserService.bulkDeleteUser(selectedUsers);
        toast.current?.show({ severity: 'success', summary: 'Success', detail: 'Selected Company outsource has been Deleted', life: 3000 });
    };

    const actionBody = (rowData: CompanyOutsource) => {
        return (
            <React.Fragment>
                <Button icon="pi pi-pencil" rounded outlined className="mr-2" onClick={() => editData(rowData)} />
                <Button icon="pi pi-trash" rounded outlined severity="danger" onClick={() => confirmDeleteData(rowData)} />
            </React.Fragment>
        );
    };

    const leftToolbar = () => {
        return (
            <div className="flex flex-wrap gap-2">
                <Link href={'/master/company-outsource/create'}>
                    <Button loading={loading} label="New" icon="pi pi-plus" outlined></Button>
                </Link>
                {/* <Button label="Delete" icon="pi pi-trash" severity="danger" onClick={confirmDeleteSelected} disabled={!selectedDatas || !selectedDatas.length} /> */}
            </div>
        );
    };

    const rightToolbar = () => {
        return (
            <>
                {/* <div className="flex flex-wrap gap-2">
                    <Button label="Export" icon="pi pi-upload" className="p-button-help" outlined />
                    <Button label="Import" icon="pi pi-download" className="p-button-success" outlined />
                </div> */}
            </>
        );
    };

    const header = renderHeader('Company Outsources', debouncedOnChange);
    const deleteDataDialogFooter = deleteItemDialogFooter(hideDeleteDataDialog, deleteData);
    const deleteDatasDialogFooter = deleteItemsDialogFooter(hideDeleteDatasDialog, deleteSelectedDatas);

    const onPageChange = (event: any) => {
        setFirst(event.first);
        setRows(event.rows);
    };

    const onRefresh = () => {
        setRefresh((refresh) => refresh + 1);
    };

    useMountEffect(() => {
        //@ts-ignore
        defaultFilters.global.value = null;
    });

    useEffect(() => {
        setLoading(true);
        CompanyOutsourceService.getCompanyOutsources({ limit: rows, skip: first, search: globalFilterValue }, { token: user?.token!, requestPath: pathName })
            .then((data) => {
                setStateDatas(data);
            })
            .catch((res) => {
                if (res) {
                    toast.current?.show({ severity: 'error', summary: 'error', detail: res.toString(), life: 3000 });
                }
            })
            .finally(() => {
                setLoading(false);
            });
    }, [rows, first, globalFilterValue, user, refresh, pathName]);

    return (
        <>
            <Toast ref={toast}></Toast>

            <div className="card">
                <Toolbar className="mb-4" start={leftToolbar} end={rightToolbar}></Toolbar>
                <DataTable
                    value={
                        //@ts-ignore
                        stateDatas['data']
                    }
                    size="normal"
                    dataKey="id"
                    globalFilterFields={Object.keys(filters)}
                    filters={filters}
                    loading={loading}
                    header={header}
                    stripedRows
                    removableSort
                    scrollable
                    resizableColumns
                    // reorderableColumns
                    columnResizeMode="expand"
                    tableStyle={{ minWidth: '50rem' }}
                    selection={selectedDatas}
                    selectionMode={'checkbox'}
                    onSelectionChange={(e) => {
                        if (Array.isArray(e.value)) {
                            setSelectedDatas(e.value);
                        }
                    }}
                >
                    {/* <Column selectionMode="multiple" frozen headerStyle={{ width: '3rem' }}></Column> */}
                    {columns.map((col, i) => (
                        <Column key={col.field} field={col.field} header={col.header} filterPlaceholder={col.filterPlaceholder} sortable={col.sortable} filter={col.filter} body={col.body} frozen={col.frozen} showFilterMenu={col.showFilterMenu} />
                    ))}
                    <Column body={actionBody} exportable={false} style={{ minWidth: '12rem' }}></Column>
                </DataTable>

                <PaginatorTemplate
                    first={first}
                    rows={rows}
                    totalRecords={
                        //@ts-ignore
                        stateDatas['total']
                    }
                    onPageChange={onPageChange}
                    onRefresh={onRefresh}
                />
            </div>

            {/* delete 1 data in row */}
            <DeleteDialog deleteItemDialog={deleteDataDialog} deleteItemDialogFooter={deleteDataDialogFooter} hideDeleteItemDialog={hideDeleteDataDialog} item={stateData} name={stateData?.outsourceName} />

            {/* delete multiple data by selected rows */}
            <DeleteSelectedDialog deleteItemsDialog={deleteDatasDialog} deleteItemsDialogFooter={deleteDatasDialogFooter} hideDeleteItemsDialog={hideDeleteDatasDialog} selectedItems={selectedDatas} />
        </>
    );
};

export default CompanyOutsourceDataTable;
