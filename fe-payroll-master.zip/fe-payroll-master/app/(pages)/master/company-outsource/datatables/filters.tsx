import { FilterMatchMode, FilterOperator } from 'primereact/api';

export const companyOutsourceFilter = {
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    companyOutsourceName: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }]
    }
};
