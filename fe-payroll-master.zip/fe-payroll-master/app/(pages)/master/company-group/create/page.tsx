'use client';

import CompanyGroupFormPage from '../forms/form';

const CompanyGroupCreatePage = () => {
    return <CompanyGroupFormPage />;
};

export default CompanyGroupCreatePage;
