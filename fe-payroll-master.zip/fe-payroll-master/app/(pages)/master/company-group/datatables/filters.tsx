import { FilterMatchMode, FilterOperator } from 'primereact/api';

export const companyGroupFilter = {
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    companyCode: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }]
    },
    companyName: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }]
    }
};
