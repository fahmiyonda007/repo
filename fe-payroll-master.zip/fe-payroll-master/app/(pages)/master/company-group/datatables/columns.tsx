import { ColumnProps } from 'primereact/column';
import { CompanyGroup } from '../../../../../types/company-group';
import { rowinfo } from '../../../../components/rowinfo';

const columns: ColumnProps[] = [
    {
        field: 'companyCode',
        header: 'Company Code',
        filterField: 'companyCode',
        filterPlaceholder: 'Search by company group code',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'companyName',
        header: 'Company Name',
        filterField: 'companyName',
        filterPlaceholder: 'Search by company group name',
        sortable: false,
        filter: false,
        frozen: false,
        showFilterMenu: false,
        body: (rowData: CompanyGroup) => {
            return <div>{rowData.companyName}</div>;
        }
    },
    {
        field: 'bebanRekening',
        header: 'Beban Rekening',
        filterField: 'bebanRekening',
        filterPlaceholder: 'Search by beban rekening',
        sortable: false,
        filter: false,
        frozen: false,
        showFilterMenu: false,
        body: (rowData: CompanyGroup) => {
            return <div>{rowData.bebanRekening}</div>;
        }
    },
    {
        field: 'cmsCompany',
        header: 'CMS Company',
        filterField: 'cmsCompany',
        filterPlaceholder: 'Search by CMS Company',
        sortable: false,
        filter: false,
        frozen: false,
        showFilterMenu: false,
        body: (rowData: CompanyGroup) => {
            return <div>{rowData.cmsCompanyId}</div>;
        }
    }
];

export const companyGroupColumns = [...columns];
