import * as Yup from 'yup';
import { CompanyGroup } from '../../../../../types/company-group';

export const CompanyGroupSchema = Yup.object().shape({
    companyCode: Yup.string().min(1, 'Too Short!').max(10, 'Too Long!').required('Required!'),
    companyName: Yup.string().min(1, 'Too Short!').max(50, 'Too Long!').required('Required!'),
    bebanRekening: Yup.string().max(10, 'Too Long!').required('Required!'),
    cmsCompanyId: Yup.number().min(1, 'Required!').required('Required!')
});
