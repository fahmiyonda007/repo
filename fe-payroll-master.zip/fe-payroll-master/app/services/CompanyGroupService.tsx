import { CompanyGroup } from '../../types/company-group';
import { JsonRequest } from '../../types/metamodel';
import { payrollApi } from '../constants/constants';

interface MetaPage {
    limit?: number;
    skip?: number;
    search?: string;
}

export const CompanyGroupService = {
    async getCompanyGroups(prop: MetaPage, req: JsonRequest) {
        const res = await fetch(`${payrollApi}master/company-group?search=${prop.search}&limit=${prop.limit}&skip=${prop.skip}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache'
            }
        });
        const data = await res.json();
        return data as CompanyGroup[];
    },

    async getCompanyGroup({ id }: any, req: JsonRequest) {
        const res = await fetch(`${payrollApi}master/company-group/${id}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache'
            }
        });
        return res;
    },

    async addCompanyGroup(prop: CompanyGroup, req: JsonRequest) {
        const res = await fetch(`${payrollApi}master/company-group`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async updateCompanyGroup(id: number, prop: CompanyGroup, req: JsonRequest) {
        const res = await fetch(`${payrollApi}master/company-group/${id}`, {
            method: 'PUT',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async deleteCompanyGroup(id: number, req: JsonRequest) {
        const res = await fetch(`${payrollApi}master/company-group/${id}`, {
            method: 'DELETE',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json'
            }
        });
        const data = await res.json();
        return data as CompanyGroup;
    }
};
