import { JsonRequest } from '../../types/metamodel';
import { PrintPayroll } from '../../types/print-payroll';
import { payrollApi } from '../constants/constants';

interface MetaPage {
    limit?: number;
    skip?: number;
    search?: string;
}

export const PrintPayrollService = {
    async getPrintPayrolls(prop: MetaPage, req: JsonRequest) {
        const res = await fetch(`${payrollApi}print?search=${prop.search}&limit=${prop.limit}&skip=${prop.skip}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache'
            }
        });
        const data = await res.json();
        return data as PrintPayroll[];
    },

    async getPrintPayroll({ id }: any, req: JsonRequest) {
        const res = await fetch(`${payrollApi}print?noPrint=${id}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache'
            }
        });
        return res;
    },

    async getNoPrints(req: JsonRequest) {
        const res = await fetch(`${payrollApi}print/noPrints`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache'
            }
        });
        return res;
    }
};
