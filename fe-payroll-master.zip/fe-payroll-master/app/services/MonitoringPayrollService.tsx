import { JsonRequest } from '../../types/metamodel';
import { MonitoringPayroll } from '../../types/monitoring-payroll';
import { payrollApi } from '../constants/constants';

interface MetaPage {
    limit?: number;
    skip?: number;
    search?: string;
}

export const MonitoringPayrollService = {
    async getMonitoringPayrolls(dt: any, prop: MetaPage, req: JsonRequest) {
        const res = await fetch(`${payrollApi}monitoring?search=${prop.search}&limit=${prop.limit}&skip=${prop.skip}&valueDate=${dt}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache'
            }
        });
        const data = await res.json();
        return data as MonitoringPayroll[];
    },

    async deleteMonitoring(id: number, req: JsonRequest) {
        const res = await fetch(`${payrollApi}monitoring`, {
            method: 'DELETE',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json'
            }
        });
        return res;
    }
};
