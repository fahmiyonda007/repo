import { Company } from '../../types/company';
import { JsonRequest } from '../../types/metamodel';
import { payrollApi } from '../constants/constants';

interface MetaPage {
    limit?: number;
    skip?: number;
    search?: string;
}

export const CompanyService = {
    async getCompanies(prop: MetaPage, req: JsonRequest) {
        const res = await fetch(`${payrollApi}master/companies?search=${prop.search}&limit=${prop.limit}&skip=${prop.skip}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache'
            }
        });
        const data = await res.json();
        return data as Company[];
    },

    async getCompany({ id }: any, req: JsonRequest) {
        const res = await fetch(`${payrollApi}master/companies/${id}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache'
            }
        });
        return res;
    },

    async addCompany(prop: Company, req: JsonRequest) {
        const res = await fetch(`${payrollApi}master/companies`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async updateCompany(id: number, prop: Company, req: JsonRequest) {
        const res = await fetch(`${payrollApi}master/companies/${id}`, {
            method: 'PUT',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async deleteCompany(id: number, req: JsonRequest) {
        const res = await fetch(`${payrollApi}master/companies/${id}`, {
            method: 'DELETE',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json'
            }
        });
        const data = await res.json();
        return data as Company;
    }
};
