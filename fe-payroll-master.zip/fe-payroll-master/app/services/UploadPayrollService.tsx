import { JsonRequest } from '../../types/metamodel';
import { UploadPayroll, UploadRequest } from '../../types/upload-payroll';
import { payrollApi } from '../constants/constants';

interface MetaPage {
    limit?: number;
    skip?: number;
    search?: string;
}

export const UploadPayrollService = {
    async getUploadPayrolls(prop: MetaPage, req: JsonRequest) {
        const res = await fetch(`${payrollApi}upload?search=${prop.search}&limit=${prop.limit}&skip=${prop.skip}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache'
            }
        });
        const data = await res.json();
        return data as UploadPayroll[];
    },

    async getUploadPayroll({ id }: any, req: JsonRequest) {
        const res = await fetch(`${payrollApi}upload/${id}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache'
            }
        });
        return res;
    },

    async addUploadPayrolls(prop: UploadPayroll[], req: JsonRequest) {
        const res = await fetch(`${payrollApi}upload`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ data: prop })
        });
        return res;
    },

    async uploadPayroll(prop: UploadRequest, req: JsonRequest) {
        const res = await fetch(`${payrollApi}upload/upload-file`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async updateUploadPayroll(id: number, prop: UploadPayroll, req: JsonRequest) {
        const res = await fetch(`${payrollApi}upload/${id}`, {
            method: 'PUT',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async deleteUploadPayroll(id: number, req: JsonRequest) {
        const res = await fetch(`${payrollApi}upload/${id}`, {
            method: 'DELETE',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json'
            }
        });
        const data = await res.json();
        return data as UploadPayroll;
    }
};
