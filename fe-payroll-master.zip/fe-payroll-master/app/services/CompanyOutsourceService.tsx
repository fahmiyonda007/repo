import { CompanyOutsource } from '../../types/company-outsource';
import { JsonRequest } from '../../types/metamodel';
import { payrollApi } from '../constants/constants';

interface MetaPage {
    limit?: number;
    skip?: number;
    search?: string;
}

export const CompanyOutsourceService = {
    async getCompanyOutsources(prop: MetaPage, req: JsonRequest) {
        const res = await fetch(`${payrollApi}master/company-outsource?search=${prop.search}&limit=${prop.limit}&skip=${prop.skip}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache'
            }
        });
        const data = await res.json();
        return data as CompanyOutsource[];
    },

    async getCompanyOutsource({ id }: any, req: JsonRequest) {
        const res = await fetch(`${payrollApi}master/company-outsource/${id}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache'
            }
        });
        return res;
    },

    async addCompanyOutsource(prop: CompanyOutsource, req: JsonRequest) {
        const res = await fetch(`${payrollApi}master/company-outsource`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async updateCompanyOutsource(id: number, prop: CompanyOutsource, req: JsonRequest) {
        const res = await fetch(`${payrollApi}master/company-outsource/${id}`, {
            method: 'PUT',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async deleteCompanyOutsource(id: number, req: JsonRequest) {
        const res = await fetch(`${payrollApi}master/company-outsource/${id}`, {
            method: 'DELETE',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json'
            }
        });
        const data = await res.json();
        return data as CompanyOutsource;
    }
};
