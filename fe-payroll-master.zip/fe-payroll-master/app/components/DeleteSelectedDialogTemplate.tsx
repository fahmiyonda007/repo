import { ReactElement, JSXElementConstructor, ReactNode, ReactPortal, PromiseLikeOfReactNode } from 'react';
import { Dialog, DialogProps } from 'primereact/dialog';

interface metaProps {
    deleteItemsDialog: boolean | undefined;
    deleteItemsDialogFooter: string | number | boolean | ReactElement<any, string | JSXElementConstructor<any>> | Iterable<ReactNode> | ReactPortal | PromiseLikeOfReactNode | ((props: DialogProps) => ReactNode) | null | undefined;
    hideDeleteItemsDialog: () => void;
    selectedItems: any;
}

const DeleteSelectedDialog = (props: metaProps) => {
    return (
        <Dialog visible={props.deleteItemsDialog} style={{ width: '32rem' }} breakpoints={{ '960px': '75vw', '641px': '90vw' }} header="Confirm" modal footer={props.deleteItemsDialogFooter} onHide={props.hideDeleteItemsDialog}>
            <div className="confirmation-content">
                <i className="pi pi-exclamation-triangle mr-3" style={{ fontSize: '2rem' }} />
                {props.selectedItems && <span>Are you sure you want to delete the selected Data?</span>}
            </div>
        </Dialog>
    );
};

export default DeleteSelectedDialog;
