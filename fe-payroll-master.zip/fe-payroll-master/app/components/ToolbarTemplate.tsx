import { Button } from 'primereact/button';
import { MouseEventHandler } from 'react';

export const LeftToolbarTemplate = (confirmDeleteSelected: MouseEventHandler<HTMLButtonElement> | undefined, selectedItems: string | any[]) => {
    return (
        <div className="flex flex-wrap gap-2">
            <Button label="New" icon="pi pi-plus" outlined />
            <Button label="Delete" icon="pi pi-trash" severity="danger" onClick={confirmDeleteSelected} disabled={!selectedItems || !selectedItems.length} />
        </div>
    );
};

export const RightToolbarTemplate = () => {
    return <Button label="Export" icon="pi pi-upload" className="p-button-help" outlined />;
};
