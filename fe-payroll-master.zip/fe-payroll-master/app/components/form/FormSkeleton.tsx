import { Skeleton } from 'primereact/skeleton';
import { classNames } from 'primereact/utils';

interface prop {
    show: boolean;
}

export default function FormSkeleteton(prop: prop) {
    const { show } = prop;
    return (
        <div className={`card ${!show ? 'hidden' : ''}`}>
            <div className="col-12">
                <div className="p-fluid formgrid grid">
                    <div className="field col-12 md:col-4">
                        <Skeleton height="2rem" className="mb-2" borderRadius="16px"></Skeleton>
                        <Skeleton height="5rem" className="mb-2" borderRadius="16px"></Skeleton>
                    </div>
                    <div className="field col-12 md:col-4">
                        <Skeleton height="2rem" className="mb-2" borderRadius="16px"></Skeleton>
                        <Skeleton height="5rem" className="mb-2" borderRadius="16px"></Skeleton>
                    </div>
                    <div className="field col-12 md:col-4">
                        <Skeleton height="2rem" className="mb-2" borderRadius="16px"></Skeleton>
                        <Skeleton height="5rem" className="mb-2" borderRadius="16px"></Skeleton>
                    </div>
                    <div className="field col-12 md:col-6">
                        <Skeleton height="2rem" className="mb-2" borderRadius="16px"></Skeleton>
                        <Skeleton height="5rem" className="mb-2" borderRadius="16px"></Skeleton>
                    </div>
                    <div className="field col-12 md:col-6">
                        <Skeleton height="2rem" className="mb-2" borderRadius="16px"></Skeleton>
                        <Skeleton height="5rem" className="mb-2" borderRadius="16px"></Skeleton>
                    </div>
                    <div className="field col-12 md:col-4">
                        <Skeleton height="2rem" className="mb-2" borderRadius="16px"></Skeleton>
                        <Skeleton height="5rem" className="mb-2" borderRadius="16px"></Skeleton>
                    </div>
                    <div className="field col-12 md:col-4">
                        <Skeleton height="2rem" className="mb-2" borderRadius="16px"></Skeleton>
                        <Skeleton height="5rem" className="mb-2" borderRadius="16px"></Skeleton>
                    </div>
                    <div className="field col-12 md:col-4">
                        <Skeleton height="2rem" className="mb-2" borderRadius="16px"></Skeleton>
                        <Skeleton height="5rem" className="mb-2" borderRadius="16px"></Skeleton>
                    </div>
                    <div className="field col-12 md:col-6">
                        <Skeleton height="2rem" className="mb-2" borderRadius="16px"></Skeleton>
                        <Skeleton height="5rem" className="mb-2" borderRadius="16px"></Skeleton>
                    </div>
                    <div className="field col-12 md:col-6">
                        <Skeleton height="2rem" className="mb-2" borderRadius="16px"></Skeleton>
                        <Skeleton height="5rem" className="mb-2" borderRadius="16px"></Skeleton>
                    </div>
                    <div className="field col-12 md:col-2">
                        <Skeleton height="3rem" width="14rem" className="mb-2" borderRadius="16px"></Skeleton>
                    </div>
                    <div className="field col-12 md:col-2">
                        <Skeleton height="3rem" width="14rem" className="mb-2" borderRadius="16px"></Skeleton>
                    </div>
                </div>
            </div>
        </div>
    );
}
