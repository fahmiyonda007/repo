import React from 'react';
import { Dropdown } from 'primereact/dropdown';
import { Paginator, PaginatorCurrentPageReportOptions, PaginatorPageChangeEvent, PaginatorPageLinksOptions, PaginatorPrevPageLinkOptions } from 'primereact/paginator';
import { Button } from 'primereact/button';
import { Ripple } from 'primereact/ripple';
import { classNames } from 'primereact/utils';

interface metaProps {
    first: number | undefined;
    rows: number | undefined;
    totalRecords: number | undefined;
    onPageChange: ((event: any) => void) | undefined;
    onRefresh?: (event: any) => void | undefined;
}

const PaginatorTemplate = (props: metaProps) => {
    const template = {
        layout: 'RowsPerPageDropdown CurrentPageReport FirstPageLink PrevPageLink PageLinks  NextPageLink LastPageLink ',
        PrevPageLink: (options: PaginatorPrevPageLinkOptions) => {
            return (
                <button type="button" className={classNames(options.className, 'border-round')} onClick={options.onClick} disabled={options.disabled}>
                    <span className="p-3">
                        <i className="pi pi-angle-left"></i>
                    </span>
                    <Ripple />
                </button>
            );
        },
        NextPageLink: (options: PaginatorPrevPageLinkOptions) => {
            return (
                <button type="button" className={classNames(options.className, 'border-round')} onClick={options.onClick} disabled={options.disabled}>
                    <span className="p-3">
                        <i className="pi pi-angle-right"></i>
                    </span>
                    <Ripple />
                </button>
            );
        },
        PageLinks: (options: PaginatorPageLinksOptions) => {
            if ((options.view.startPage === options.page && options.view.startPage !== 0) || (options.view.endPage === options.page && options.page + 1 !== options.totalPages)) {
                const className = classNames(options.className, { 'p-disabled': true });

                return (
                    <span className={className} style={{ userSelect: 'none' }}>
                        ...
                    </span>
                );
            }

            return (
                <button type="button" className={options.className} onClick={options.onClick}>
                    {options.page + 1}
                    <Ripple />
                </button>
            );
        },
        RowsPerPageDropdown: (options: { value: any; onChange: any }) => {
            const dropdownOptions = [
                { label: 5, value: 5 },
                { label: 10, value: 10 },
                { label: 20, value: 20 },
                { label: 30, value: 30 },
                { label: 'All', value: props.totalRecords }
            ];

            return (
                <React.Fragment>
                    <span className="mx-1" style={{ color: 'var(--text-color)', userSelect: 'none' }}>
                        {' '}
                    </span>
                    <Dropdown value={options.value} options={dropdownOptions} onChange={options.onChange} />
                </React.Fragment>
            );
        },
        CurrentPageReport: (options: PaginatorCurrentPageReportOptions) => {
            return (
                <span style={{ color: 'var(--text-color)', userSelect: 'none', width: '120px', textAlign: 'center' }}>
                    {!Number.isNaN(options.first) ? options.first : 0} - {!Number.isNaN(options.last) ? options.last : 0} of {options.totalRecords ? options.totalRecords : 0}
                </span>
            );
        }
    };

    const leftContent = props.onRefresh ? <Button type="button" onClick={props.onRefresh} icon="pi pi-refresh" severity="secondary" outlined /> : <div></div>;

    return <Paginator first={props.first} rows={props.rows} totalRecords={props.totalRecords} rowsPerPageOptions={[10, 20, 30]} template={template} onPageChange={props.onPageChange} leftContent={leftContent} />;
};

export default PaginatorTemplate;
