import { Button } from 'primereact/button';
import { Card } from 'primereact/card';
import { Skeleton } from 'primereact/skeleton';
import { Toast } from 'primereact/toast';
import { useEffect, useRef, useState } from 'react';
import { useAuth } from '../../layout/context/AuthContext';
import { QuoteService } from '../services/QuoteService';

export default function RandomQuoteComponent() {
    const [quote, setQuote] = useState<Model.Quote | null>();
    const [hidden, setHidden] = useState(false);
    const [check, setCheck] = useState(0);
    const toast = useRef<Toast>(null);
    const { user } = useAuth();

    const handleRefreshQuote = () => {
        setQuote(null);
        setHidden(false);
        setCheck(0);
    };

    useEffect(() => {
        const id = setInterval(() => {
            setQuote(null);
            setHidden(false);
            setCheck(check + 1);
        }, 15000);
        return () => clearInterval(id);
    }, [check]);

    useEffect(() => {
        if (!quote) {
            QuoteService.getRandomQuote({ token: user?.token })
                .then((data) => {
                    setQuote(data);
                    setHidden(true);
                })
                .catch((c) => {
                    if (c) {
                        toast.current?.show({ severity: 'error', summary: '', detail: 'Failed to fetch quote!', life: 30000 });
                    }
                });
        }
    }, [hidden, quote, user]);

    const footer = (
        <div className="flex justify-content-start">
            <Button icon="pi pi-refresh" rounded text severity="info" aria-label="Cancel" size="large" loading={!hidden} onClick={handleRefreshQuote} />
        </div>
    );

    return (
        <div className="card">
            <Toast ref={toast}></Toast>
            <Card title="" footer={footer}>
                <p>
                    👋 Welcome back <b>{user?.firstName ? user?.firstName : user?.name}</b>
                    {user?.gender?.toLowerCase() === 'female' ? ' 💕' : ' 😎'}
                </p>
                <Skeleton width="100%" height="60px" className="mb-2" hidden={hidden}></Skeleton>
                <Skeleton width="10rem" className="mb-2" hidden={hidden}></Skeleton>
                {quote && (
                    <>
                        <h5>
                            <blockquote>{quote?.quote}</blockquote>
                        </h5>
                        <p className="mt-2">
                            <i>- {quote?.author}</i>
                        </p>
                    </>
                )}
            </Card>
        </div>
    );
}
