/* eslint-disable @next/next/no-img-element */

import React from 'react';
import { useAuth } from './context/AuthContext';

const AppFooter = () => {
    const yearFirst = 2023;
    const year = new Date().getFullYear();
    const { user } = useAuth();

    return (
        <>
            {user ? (
                <div className="layout-footer">
                    <span className="font-medium ml-1">PT Bank Hibank Indonesia &copy;</span>
                    <span className="ml-1">
                        {' '}
                        {yearFirst} {yearFirst == year ? '' : ' - ' + year}
                    </span>
                    .
                </div>
            ) : null}
        </>
    );
};

export default AppFooter;
