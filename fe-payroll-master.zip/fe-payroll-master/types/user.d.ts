import { MetaModel } from "./metamodel";
import { Role } from "./role";

declare namespace Model {
    type User = {
        code: number;
        message: string;
        id: number;
        firstName: string;
        lastName: string;
        gender: string;
        email: string;
        phone: string;
        birthDate: Date;
        image: string;
        roles?: Role[];
        rowInfo: MetaModel;
    };
}

export interface User extends UserGoogle {
    id?: string;
    email?: string;
    gender?: string;
    genderJson?: {
        label?: string;
    };
    birthDate?: Date;
    firstName?: string;
    phone?: string;
    lastName?: string;
    email?: string;
    image?: string;
    exp?: number;
    expires?: Date;
    token?: string;
    roles?: Role[];
}

export interface UserGoogle {
    sub?: string;
    name?: string;
    givenName?: string;
    familyName?: string;
    picture?: string;
    email?: string;
    emailVerified?: boolean;
    token?: string;
}
