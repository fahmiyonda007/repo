import { Menu } from "primereact/menu";
import { JsonResponse, MetaModel } from "./metamodel";

export interface MonitoringPayroll extends JsonResponse {
    id: number;
    noBatch: string;
    keterangan: string;
    totalRekening: number;
    totalNominal: number;
    noPrint: string;
};