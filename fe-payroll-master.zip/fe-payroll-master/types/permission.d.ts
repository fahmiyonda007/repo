import { JsonResponse, MetaModel } from "./metamodel";

export interface Permission extends JsonResponse {
    id: number;
    permissionName: string;
    rowInfo?: MetaModel;
};