import { Menu } from "primereact/menu";
import { JsonResponse, MetaModel } from "./metamodel";

export interface CompanyOutsource extends JsonResponse {
    id: number;
    outsourceName: string;
    outsourceCode: string;
    rowInfo?: MetaModel;
};