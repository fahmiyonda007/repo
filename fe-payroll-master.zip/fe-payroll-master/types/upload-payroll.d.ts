import { JsonResponse, MetaModel } from './metamodel';

export interface UploadPayroll extends JsonResponse {
    id: number;
    rowNumber: number;
    bankId: string;
    via: string;
    noRekeningTujuan: string;
    namaNasabahTujuan: string;
    nominal: string;
    reference: string;
    keterangan: string;
    alamat: string;
    kodeKota: string;
    filename: string;
    rowInfo?: MetaModel;
}

export interface UploadRequest {
    filename: string;
    data: UploadFormat[];
}

export interface UploadResponse extends JsonResponse {
    data: UploadPayroll[];
    listError: {
        dupeReff: UploadPayroll[];
        dupeReffCount: number;
        reffExists: UploadPayroll[];
        reffExistsCount: number;
        reffMoreThan15: UploadPayroll[];
        reffMoreThan15Count: number;
        nominalNotValid: UploadPayroll[];
        nominalNotValidCount: number;
        bankNotValid: UploadPayroll[];
        bankNotValidCount: number;
        companyNotValid: UploadPayroll[];
        companyNotValidCount: number;
        rekeningNotValid: UploadPayroll[];
        rekeningNotValidCount: number;
        penerimaNotMatch: UploadPayroll[];
        penerimaNotMatchCount: number;
        listErrorCount: number;
    };
}

export interface UploadDataSection {
    data: UploadPayroll[];
}

export interface UploadFormat {
    CODE_REFF: string;
    KET: string;
    REKENING: string; 
    NASABAH: string; 
    NOMINAL: string; 
    REFF: string; 
    BERITA: string;

}
