import { Menu } from "primereact/menu";
import { JsonResponse, MetaModel } from "./metamodel";

export interface PrintPayroll extends JsonResponse {
    id: number;
    noBatch: string;
    keterangan: string;
    bebanRekening: string;
    totalRekening: number;
    totalNominal: number;
    company: string;
    noPrint: string;
    valueDate: string;
};