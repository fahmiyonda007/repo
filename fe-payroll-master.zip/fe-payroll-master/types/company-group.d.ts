import { Menu } from "primereact/menu";
import { JsonResponse, MetaModel } from "./metamodel";

export interface CompanyGroup extends JsonResponse {
    id: number;
    companyCode: string;
    companyName: string;
    bebanRekening: string;
    cmsCompanyId: number;
    rowInfo?: MetaModel;
};