declare namespace Model {
    type Quote = {
        id: number;
        quote: string;
        author: string;
    };
}
