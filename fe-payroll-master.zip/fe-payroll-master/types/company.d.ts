import { Menu } from "primereact/menu";
import { JsonResponse, MetaModel } from "./metamodel";

export interface Company extends JsonResponse {
    id: number;
    companyName: string;
    cmsType: string;
    coAccountNo: string;
    isSewa: boolean;
    rowInfo?: MetaModel;
};