export const appName = process.env.NEXT_PUBLIC_APP_NAME!;
export const appUrl = process.env.NEXT_PUBLIC_APP_URL!;
export const apiUrl = process.env.NEXT_PUBLIC_API_URL!;
export const appLifetime = parseInt(process.env.NEXT_PUBLIC_APP_LIFETIME!);
export const expiresInMins = parseInt(process.env.NEXT_PUBLIC_API_DUMMY_EXPIRES_IN_MINS!);
export const cookieAuthName = 'auth.token';
export const cookieAuthNameGoogle = 'google.auth.token';
export const appThrottle = 500;
