'use client';
import ApplicationList from '../components/ApplicationList';
import PrivateRoute from '../components/PrivateRoute';
import RandomQuoteComponent from '../components/RandomQuote';

const Dashboard = () => {
    return (
        <PrivateRoute>
            <RandomQuoteComponent />
            <ApplicationList />
        </PrivateRoute>
    );
};

export default Dashboard;
