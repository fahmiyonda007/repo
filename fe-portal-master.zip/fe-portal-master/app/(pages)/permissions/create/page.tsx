'use client';

import PermissionFormPage from '../forms/form';

const PermissionCreatePage = () => {
    return <PermissionFormPage />;
};

export default PermissionCreatePage;
