import { ColumnProps } from 'primereact/column';
import { Permission } from '../../../../types/permission';
import { rowinfo } from '../../../components/rowinfo';

const columns: ColumnProps[] = [
    {
        field: 'name',
        header: 'Permission Name',
        filterField: 'name',
        filterPlaceholder: 'Search by permission name',
        sortable: false,
        filter: false,
        frozen: false,
        body: (rowData: Permission) => {
            return <div>{rowData.permissionName}</div>;
        },
        style: { width: '5rem' }
    }
];

export const permissionColumns = [...columns, ...rowinfo];
