import { FilterMatchMode } from 'primereact/api';

export const permissionFilter = {
    global: { value: null, matchMode: FilterMatchMode.CONTAINS }
};
