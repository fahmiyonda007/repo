'use client';

import MenuFormPage from '../forms/form';

const MenuCreatePage = () => {
    return <MenuFormPage />;
};

export default MenuCreatePage;
