import { format } from 'date-fns';
import { useFormik } from 'formik';
import { useRouter } from 'next/navigation';
import { Button } from 'primereact/button';
import { Chip } from 'primereact/chip';
import { Dropdown, DropdownChangeEvent } from 'primereact/dropdown';
import { Fieldset } from 'primereact/fieldset';
import { useMountEffect } from 'primereact/hooks';
import { InputNumber, InputNumberValueChangeEvent } from 'primereact/inputnumber';
import { InputText } from 'primereact/inputtext';
import { Message } from 'primereact/message';
import { RadioButton, RadioButtonChangeEvent } from 'primereact/radiobutton';
import { Toast } from 'primereact/toast';
import { classNames } from 'primereact/utils';
import React, { useContext, useRef, useState } from 'react';
import { useAuth } from '../../../../layout/context/AuthContext';
import { LayoutContext } from '../../../../layout/context/layoutcontext';
import { Menu } from '../../../../types/menu';
import PrivateRoute from '../../../components/PrivateRoute';
import { ApplicationService } from '../../../services/ApplicationService';
import { MenuService } from '../../../services/MenuService';
import { MenuSchema } from './validation';

interface metaProps {
    data?: Menu;
}

const MenuFormPage = (props: metaProps) => {
    const toast = useRef<Toast>(null);
    const { data } = props;
    const [btnLoading, setBtnLoading] = useState(false);
    const { setMessage } = useContext(LayoutContext);
    const router = useRouter();
    const [menuParent, setMenuParent] = useState<any[]>([]);
    const { user } = useAuth();
    const [applications, setApplications] = useState<{ id: number; applicationCode: string; applicationName: string }[]>();

    useMountEffect(() => {
        ApplicationService.getApplications({ limit: 0, skip: 0, search: '' }, user?.token!).then((res) => {
            //@ts-ignore
            setApplications(res.data);
        });

        if (data) {
            MenuService.getParentMenu({ level: data.menuLevel - 1, application: data.application?.applicationName, token: user?.token! }).then((res: any) => {
                if (!res.message) {
                    const dtParent = res.map((v: any) => {
                        return { id: v.id, menuName: v.menuName };
                    });
                    setMenuParent(dtParent);
                } else {
                    setMenuParent([]);
                }
            });
        }
    });

    const legendTemplate = (
        <div className="flex align-items-center text-primary">
            <span className="pi pi-plus mr-2"></span>
            <span className="font-bold text-lg">Form {!data?.menuName ? 'Create' : `Edit`}</span>
        </div>
    );

    const formik = useFormik({
        initialValues: {
            id: data?.id || 0,
            menuType: data?.menuRoute ? 'Item' : 'Group',
            menuName: data?.menuName || '',
            menuRoute: data?.menuRoute || '',
            menuLevel: data?.menuLevel || 0,
            icon: data?.icon || '',
            application: data?.application || { id: 0, applicationCode: '', applicationName: '' },
            parent: data?.parent || { id: 0, menuName: '' }
        },
        enableReinitialize: true,
        validationSchema: MenuSchema,
        onSubmit: (form: Menu) => {
            setBtnLoading(true);
            form.parentId = form.parent?.id;
            form.applicationId = form.application?.id;
            form.orderId = data?.orderId;
            if (!data) {
                MenuService.addMenu(form, user?.token!)
                    .then(async (res) => {
                        const data = (await res.json()) as unknown as Menu;
                        if (res.ok) {
                            setMessage({
                                sticky: false,
                                life: 5000,
                                severity: 'success',
                                content: (
                                    <React.Fragment>
                                        <i className="pi pi-check"></i>
                                        <div className="ml-2">{`Menu ${data.menuName} has been created`}</div>
                                    </React.Fragment>
                                ),
                                closable: true
                            });
                            router.push(`/menus?application=${data.applicationId}`);
                        } else {
                            toast.current?.show({ severity: 'error', summary: 'Error', detail: data.message });
                        }
                    })
                    .catch((ex) => {
                        toast.current?.show({ severity: 'error', summary: 'Error', detail: 'Failed!' });
                    })
                    .finally(() => {
                        setBtnLoading(false);
                    });
            } else {
                MenuService.updateMenu(data?.id, form, user?.token!)
                    .then(async (res) => {
                        const data = (await res.json()) as unknown as Menu;
                        if (res.ok) {
                            setMessage({
                                sticky: false,
                                life: 5000,
                                severity: 'success',
                                content: (
                                    <React.Fragment>
                                        <i className="pi pi-check"></i>
                                        <div className="ml-2">{`Menu ${data.menuName} has been updated`}</div>
                                    </React.Fragment>
                                ),
                                closable: true
                            });
                            router.push(`/menus?application=${data.applicationId}`);
                        } else {
                            toast.current?.show({ severity: 'error', summary: 'Error', detail: data.message });
                        }
                    })
                    .catch((ex) => {
                        toast.current?.show({ severity: 'error', summary: 'Error', detail: 'Failed!' });
                    })
                    .finally(() => {
                        setBtnLoading(false);
                    });
            }
        }
    });
    const { errors, touched, values, handleChange, handleSubmit } = formik;

    //@ts-ignore
    const isFormFieldInvalid = (name) => !!(touched[name] && errors[name]);
    const getFormErrorMessage = (name: any) => {
        return isFormFieldInvalid(name) ? (
            <>
                {/* @ts-ignore */}
                <Message severity="error" text={errors[name]} className="justify-content-start" />
            </>
        ) : (
            ''
        );
    };

    return (
        <PrivateRoute>
            <form onSubmit={handleSubmit}>
                <div className="grid">
                    <Toast ref={toast}></Toast>
                    <div className={classNames(!data ? 'col-12' : 'col-8')}>
                        <Fieldset legend={legendTemplate}>
                            <div className="col-12">
                                <div className="p-fluid formgrid grid">
                                    <div className="field col-12 md:col-12">
                                        <label htmlFor="menuType">Menu Type</label>
                                        <div className="flex flex-wrap gap-3">
                                            <div className="flex align-items-center">
                                                <RadioButton
                                                    inputId="menuType1"
                                                    name="menuType"
                                                    value="Group"
                                                    disabled={data ? true : false}
                                                    onChange={(e: RadioButtonChangeEvent) => {
                                                        formik.setFieldValue('menuType', e.value);
                                                    }}
                                                    checked={values.menuType === 'Group'}
                                                />
                                                <label htmlFor="menuType1" className="ml-2">
                                                    Group
                                                </label>
                                            </div>
                                            <div className="flex align-items-center">
                                                <RadioButton
                                                    inputId="menuType2"
                                                    name="menuType"
                                                    value="Item"
                                                    disabled={data ? true : false}
                                                    onChange={(e: RadioButtonChangeEvent) => {
                                                        formik.setFieldValue('menuType', e.value);
                                                    }}
                                                    checked={values.menuType === 'Item'}
                                                />
                                                <label htmlFor="menuType2" className="ml-2">
                                                    Item
                                                </label>
                                            </div>
                                        </div>
                                        {getFormErrorMessage('application')}
                                    </div>
                                    <div className="field col-12 md:col-4">
                                        <label htmlFor="application">Application</label>
                                        <Dropdown
                                            value={values.application}
                                            onChange={(e: DropdownChangeEvent) => {
                                                formik.setFieldValue('application', e.value);
                                                MenuService.getParentMenu({ level: values.menuLevel - 1, application: e.value.applicationName, token: user?.token! }).then((res: any) => {
                                                    if (!res.message) {
                                                        const dt = res.map((v: any) => {
                                                            return { id: v.id, menuName: v.menuName };
                                                        });
                                                        setMenuParent(dt);
                                                    } else {
                                                        setMenuParent([]);
                                                    }
                                                });
                                            }}
                                            options={applications}
                                            optionLabel="applicationName"
                                            placeholder="Select a Application"
                                            className={classNames({ 'p-invalid': isFormFieldInvalid('application') })}
                                            virtualScrollerOptions={{ itemSize: 38 }}
                                            filter
                                            showClear
                                        />
                                        {getFormErrorMessage('application')}
                                    </div>
                                    <div className="field col-12 md:col-4">
                                        <label htmlFor="menuName">Name</label>
                                        <InputText id="menuName" type="text" value={values.menuName} onChange={handleChange} className={classNames({ 'p-invalid': isFormFieldInvalid('menuName') })} />
                                        {getFormErrorMessage('menuName')}
                                    </div>
                                    <div className={classNames({ 'field col-12 md:col-4': true }, { hidden: values.menuType === 'Group' })}>
                                        <label htmlFor="menuRoute">Route</label>
                                        <InputText id="menuRoute" type="text" value={values.menuRoute} onChange={handleChange} className={classNames({ 'p-invalid': isFormFieldInvalid('menuRoute') })} />
                                        {getFormErrorMessage('menuRoute')}
                                    </div>
                                    <div className={classNames({ 'field col-12 md:col-4': true }, { hidden: values.menuType === 'Group' })}>
                                        <label htmlFor="icon">Prime Icon</label>
                                        <InputText id="icon" type="text" value={values.icon} onChange={handleChange} className={classNames({ 'p-invalid': isFormFieldInvalid('icon') })} />
                                        {getFormErrorMessage('icon')}
                                    </div>
                                    <div className="field col-12 md:col-4">
                                        <label htmlFor="menuLevel">Level</label>
                                        <InputNumber
                                            id="menuLevel"
                                            showButtons
                                            min={0}
                                            value={values.menuLevel}
                                            onValueChange={(e: InputNumberValueChangeEvent) => {
                                                formik.setFieldValue('menuLevel', e.value);
                                                MenuService.getParentMenu({ level: e.value! - 1, application: values.application?.applicationName, token: user?.token! }).then((res: any) => {
                                                    if (!res.message) {
                                                        const dt = res.map((v: any) => {
                                                            return { id: v.id, menuName: v.menuName };
                                                        });
                                                        setMenuParent(dt);
                                                    } else {
                                                        setMenuParent([]);
                                                    }
                                                });
                                            }}
                                            className={classNames({ 'p-invalid': isFormFieldInvalid('menuLevel') })}
                                        />
                                        {getFormErrorMessage('menuLevel')}
                                    </div>
                                    <div className="field col-12 md:col-4">
                                        <label htmlFor="parent">Parent</label>
                                        <Dropdown
                                            value={values.parent}
                                            onChange={(e: DropdownChangeEvent) => {
                                                formik.setFieldValue('parent', e.value);
                                            }}
                                            options={menuParent}
                                            optionLabel="menuName"
                                            placeholder="Select a Parent"
                                            className={classNames({ 'p-invalid': isFormFieldInvalid('parent') })}
                                            virtualScrollerOptions={{ itemSize: 38 }}
                                            filter
                                            showClear
                                        />
                                        {getFormErrorMessage('parent')}
                                    </div>
                                </div>
                            </div>
                            <div className="col-12">
                                <div className="p-fluid formgrid grid flex flex-wrap gap-2">
                                    <div className="field">
                                        <Button onClick={() => router.push(`/menus?application=${data?.applicationId}`)} type="button" label="Cancel" icon="pi pi-times" severity="danger" loading={btnLoading} outlined></Button>
                                    </div>

                                    <div className="field">
                                        <Button type="submit" label={data?.id ? 'Update' : 'Save'} icon="pi pi-check" severity="info" loading={btnLoading}></Button>
                                    </div>
                                </div>
                            </div>
                        </Fieldset>
                    </div>
                    <div className={classNames('col-4', !data ? 'hidden' : '')}>
                        <Fieldset legend="Information">
                            <div className="card flex flex-wrap gap-2">
                                <Chip label={`Created by: ${data?.rowInfo?.createdBy}`} />
                                <Chip label={`Created at: ${data?.rowInfo?.createdAt?.Time! ? format(new Date(data?.rowInfo?.createdAt?.Time!), 'dd-MM-yyyy') : null}`} />
                                <Chip label={`Updated by: ${data?.rowInfo?.updatedBy}`} />
                                <Chip label={`Updated at: ${data?.rowInfo?.updatedAt?.Time! ? format(new Date(data?.rowInfo?.updatedAt?.Time!), 'dd-MM-yyyy') : null}`} />
                            </div>
                        </Fieldset>
                    </div>
                </div>
            </form>
        </PrivateRoute>
    );
};

export default MenuFormPage;
