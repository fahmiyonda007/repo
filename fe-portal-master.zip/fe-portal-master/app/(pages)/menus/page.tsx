'use client';

import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { Button } from 'primereact/button';
import { ContextMenu } from 'primereact/contextmenu';
import { Dropdown, DropdownChangeEvent } from 'primereact/dropdown';
import { useMountEffect } from 'primereact/hooks';
import { Messages } from 'primereact/messages';
import { Toast } from 'primereact/toast';
import { Tree, TreeDragDropEvent, TreeExpandedKeysType, TreeNodeTemplateOptions } from 'primereact/tree';
import { TreeNode } from 'primereact/treenode';
import React, { useContext, useEffect, useRef, useState } from 'react';
import { useAuth } from '../../../layout/context/AuthContext';
import { LayoutContext } from '../../../layout/context/layoutcontext';
import { Application } from '../../../types/application';
import { Menu } from '../../../types/menu';
import { deleteItemDialogFooter } from '../../components/DeleteDialogFooter';
import DeleteDialog from '../../components/DeleteDialogTemplate';
import PrivateRoute from '../../components/PrivateRoute';
import { ApplicationService } from '../../services/ApplicationService';
import { MenuService } from '../../services/MenuService';

export default function ReorderMenus() {
    const [nodes, setNodes] = useState<TreeNode[]>([]);
    const [expandedKeys, setExpandedKeys] = useState<TreeExpandedKeysType>({});
    const [selectedApplication, setSelectedApplication] = useState<Application | undefined | null>(null);
    const [applications, setApplications] = useState<Application[]>([]);
    const [selectedNodeKey, setSelectedNodeKey] = useState<any>(null);
    const [selectedNode, setSelectedNode] = useState<TreeNode>();
    const { user } = useAuth();
    const cm = useRef<ContextMenu>(null);
    const toast = useRef<Toast>(null);
    const router = useRouter();
    const [deleteDataDialog, setDeleteDataDialog] = useState<boolean>(false);
    const [refreshTree, setRefreshTree] = useState<boolean>(false);
    const [loading, setLoading] = useState<boolean>(false);
    const msgs = useRef<Messages>(null);
    const msgsAnnounce = useRef<Messages>(null);
    const {
        layoutConfig: { message },
        clearMessage
    } = useContext(LayoutContext);
    const searchParams = useSearchParams();

    const menu = [
        {
            label: 'Edit',
            icon: 'pi pi-pencil',
            command: () => {
                router.push(`/menus/${selectedNode?.id}`);
            }
        },
        {
            label: 'Delete',
            icon: 'pi pi-trash',
            command: () => {
                setDeleteDataDialog(true);
            }
        }
    ];

    const expandAll = () => {
        let _expandedKeys = {};

        for (let node of nodes) {
            expandNode(node, _expandedKeys);
        }

        setExpandedKeys(_expandedKeys);
    };

    const collapseAll = () => {
        setExpandedKeys({});
    };

    const expandNode = (node: TreeNode, _expandedKeys: TreeExpandedKeysType) => {
        if (node.children && node.children.length) {
            //@ts-ignore
            _expandedKeys[node.key] = true;

            for (let child of node.children) {
                expandNode(child, _expandedKeys);
            }
        }
    };

    const nodeTemplate = (node: TreeNode, options: TreeNodeTemplateOptions) => {
        let label = <b>{node.label}</b>;

        if (node.icon != '') {
            label = <span className="hover:text-primary">{node.label}</span>;
        }

        return <span className={options.className}>{label}</span>;
    };

    const hideDeleteDataDialog = () => {
        setDeleteDataDialog(false);
    };

    const deleteData = () => {
        setDeleteDataDialog(false);
        MenuService.deleteMenu(parseInt(selectedNode?.id!), user?.token!).then((res) => {
            if (res) {
                toast.current?.show({ severity: 'success', summary: 'Delete', detail: 'Successfully' });
                setRefreshTree(true);
            }
        });
    };

    const deleteDataDialogFooter = deleteItemDialogFooter(hideDeleteDataDialog, deleteData);

    useEffect(() => {
        if (selectedApplication?.id) {
            MenuService.getMenubyApplicationId({ applicationId: selectedApplication.id }).then((res) => {
                if (res) {
                    setNodes(res);
                }
                setRefreshTree(false);
                setLoading(false);
            });
        } else {
            setNodes([]);
        }
    }, [selectedApplication, refreshTree]);

    useEffect(() => {
        ApplicationService.getApplications({ limit: 0, skip: 0, search: '' }, user?.token!).then((res) => {
            //@ts-ignore
            const data: Application[] = res.data;
            setApplications(data);
            if (data) {
                setSelectedApplication(data.find((x) => x.id === parseInt(searchParams.get('application')!)));
            }
        });

        msgsAnnounce.current?.clear();
        msgsAnnounce.current?.show([
            {
                sticky: true,
                severity: 'info',
                content: (
                    <React.Fragment>
                        <ul>
                            <li>
                                Drag and drop menu{' '}
                                <b>
                                    <i>(you can only move menu items, not the parent item)</i>
                                </b>
                            </li>
                            <li>
                                Right click for context menu{' '}
                                <b>
                                    <i>(Edit & Delete)</i>
                                </b>
                            </li>
                        </ul>
                    </React.Fragment>
                ),
                closable: false
            }
        ]);

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [user?.token]);

    useMountEffect(() => {
        clearMessage();

        msgs.current?.clear();
        if (message) {
            msgs.current?.show(message);
        }
    });

    return (
        <PrivateRoute>
            <Toast ref={toast} />
            <Messages ref={msgs} />
            <div className="card flex flex-column">
                <div className="field md:col-12">
                    <label htmlFor="application">Application </label>
                    <Dropdown
                        value={selectedApplication}
                        onChange={(e: DropdownChangeEvent) => {
                            setSelectedApplication(e.value);
                        }}
                        options={applications}
                        optionLabel="applicationName"
                        placeholder="Select a Application"
                        virtualScrollerOptions={{ itemSize: 38 }}
                        className="w-full"
                        filter
                        showClear
                    />
                    <small id="username-help">Enter application first for display menus below.</small>
                </div>
                <div className="flex justify-content-between">
                    <div className="flex gap-2 ml-2 mb-2">
                        <Link href={'/menus/create'}>
                            <Button label="New" icon="pi pi-plus" outlined></Button>
                        </Link>
                    </div>

                    <div className="flex gap-2">
                        <Button type="button" icon="pi pi-plus" link label="Expand All" onClick={expandAll} />
                        <Button type="button" icon="pi pi-minus" link label="Collapse All" onClick={collapseAll} />
                    </div>
                </div>

                <ContextMenu model={menu} ref={cm} />

                <Messages ref={msgsAnnounce} />
                <div className="flex flex-column">
                    <Tree
                        loading={loading}
                        value={nodes}
                        filter
                        filterMode="lenient"
                        filterPlaceholder="Search ..."
                        expandedKeys={expandedKeys}
                        dragdropScope="demo"
                        nodeTemplate={nodeTemplate}
                        onToggle={(e) => setExpandedKeys(e.value)}
                        onDragDrop={(e: TreeDragDropEvent) => {
                            setLoading(true);
                            let draggable = false;
                            const drop = e.dropNode ? !e.dropNode.icon : e.dropNode == null;

                            if (e.dragNode.icon && drop) {
                                draggable = true;
                            }

                            if (draggable) {
                                MenuService.updateOrdering(selectedApplication?.id!, e.dragNode, e.dropIndex, e.dropNode, user?.token!)
                                    .then(async (res) => {
                                        const data = (await res.json()) as unknown as Menu;
                                        if (res.ok) {
                                            setRefreshTree(true);
                                            toast.current?.show({ severity: 'success', summary: 'Moved', detail: 'Successfully' });
                                        } else {
                                            toast.current?.show({ severity: 'error', summary: 'Error', detail: data.message });
                                        }
                                    })
                                    .catch((ex) => {
                                        toast.current?.show({ severity: 'error', summary: 'Error', detail: 'Failed!' });
                                    })
                                    .finally(() => {
                                        setLoading(false);
                                    });
                            } else {
                                toast.current?.show({ severity: 'error', summary: 'Error', detail: 'Can`t move this item' });
                                setLoading(false);
                            }
                        }}
                        contextMenuSelectionKey={selectedNodeKey}
                        onContextMenuSelectionChange={(e) => {
                            setSelectedNodeKey(e.value);
                        }}
                        onContextMenu={(e) => {
                            setSelectedNode(e.node);
                            return cm.current?.show(e.originalEvent);
                        }}
                        className="w-full"
                    />
                </div>
            </div>
            <DeleteDialog deleteItemDialog={deleteDataDialog} deleteItemDialogFooter={deleteDataDialogFooter} hideDeleteItemDialog={hideDeleteDataDialog} item={selectedNode} name={selectedNode?.data} />
        </PrivateRoute>
    );
}
