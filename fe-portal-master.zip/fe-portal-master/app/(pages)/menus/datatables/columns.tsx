import { classNames } from 'primereact/utils';
import { Menu } from '../../../../types/menu';
import { rowinfo } from '../../../components/rowinfo';
import { ColumnProps } from 'primereact/column';

const columns: ColumnProps[] = [
    {
        header: '',
        frozen: true
    },
    {
        field: 'menuName',
        header: 'Name',
        filterField: 'menuName',
        filterPlaceholder: 'Search by menu name',
        sortable: false,
        filter: false,
        showFilterMenu: false,
        frozen: true
    },
    {
        field: 'menuRoute',
        header: 'Route',
        filterField: 'menuRoute',
        filterPlaceholder: 'Search by menu route',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'menuLevel',
        header: 'Level',
        filterField: 'menuLevel',
        filterPlaceholder: 'Search by menu level',
        sortable: false,
        filter: false,
        frozen: false,
        body: (rowData: Menu) => {
            const ageClassName = classNames('border-circle w-2rem h-2rem inline-flex font-bold justify-content-center align-items-center text-sm bg-teal-100 text-teal-900');
            return <div className={ageClassName}>{rowData.menuLevel}</div>;
        }
    },
    {
        field: 'icon',
        header: 'Icon',
        filterField: 'icon',
        filterPlaceholder: 'Search by icon',
        sortable: false,
        filter: false,
        frozen: false,
        body: (rowData: Menu) => {
            return (
                <div>
                    <i className={`${rowData.icon}`}></i>
                </div>
            );
        }
    },
    {
        field: 'orderId',
        header: 'Order Id',
        filterField: 'orderId',
        filterPlaceholder: 'Search by order id',
        sortable: true,
        filter: false,
        frozen: false
    },
    {
        field: 'parentId',
        header: 'Parent Id',
        filterField: 'parentId',
        filterPlaceholder: 'Search by parent id',
        sortable: false,
        filter: false,
        frozen: false
    }
];

export const menuColumns = [...columns, ...rowinfo];
