import { FilterMatchMode } from 'primereact/api';

export const menuFilter = {
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    menuName: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    applicationName: { value: null, matchMode: FilterMatchMode.STARTS_WITH }
};
