'use client';

import { useFormik } from 'formik';
import Link from 'next/link';
import { Button } from 'primereact/button';
import { Divider } from 'primereact/divider';
import { Image } from 'primereact/image';
import { Message } from 'primereact/message';
import { OrganizationChart } from 'primereact/organizationchart';
import { TabPanel, TabView } from 'primereact/tabview';
import { Toast } from 'primereact/toast';
import { useRef, useState } from 'react';
import { useAuth } from '../../../layout/context/AuthContext';
import PrivateRoute from '../../components/PrivateRoute';
import { UserService } from '../../services/UserService';
import { changePasswordSchema } from '../users/forms/validation';

const UserPage = () => {
    const toast = useRef<Toast>(null);
    const { user, logout } = useAuth();

    const [data] = useState([
        {
            expanded: true,
            type: 'person',
            style: { borderRadius: '12px' },
            data: {
                image: 'https://primefaces.org/cdn/primereact/images/avatar/amyelsner.png',
                name: 'Amy Elsner',
                title: 'CEO'
            },
            children: [
                {
                    expanded: true,
                    type: 'person',
                    style: { borderRadius: '12px' },
                    data: {
                        image: 'https://primefaces.org/cdn/primereact/images/avatar/annafali.png',
                        name: 'Anna Fali',
                        title: 'CMO'
                    },
                    children: [
                        {
                            label: 'Sales',
                            style: { borderRadius: '12px' }
                        },
                        {
                            label: 'Marketing',
                            style: { borderRadius: '12px' }
                        }
                    ]
                },
                {
                    expanded: true,
                    type: 'person',
                    style: { borderRadius: '12px' },
                    data: {
                        image: 'https://primefaces.org/cdn/primereact/images/avatar/stephenshaw.png',
                        name: 'Stephen Shaw',
                        title: 'CTO'
                    },
                    children: [
                        {
                            label: 'Development',
                            className: 'bg-purple-500 text-white',
                            style: { borderRadius: '12px' }
                        },
                        {
                            label: 'UI/UX Design',
                            style: { borderRadius: '12px' }
                        }
                    ]
                }
            ]
        }
    ]);

    const nodeTemplate = (node: any) => {
        if (node.type === 'person') {
            return (
                <div className="flex flex-column">
                    <div className="flex flex-column align-items-center">
                        <img alt={node.data.name} src={node.data.image} className="mb-3 w-3rem h-3rem" />
                        <span className="font-bold mb-2">{node.data.name}</span>
                        <span>{node.data.title}</span>
                    </div>
                </div>
            );
        }

        return node.label;
    };

    const [btnLoading, setBtnLoading] = useState(false);
    const formik = useFormik({
        initialValues: {
            oldPassword: null,
            newPassword: null,
            passwordConfirmation: null
        },
        enableReinitialize: true,
        validationSchema: changePasswordSchema,
        onSubmit: (data: any) => {
            setBtnLoading(true);

            //! sample api change password
            UserService.getUser({ id: user?.id, token: user?.token })
                .then((res) => {
                    if (res) {
                        logout({ severity: 'success', summary: 'Change Password Success', detail: 'Please re-login with new password', life: 10000 });
                    }
                })
                .catch((ex) => {
                    toast.current?.show({ severity: 'error', summary: 'Error', detail: 'Failed!' });
                })
                .finally(() => {
                    setBtnLoading(false);
                });
        }
    });
    const { errors, touched, values, handleChange, handleSubmit } = formik;

    //@ts-ignore
    const isFormFieldInvalid = (name) => !!(touched[name] && errors[name]);
    const getFormErrorMessage = (name: any) => {
        return isFormFieldInvalid(name) ? (
            <>
                {/* @ts-ignore */}
                <Message severity="error" text={errors[name]} className="justify-content-start" />
            </>
        ) : (
            ''
        );
    };

    return (
        <PrivateRoute>
            <Toast ref={toast}></Toast>
            <div className="grid">
                <div className="col-3">
                    <div className="card">
                        <div className="col-12 text-center">
                            <Image width="100%" src={user?.image} alt="Image" loading="lazy" preview />
                            <Divider />
                            <span className="text-900 font-medium text-3xl">{user?.name}</span>
                        </div>
                        <div className="col-12">
                            <p>
                                <i className="pi pi-google"></i>
                                <span className="text-900 font-medium text-xl">&nbsp;&nbsp; {user?.email}</span>
                            </p>
                        </div>
                        <Divider />
                        <Link href={`https://myaccount.google.com`} target="_blank" className="w-full">
                            <Button className="bg-gray-100 hover:bg-primary-100 border-gray-700 text-teal-900 justify-content-center align-items-center w-full">
                                <img
                                    alt="logo"
                                    src="https://fonts.gstatic.com/s/i/productlogos/googleg/v6/24px.svg
"
                                ></img>
                                <span> &nbsp; Google Account</span>
                            </Button>
                        </Link>
                    </div>
                </div>
                <div className="col-9">
                    <div className="card">
                        <TabView>
                            <TabPanel header="About" leftIcon="pi pi-user mr-2">
                                <p className="m-0">
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                                    commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit
                                    anim id est laborum.
                                </p>
                                <p>
                                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Rem placeat temporibus ut! Aspernatur, ex maiores. Laborum, id. Autem minima consectetur, dolorum sit provident voluptatum dicta neque ipsa at facilis saepe.
                                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. At corporis nemo quo rem! Fugit nostrum aperiam similique totam, mollitia fugiat corporis suscipit eius veritatis minus. Reprehenderit et quod excepturi
                                    voluptas?
                                </p>
                            </TabPanel>
                            <TabPanel header="Organization" leftIcon="pi pi-eye mr-2">
                                <div className="col-12 text-center">
                                    <OrganizationChart value={data} nodeTemplate={nodeTemplate} />
                                </div>
                            </TabPanel>
                            <TabPanel header="Change Password" leftIcon="pi pi-key mr-2">
                                <Link href={`https://myaccount.google.com/signinoptions/password`} target="_blank" className="w-full">
                                    <Button className="bg-gray-100 hover:bg-primary-100 border-gray-700 text-teal-900 justify-content-center align-items-center w-full">
                                        <img
                                            alt="logo"
                                            src="https://fonts.gstatic.com/s/i/productlogos/googleg/v6/24px.svg
"
                                        ></img>
                                        <span> &nbsp; Change Password</span>
                                    </Button>
                                </Link>
                            </TabPanel>
                        </TabView>
                    </div>
                </div>
            </div>
        </PrivateRoute>
    );
};

export default UserPage;
