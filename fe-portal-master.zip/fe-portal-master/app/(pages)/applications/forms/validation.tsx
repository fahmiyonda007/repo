import * as Yup from 'yup';

export const ApplicationSchema = Yup.object().shape({
    applicationName: Yup.string().min(1, 'Too Short!').max(50, 'Too Long!').required('Required!'),
    applicationCode: Yup.string().min(1, 'Too Short!').max(50, 'Too Long!').required('Required!'),
    url: Yup.string().required('Required!')
});
