import { format } from 'date-fns';
import { useFormik } from 'formik';
import _ from 'lodash';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Button } from 'primereact/button';
import { Chip } from 'primereact/chip';
import { Fieldset } from 'primereact/fieldset';
import { useMountEffect } from 'primereact/hooks';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import { Message } from 'primereact/message';
import { Messages } from 'primereact/messages';
import { Toast } from 'primereact/toast';
import { classNames } from 'primereact/utils';
import React, { useContext, useRef, useState } from 'react';
import { useAuth } from '../../../../layout/context/AuthContext';
import { LayoutContext } from '../../../../layout/context/layoutcontext';
import { Application } from '../../../../types/application';
import PrivateRoute from '../../../components/PrivateRoute';
import { ApplicationService } from '../../../services/ApplicationService';
import { ApplicationSchema } from './validation';
interface metaProps {
    data?: Application;
}

const ApplicationFormPage = (props: metaProps) => {
    const toast = useRef<Toast>(null);
    const { data } = props;
    const [btnLoading, setBtnLoading] = useState(false);
    const { setMessage } = useContext(LayoutContext);
    const router = useRouter();
    const msgsAnnounce = useRef<Messages>(null);
    const { user } = useAuth();

    const legendTemplate = (
        <div className="flex align-items-center text-primary">
            <span className="pi pi-plus mr-2"></span>
            <span className="font-bold text-lg">Form {!data?.applicationName ? 'Create' : `Edit`}</span>
        </div>
    );

    const formik = useFormik({
        initialValues: {
            id: data?.id || 0,
            applicationName: data?.applicationName || '',
            applicationCode: data?.applicationCode || '',
            url: data?.url || '',
            description: data?.description || ''
        },
        enableReinitialize: true,
        validationSchema: ApplicationSchema,
        onSubmit: (form: Application) => {
            setBtnLoading(true);
            if (!data) {
                ApplicationService.addApplication(form, user?.token!)
                    .then(async (res) => {
                        const data = (await res.json()) as unknown as Application;
                        if (res.ok) {
                            setMessage({
                                sticky: false,
                                life: 5000,
                                severity: 'success',
                                content: (
                                    <React.Fragment>
                                        <i className="pi pi-check"></i>
                                        <div className="ml-2">{`Application ${data.applicationName} has been created`}</div>
                                    </React.Fragment>
                                ),
                                closable: true
                            });
                            router.push('/applications');
                        } else {
                            toast.current?.show({ severity: 'error', summary: 'Error', detail: data.message });
                        }
                    })
                    .catch((ex) => {
                        toast.current?.show({ severity: 'error', summary: 'Error', detail: 'Failed!' });
                    })
                    .finally(() => {
                        setBtnLoading(false);
                    });
            } else {
                ApplicationService.updateApplication(data?.id, form, user?.token!)
                    .then(async (res) => {
                        const data = (await res.json()) as unknown as Application;
                        if (res.ok) {
                            setMessage({
                                sticky: false,
                                life: 5000,
                                severity: 'success',
                                content: (
                                    <React.Fragment>
                                        <i className="pi pi-check"></i>
                                        <div className="ml-2">{`Application ${data.applicationName} has been updated`}</div>
                                    </React.Fragment>
                                ),
                                closable: true
                            });
                            router.push('/applications');
                        } else {
                            toast.current?.show({ severity: 'error', summary: 'Error', detail: data.message });
                        }
                    })
                    .catch((ex) => {
                        toast.current?.show({ severity: 'error', summary: 'Error', detail: 'Failed!' });
                    })
                    .finally(() => {
                        setBtnLoading(false);
                    });
            }
        }
    });
    const { errors, touched, values, handleChange, handleSubmit } = formik;

    //@ts-ignore
    const isFormFieldInvalid = (name) => !!(touched[name] && errors[name]);
    const getFormErrorMessage = (name: any) => {
        return isFormFieldInvalid(name) ? (
            <>
                {/* @ts-ignore */}
                <Message severity="error" text={errors[name]} className="justify-content-start" />
            </>
        ) : (
            ''
        );
    };

    useMountEffect(() => {
        if (data) {
            msgsAnnounce.current?.clear();
            msgsAnnounce.current?.show([
                {
                    sticky: true,
                    severity: 'warn',
                    content: (
                        <React.Fragment>
                            <ul>
                                <li>
                                    <b>PERHATIAN! &nbsp;</b>
                                    jika mengubah nama aplikasi, <b>MAKA</b> pada aplikasi tersebut harus mengubah pada&nbsp;
                                    <b>
                                        <i>konfigurasi environment.</i>
                                    </b>
                                </li>
                            </ul>
                        </React.Fragment>
                    ),
                    closable: false
                }
            ]);
        }
    });

    return (
        <PrivateRoute>
            <Messages ref={msgsAnnounce} />

            <form onSubmit={handleSubmit}>
                <div className="grid">
                    <Toast ref={toast}></Toast>
                    <div className={classNames(!data ? 'col-12' : 'col-8')}>
                        <Fieldset legend={legendTemplate}>
                            <div className="col-12">
                                <div className="p-fluid formgrid grid">
                                    <div className="field col-12 md:col-4">
                                        <label htmlFor="applicationCode">Code</label>
                                        <InputText
                                            placeholder="Auto from Name"
                                            id="applicationCode"
                                            type="text"
                                            value={values.applicationCode}
                                            readOnly
                                            onChange={handleChange}
                                            className={classNames({ 'bg-gray-100 p-invalid': isFormFieldInvalid('applicationCode') })}
                                            style={{ backgroundColor: '#F4F4F5' }}
                                        />
                                        {getFormErrorMessage('applicationCode')}
                                    </div>
                                    <div className="field col-12 md:col-4">
                                        <label htmlFor="applicationName">Name</label>
                                        <InputText
                                            id="applicationName"
                                            type="text"
                                            value={values.applicationName}
                                            onChange={(e) => {
                                                formik.setFieldValue('applicationName', e.target.value);
                                                formik.setFieldValue('applicationCode', _.kebabCase(e.target.value));
                                            }}
                                            className={classNames({ 'p-invalid': isFormFieldInvalid('applicationName') })}
                                        />
                                        {getFormErrorMessage('applicationName')}
                                    </div>
                                    <div className="field col-12 md:col-4">
                                        <label htmlFor="url">Url</label>
                                        <InputText id="url" type="text" value={values.url} onChange={handleChange} className={classNames({ 'p-invalid': isFormFieldInvalid('url') })} />
                                        {getFormErrorMessage('url')}
                                    </div>
                                    <div className="field col-12 md:col-12">
                                        <label htmlFor="description">Description</label>
                                        <InputTextarea
                                            autoResize
                                            value={values.description}
                                            onChange={(e) => {
                                                formik.setFieldValue('description', e.target.value);
                                            }}
                                            rows={5}
                                            cols={30}
                                            className={classNames({ 'p-invalid': isFormFieldInvalid('description') })}
                                        />
                                        {getFormErrorMessage('description')}
                                    </div>
                                </div>
                            </div>
                            <div className="col-12">
                                <div className="p-fluid formgrid grid flex flex-wrap gap-2">
                                    <div className="field">
                                        <Link href={'/applications'}>
                                            <Button type="button" label="Cancel" icon="pi pi-times" severity="danger" loading={btnLoading} outlined></Button>
                                        </Link>
                                    </div>

                                    <div className="field">
                                        <Button type="submit" label={data?.id ? 'Update' : 'Save'} icon="pi pi-check" severity="info" loading={btnLoading}></Button>
                                    </div>
                                </div>
                            </div>
                        </Fieldset>
                    </div>
                    <div className={classNames('col-4', !data ? 'hidden' : '')}>
                        <Fieldset legend="Information">
                            <div className="card flex flex-wrap gap-2">
                                <Chip label={`Created by: ${data?.rowInfo?.createdBy}`} />
                                <Chip label={`Created at: ${data?.rowInfo?.createdAt?.Time! ? format(new Date(data?.rowInfo?.createdAt?.Time!), 'dd-MM-yyyy') : null}`} />
                                <Chip label={`Updated by: ${data?.rowInfo?.updatedBy}`} />
                                <Chip label={`Updated at: ${data?.rowInfo?.updatedAt?.Time! ? format(new Date(data?.rowInfo?.updatedAt?.Time!), 'dd-MM-yyyy') : null}`} />
                            </div>
                        </Fieldset>
                    </div>
                </div>
            </form>
        </PrivateRoute>
    );
};

export default ApplicationFormPage;
