'use client';

import ApplicationFormPage from '../forms/form';

const ApplicationCreatePage = () => {
    return <ApplicationFormPage />;
};

export default ApplicationCreatePage;
