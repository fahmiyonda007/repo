import { ColumnProps } from 'primereact/column';
import { Application } from '../../../../types/application';
import { rowinfo } from '../../../components/rowinfo';

const columns: ColumnProps[] = [
    {
        field: 'applicationName',
        header: 'Name',
        filterField: 'applicationName',
        filterPlaceholder: 'Search by application name',
        sortable: false,
        filter: false,
        frozen: true,
        showFilterMenu: false,
        body: (rowData: Application) => {
            return <div>{rowData.applicationName}</div>;
        }
    },
    {
        field: 'applicationCode',
        header: 'slug',
        filterField: 'applicationCode',
        filterPlaceholder: 'Search by application code',
        sortable: false,
        filter: false,
        frozen: true
    },
    {
        field: 'url',
        header: 'Url',
        filterField: 'url',
        filterPlaceholder: 'Search by url',
        sortable: false,
        filter: false,
        frozen: true
    },
    {
        field: 'description',
        header: 'Description',
        filterField: 'description',
        filterPlaceholder: 'Search by description',
        sortable: false,
        filter: false,
        frozen: false
    }
];

export const applicationColumns = [...columns, ...rowinfo];
