import { debounce } from 'lodash';
import { Button } from 'primereact/button';
import { Card } from 'primereact/card';
import { ConfirmPopup, confirmPopup } from 'primereact/confirmpopup';
import { Divider } from 'primereact/divider';
import { Dropdown, DropdownChangeEvent } from 'primereact/dropdown';
import { InputSwitch, InputSwitchChangeEvent } from 'primereact/inputswitch';
import { Toast } from 'primereact/toast';
import { ChangeEvent, useEffect, useRef, useState } from 'react';
import { useAuth } from '../../../../layout/context/AuthContext';
import { Application } from '../../../../types/application';
import { Role, RolePermission } from '../../../../types/role';
import { ApplicationService } from '../../../services/ApplicationService';
import { RoleService } from '../../../services/RoleService';

interface permissionProps {
    data: Role;
}

const PermissionsComponent: React.FC<permissionProps> = ({ data }) => {
    const [switchState, setSwitchState] = useState<RolePermission | undefined>(data ? data.rolePermission : undefined);
    const [isReset, setIsReset] = useState(false);
    const [selectedApplication, setSelectedApplication] = useState<Application | null>(null);
    const [applications, setApplications] = useState<Application[]>([]);
    const toast = useRef<Toast>(null);
    const { user } = useAuth();

    useEffect(
        () => {
            if (switchState?.menu) {
                const menubyApps = data.rolePermission!.menu.filter((x) => x.applicationId == selectedApplication?.id);
                const filterSwitch = menubyApps.filter(function (obj) {
                    obj.value = obj.permission.filter((x) => x.value === true).length == 4;
                    return obj;
                });

                const isAll = filterSwitch.filter((x) => x.value === true).length == filterSwitch.length;
                const dt: RolePermission = { isAll: isAll, menu: filterSwitch };
                setSwitchState(dt);
                setIsReset(false);
            }
        },
        // eslint-disable-next-line react-hooks/exhaustive-deps
        [isReset, selectedApplication]
    );

    useEffect(() => {
        ApplicationService.getApplications({ limit: 0, skip: 0, search: '' }, user?.token!).then((res) => {
            //@ts-ignore
            const data: Application[] = res.data;
            setApplications(data);
        });
    }, [user?.token]);

    const handleSwitchItem = (e: InputSwitchChangeEvent, menu?: string, permissionId?: number) => {
        const filterSwitch = switchState!.menu.filter(function (obj) {
            if (e.target.id == 'select-all') {
                obj.value = e.target.value!;
                obj.permission?.find((x) => {
                    x.value = e.target.value!;
                });
            } else {
                if (obj.name == menu) {
                    if (!permissionId) {
                        obj.value = e.target.value!;
                        obj.permission?.find((x) => {
                            x.value = e.target.value!;
                        });
                    } else {
                        obj.permission.find((x) => {
                            if (x.id == permissionId) {
                                x.value = e.target.value!;
                            }
                        });

                        obj.value = obj.permission.filter((x) => x.value === true).length == 4;
                    }
                }
            }

            return obj;
        });
        const isAll = filterSwitch.filter((x) => x.value === true).length == filterSwitch.length;
        const dt: RolePermission = { isAll: isAll, menu: filterSwitch };

        setSwitchState(dt);
    };

    const handleReset = () => {
        RoleService.getRole({ id: data.id, token: user?.token })
            .then(async (res) => {
                const data = (await res.json()) as unknown as Role;
                if (res.ok) {
                    const filterSwitch = data
                        .rolePermission!.menu.filter((x) => x.applicationId == selectedApplication?.id)
                        .filter(function (obj) {
                            obj.value = obj.permission.filter((x) => x.value === true).length == 4;
                            return obj;
                        });

                    const isAll = filterSwitch.filter((x) => x.value === true).length == filterSwitch.length;
                    const dt: RolePermission = { isAll: isAll, menu: filterSwitch };
                    setSwitchState(dt);
                } else {
                    toast.current?.show({ severity: 'error', summary: 'Error', detail: data.message, life: 3000 });
                }
            })
            .catch((e) => {
                if (e) {
                    toast.current?.show({ severity: 'error', summary: 'Error', detail: e.message, life: 3000 });
                }
            });
    };

    const handleSave = (event: any) => {
        confirmPopup({
            target: event.currentTarget,
            message: 'Are you sure you want to proceed?',
            icon: 'pi pi-exclamation-triangle',
            accept: () => {
                RoleService.updatePermissionbyRoleId(data.id, switchState!, user?.token!).then((res: any) => {
                    if (res) {
                        setSwitchState(res);
                        toast.current?.show({ severity: 'info', summary: 'Confirmed', detail: 'You have accepted', life: 3000 });
                    }
                });
            },
            reject: () => {
                toast.current?.show({ severity: 'error', summary: 'Canceled', detail: 'You have canceled', life: 3000 });
            }
        });
    };

    const handleSearch = debounce((e: ChangeEvent) => {
        //@ts-ignore
        RoleService.getRole({ id: data.id, token: user?.token, search: e.target.value })
            .then(async (res) => {
                const data = (await res.json()) as unknown as Role;
                if (res.ok) {
                    if (!data.rolePermission?.menu) {
                        data.rolePermission!.menu = [];
                    }
                    const filterSwitch = data.rolePermission!.menu.filter(function (obj) {
                        obj.value = obj.permission.filter((x) => x.value === true).length == 4;
                        return obj;
                    });

                    const isAll = filterSwitch.filter((x) => x.value === true).length == filterSwitch.length;
                    const dt: RolePermission = { isAll: isAll, menu: filterSwitch };
                    setSwitchState(dt);
                } else {
                    toast.current?.show({ severity: 'error', summary: 'Error', detail: data.message, life: 3000 });
                }
            })
            .catch((e) => {
                if (e) {
                    toast.current?.show({ severity: 'error', summary: 'Error', detail: e.message, life: 3000 });
                }
            });
    }, 1000);

    const CardHeaderTemplate = (title: string, i: number) => (
        <div className="flex flex-wrap justify-content-between align-items-center text-primary">
            <span className="font-bold text-lg">{title}</span>
            <InputSwitch id={`select-all-${title.toLowerCase()}`} tooltip={'Select All ' + title} checked={switchState!.menu[i].value!} onChange={(e) => handleSwitchItem(e, title)} />
        </div>
    );

    return (
        <>
            <Toast ref={toast}></Toast>
            <ConfirmPopup />
            <div className="field col-12 md:col-12">
                <label htmlFor="application">Application</label>
                <Dropdown
                    value={selectedApplication}
                    onChange={(e: DropdownChangeEvent) => {
                        setSelectedApplication(e.value);
                    }}
                    options={applications}
                    optionLabel="applicationName"
                    placeholder="Select a Application"
                    virtualScrollerOptions={{ itemSize: 38 }}
                    className="w-full"
                    filter
                    showClear
                />
                <small id="username-help">Enter application first for display menus below.</small>
            </div>
            <div className="flex justify-content-between">
                <div className="flex align-items-center gap-2 text-primary">
                    <span className="font-bold text-lg">Select All</span>
                    <InputSwitch id="select-all" tooltip={'Select All'} checked={switchState ? switchState.isAll : false} onChange={(e) => handleSwitchItem(e)} />
                </div>
                <div className="flex gap-2">
                    <Button label="Reset" onClick={handleReset} severity="warning" rounded outlined></Button>
                    <Button label="Save" onClick={(e) => handleSave(e)} severity="info" rounded></Button>
                </div>
            </div>
            <Divider />
            <div className="grid">
                {/* BUG: search role has permission */}
                {/* <div className="col-12">
                    <InputText ref={searchRef} className="field w-full" placeholder="Search ..." onChange={(e) => handleSearch(e)} />
                </div> */}
                {switchState?.menu &&
                    switchState.menu.map((v, i) => {
                        return (
                            <div key={i} className="col-3">
                                <Card title={CardHeaderTemplate(v.name, i)}>
                                    <div className="card flex flex-column gap-2">
                                        <div className="flex justify-content-between">
                                            <div>View</div>
                                            <InputSwitch name="view" checked={switchState.menu[i].permission?.find((x) => x.id === 1)?.value!} onChange={(e) => handleSwitchItem(e, v.name, 1)} />
                                        </div>
                                        <div className="flex justify-content-between">
                                            <div>Create</div>
                                            <InputSwitch name="create" checked={switchState.menu[i].permission?.find((x) => x.id === 2)?.value!} onChange={(e) => handleSwitchItem(e, v.name, 2)} />
                                        </div>
                                        <div className="flex justify-content-between">
                                            <div>Update</div>
                                            <InputSwitch name="update" checked={switchState.menu[i].permission?.find((x) => x.id === 3)?.value!} onChange={(e) => handleSwitchItem(e, v.name, 3)} />
                                        </div>
                                        <div className="flex justify-content-between">
                                            <div>Delete</div>
                                            <InputSwitch name="delete" checked={switchState.menu[i].permission?.find((x) => x.id === 4)?.value!} onChange={(e) => handleSwitchItem(e, v.name, 4)} />
                                        </div>
                                    </div>
                                </Card>
                            </div>
                        );
                    })}
            </div>
        </>
    );
};

export default PermissionsComponent;
