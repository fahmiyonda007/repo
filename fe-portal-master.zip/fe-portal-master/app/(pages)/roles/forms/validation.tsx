import * as Yup from 'yup';

export const RoleSchema = Yup.object().shape({
    roleName: Yup.string().min(2, 'Too Short!').max(50, 'Too Long!').required('Required!')
});
