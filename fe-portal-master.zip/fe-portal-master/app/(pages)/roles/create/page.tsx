'use client';

import RoleFormPage from '../forms/form';

const RoleCreatePage = () => {
    return <RoleFormPage />;
};

export default RoleCreatePage;
