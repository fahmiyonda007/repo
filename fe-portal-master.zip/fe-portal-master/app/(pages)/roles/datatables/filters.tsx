import { FilterMatchMode, FilterOperator } from 'primereact/api';

export const roleFilter = {
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    roleName: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }]
    }
};
