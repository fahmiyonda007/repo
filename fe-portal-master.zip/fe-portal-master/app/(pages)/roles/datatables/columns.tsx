import { classNames } from 'primereact/utils';
import { Role } from '../../../../types/role';
import { rowinfo } from '../../../components/rowinfo';
import { ColumnProps } from 'primereact/column';

const columns: ColumnProps[] = [
    {
        field: 'roleName',
        header: 'Role Name',
        filterField: 'roleName',
        filterPlaceholder: 'Search by role name',
        sortable: false,
        filter: false,
        frozen: true,
        style: { width: '5rem' }
    },
    {
        field: 'totalPermission',
        header: 'Permissions',
        filterField: 'totalPermission',
        filterPlaceholder: 'Search by total permission',
        sortable: false,
        filter: false,
        frozen: true,
        body: (rowData: Role) => {
            const ageClassName = classNames('border-circle w-2rem h-2rem inline-flex font-bold justify-content-center align-items-center text-sm bg-teal-100 text-teal-900');
            return <div className={ageClassName}>{rowData.totalPermission}</div>;
        }
    }
];

export const roleColumns = [...columns, ...rowinfo];
