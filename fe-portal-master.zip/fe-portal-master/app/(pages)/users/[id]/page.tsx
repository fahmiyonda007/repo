'use client';

import { useRouter } from 'next/navigation';
import { Toast } from 'primereact/toast';
import { useContext, useEffect, useRef, useState } from 'react';
import { useAuth } from '../../../../layout/context/AuthContext';
import { Model } from '../../../../types/user';
import { UserService } from '../../../services/UserService';
import UserFormPage from '../forms/form';
import { LayoutContext } from '../../../../layout/context/layoutcontext';
import React from 'react';
import FormSkeleteton from '../../../components/form/FormSkeleton';

export default function Page({ params }: { params: { id: number } }) {
    const { id } = params;
    const toast = useRef<Toast>(null);
    const [data, setData] = useState<Model.User | undefined>();
    const [msg, setMsg] = useState('');
    const { user } = useAuth();
    const router = useRouter();
    const { setMessage } = useContext(LayoutContext);

    useEffect(() => {
        if (!data) {
            UserService.getUser({ id: id, token: user?.token })
                .then(async (res) => {
                    const data = (await res.json()) as unknown as Model.User;
                    if (res.ok) {
                        setData(data);
                    } else {
                        setMsg(data.message);
                    }
                })
                .catch((e) => {
                    if (e) {
                        toast.current?.show({ severity: 'error', summary: 'Error', detail: e.message, life: 3000 });
                    }
                });
        }
    }, [data, id, user?.token]);

    if (msg) {
        setMessage({
            sticky: false,
            life: 5000,
            severity: 'error',
            content: (
                <React.Fragment>
                    <i className="pi pi-times"></i>
                    <div className="ml-2">{msg}</div>
                </React.Fragment>
            ),
            closable: true
        });
        router.push('/users');
    }

    if (data) {
        return (
            <div>
                <Toast ref={toast}></Toast>
                <UserFormPage data={data} />
            </div>
        );
    }

    return <FormSkeleteton show={true} />;
}
