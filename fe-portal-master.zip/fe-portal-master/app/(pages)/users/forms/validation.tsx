import * as Yup from 'yup';

export const UserSchema = Yup.object().shape({
    firstName: Yup.string().min(2, 'Too Short!').max(50, 'Too Long!').required('Required!'),
    lastName: Yup.string().min(2, 'Too Short!').max(50, 'Too Long!').required('Required!'),
    email: Yup.string().email('Invalid email').required('Required!')
});

export const changePasswordSchema = Yup.object().shape({
    oldPassword: Yup.string().required('Please Enter your old password'),
    newPassword: Yup.string()
        .required('Please Enter your new password')
        .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{12,})/, 'Must contain 12 characters, 1 uppercase, 1 lowercase, 1 number and 1 special case character'),
    passwordConfirmation: Yup.string()
        .oneOf([Yup.ref('newPassword')], 'Passwords must match')
        .required('required')
});

export const LoginSchema = Yup.object().shape({
    username: Yup.string().required('Required!'),
    password: Yup.string().required('Required!')
});
