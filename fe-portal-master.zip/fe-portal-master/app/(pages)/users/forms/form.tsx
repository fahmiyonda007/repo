import { format } from 'date-fns';
import { useFormik } from 'formik';
import _ from 'lodash';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Button } from 'primereact/button';
import { Calendar } from 'primereact/calendar';
import { Checkbox, CheckboxChangeEvent } from 'primereact/checkbox';
import { Chip } from 'primereact/chip';
import { Dropdown } from 'primereact/dropdown';
import { Fieldset } from 'primereact/fieldset';
import { InputMask, InputMaskChangeEvent } from 'primereact/inputmask';
import { InputText } from 'primereact/inputtext';
import { Message } from 'primereact/message';
import { Toast } from 'primereact/toast';
import { classNames } from 'primereact/utils';
import { useContext, useRef, useState } from 'react';
import { useAuth } from '../../../../layout/context/AuthContext';
import { LayoutContext } from '../../../../layout/context/layoutcontext';
import { Role } from '../../../../types/role';
import { Model, User } from '../../../../types/user';
import PrivateRoute from '../../../components/PrivateRoute';
import { UserService } from '../../../services/UserService';
import { UserSchema } from './validation';
import React from 'react';

interface metaProps {
    data?: Model.User;
}

const UserFormPage = (props: metaProps) => {
    const toast = useRef<Toast>(null);
    const { data } = props;
    const [btnLoading, setBtnLoading] = useState(false);
    const { setMessage } = useContext(LayoutContext);
    const router = useRouter();
    const [roles, setRoles] = useState<Role[] | undefined>(data ? data.roles : undefined);

    const { user } = useAuth();

    const legendTemplate = (legend: string) => (
        <div className="flex align-items-center text-primary">
            <span className="pi pi-plus mr-2"></span>
            <span className="font-bold text-lg">{legend}</span>
        </div>
    );

    const handleRole = (e: CheckboxChangeEvent) => {
        const newData = roles?.filter((x) => {
            if (x.id === parseInt(e.target.id)) {
                x.checked = e.checked;
            }
            return x;
        });

        setRoles(newData);
    };

    const formik = useFormik({
        initialValues: {
            firstName: data?.firstName || '',
            lastName: data?.lastName || '',
            email: data?.email || '',
            genderJson: { label: data?.gender } || undefined,
            phone: data?.phone || '',
            birthDate: data?.birthDate! || '',
            roles: data?.roles || []
        },

        enableReinitialize: true,
        validationSchema: UserSchema,
        onSubmit: (form: User) => {
            setBtnLoading(true);
            form.gender = form.genderJson?.label;
            form.image = `https://robohash.org/${_.kebabCase(form.firstName)}`;
            form.roles = roles?.filter((x) => x.checked === true);
            if (!data) {
                UserService.addUser(form, user?.token!)
                    .then(async (res) => {
                        const data = (await res.json()) as unknown as Model.User;
                        if (res.ok) {
                            setMessage({
                                sticky: false,
                                life: 5000,
                                severity: 'success',
                                content: (
                                    <React.Fragment>
                                        <i className="pi pi-check"></i>
                                        <div className="ml-2">{`User ${data.email} has been created`}</div>
                                    </React.Fragment>
                                ),
                                closable: true
                            });
                            router.push(`/users/${data.id}`);
                        } else {
                            toast.current?.show({ severity: 'error', summary: 'Error', detail: data.message });
                        }
                    })
                    .catch((ex) => {
                        toast.current?.show({ severity: 'error', summary: 'Error', detail: 'Failed!' });
                    })
                    .finally(() => {
                        setBtnLoading(false);
                    });
            } else {
                UserService.updateUser(data?.id, form, user?.token!)
                    .then(async (res) => {
                        const data = (await res.json()) as unknown as Model.User;
                        if (res.ok) {
                            setMessage({
                                sticky: false,
                                life: 5000,
                                severity: 'success',
                                content: (
                                    <React.Fragment>
                                        <i className="pi pi-check"></i>
                                        <div className="ml-2">{`User ${data.email} has been updated`}</div>
                                    </React.Fragment>
                                ),
                                closable: true
                            });
                            router.push('/users');
                        } else {
                            toast.current?.show({ severity: 'error', summary: 'Error', detail: data.message });
                        }
                        setBtnLoading(false);
                    })
                    .catch((ex) => {
                        toast.current?.show({ severity: 'error', summary: 'Error', detail: 'Failed!' });
                    })
                    .finally(() => {
                        setBtnLoading(false);
                    });
            }
        }
    });
    const { errors, touched, values, handleChange, handleSubmit } = formik;

    //@ts-ignore
    const isFormFieldInvalid = (name) => !!(touched[name] && errors[name]);
    const getFormErrorMessage = (name: any) => {
        return isFormFieldInvalid(name) ? (
            <>
                {/* @ts-ignore */}
                <Message severity="error" text={errors[name]} className="justify-content-start" />
            </>
        ) : (
            ''
        );
    };

    return (
        <PrivateRoute>
            <form onSubmit={handleSubmit}>
                <div className="grid">
                    <Toast ref={toast}></Toast>
                    <div className={classNames(!data ? 'col-12' : 'col-8')}>
                        <Fieldset legend={legendTemplate(`Form ${!data?.email ? 'Create' : 'Edit'}`)}>
                            <div className="col-12">
                                <div className="p-fluid formgrid grid">
                                    <div className="field col-12 md:col-4">
                                        <label htmlFor="firstName">First Name</label>
                                        <InputText id="firstName" type="text" value={values.firstName} onChange={handleChange} className={classNames({ 'p-invalid': isFormFieldInvalid('firstName') })} />
                                        {getFormErrorMessage('firstName')}
                                    </div>
                                    <div className="field col-12 md:col-4">
                                        <label htmlFor="lastName">Last Name</label>
                                        <InputText id="lastName" type="text" value={values.lastName} onChange={handleChange} className={classNames({ 'p-invalid': isFormFieldInvalid('firstName') })} />
                                        {getFormErrorMessage('lastName')}
                                    </div>
                                    <div className="field col-12 md:col-4">
                                        <label htmlFor="genderJson">Gender</label>
                                        <Dropdown
                                            id="genderJson"
                                            options={[{ label: 'Male' }, { label: 'Female' }]}
                                            optionLabel="label"
                                            value={values.genderJson}
                                            onChange={handleChange}
                                            showClear
                                            className={classNames({ 'p-invalid': isFormFieldInvalid('genderJson') })}
                                        />
                                        {getFormErrorMessage('genderJson')}
                                    </div>
                                    <div className="field col-12 md:col-4">
                                        <label htmlFor="birthDate">Birth Date</label>
                                        <Calendar
                                            name="birthDate"
                                            showButtonBar
                                            value={new Date(values.birthDate!)}
                                            dateFormat='dd-mm-yy'
                                            onChange={(e) => {
                                                formik.setFieldValue('birthDate', e.target.value);
                                            }}
                                            className={classNames({ 'p-invalid': isFormFieldInvalid('birthDate') })}
                                        />
                                        {getFormErrorMessage('birthDate')}
                                    </div>
                                    <div className="field col-12 md:col-4">
                                        <label htmlFor="email">Email</label>
                                        <InputText id="email" type="email" value={values.email} onChange={handleChange} className={classNames({ 'p-invalid': isFormFieldInvalid('email') })} />
                                        {getFormErrorMessage('email')}
                                    </div>
                                    <div className="field col-12 md:col-4">
                                        <label htmlFor="phone">Phone</label>
                                        <InputMask
                                            value={values.phone}
                                            onChange={(e: InputMaskChangeEvent) => {
                                                formik.setFieldValue('phone', e.value);
                                            }}
                                            mask="999-99999999?99"
                                            placeholder="085-01234567890"
                                        />
                                        {getFormErrorMessage('phone')}
                                    </div>
                                </div>
                            </div>
                            <div className="col-12">
                                <div className="p-fluid formgrid grid flex flex-wrap gap-2">
                                    <div className="field">
                                        <Link href={'/users'}>
                                            <Button type="button" label="Cancel" icon="pi pi-times" severity="danger" loading={btnLoading} outlined></Button>
                                        </Link>
                                    </div>

                                    <div className="field">
                                        <Button type="submit" label={data?.id ? 'Update' : 'Save'} icon="pi pi-check" severity="info" loading={btnLoading}></Button>
                                    </div>
                                </div>
                            </div>
                        </Fieldset>
                    </div>
                    <div className={classNames('col-4', !data ? 'hidden' : '')}>
                        <Fieldset legend="Information">
                            <div className="card flex flex-wrap gap-2">
                                <Chip label={`Created by: ${data?.rowInfo?.createdBy}`} />
                                <Chip label={`Created at: ${data?.rowInfo?.createdAt?.Time! ? format(new Date(data?.rowInfo?.createdAt?.Time!), 'dd-MM-yyyy') : null}`} />
                                <Chip label={`Updated by: ${data?.rowInfo?.updatedBy}`} />
                                <Chip label={`Updated at: ${data?.rowInfo?.updatedAt?.Time! ? format(new Date(data?.rowInfo?.updatedAt?.Time!), 'dd-MM-yyyy') : null}`} />
                            </div>
                        </Fieldset>
                    </div>
                </div>
                <Fieldset legend={legendTemplate('Set Roles')} hidden={!data ?? true}>
                    <div className="grid">
                        <div className="flex flex-wrap justify-content-center gap-6">
                            <>
                                {roles?.map((role, i) => {
                                    return (
                                        <div key={i} className="flex align-items-center">
                                            <Checkbox id={role.id.toString()} inputId={role.roleName} name={role.roleName} value={role.roleName} checked={role.checked!} onChange={(e) => handleRole(e)} />
                                            <label htmlFor={role.roleName} className="ml-2">
                                                {role.roleName}
                                            </label>
                                        </div>
                                    );
                                })}
                            </>
                        </div>
                    </div>
                </Fieldset>
            </form>
        </PrivateRoute>
    );
};

export default UserFormPage;
