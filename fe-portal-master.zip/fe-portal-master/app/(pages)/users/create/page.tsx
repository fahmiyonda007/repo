'use client';

import UserFormPage from '../forms/form';

const UserCreatePage = () => {
    return <UserFormPage />;
};

export default UserCreatePage;
