import { ColumnProps } from 'primereact/column';
import { Model } from '../../../../types/user';
import { rowinfo } from '../../../components/rowinfo';

const columns: ColumnProps[] = [
    {
        field: 'image',
        header: '',
        frozen: true,
        body: (rowData: Model.User) => {
            return <img src={rowData.image == '' || null || undefined ? 'https://robohash.org/' + rowData.firstName : rowData.image} alt={rowData.firstName} className="w-3rem shadow-2 border-round" />;
        }
    },
    {
        field: 'email',
        header: 'Email',
        filterField: 'email',
        filterPlaceholder: 'Search by email',
        sortable: false,
        frozen: true,
        filter: false
    },
    {
        field: 'firstName',
        header: 'First Name',
        filterField: 'firstName',
        filterPlaceholder: 'Search by first name',
        sortable: false,
        filter: false,
        style: { width: '5rem' }
    },
    {
        field: 'lastName',
        header: 'Last Name',
        filterField: 'lastName',
        filterPlaceholder: 'Search by last name',
        sortable: false,
        filter: false
    },

    {
        field: 'phone',
        header: 'Phone',
        filterField: 'phone',
        filterPlaceholder: 'Search by phone',
        sortable: false,
        filter: false
    },
    {
        field: 'birthDate',
        header: 'Birth Date',
        filterField: 'birthDate',
        filterPlaceholder: 'Search by birthDate',
        sortable: false,
        filter: false
    },
    {
        field: 'gender',
        header: 'Gender',
        filterField: 'gender',
        filterPlaceholder: 'Search by gender',
        sortable: false,
        filter: false
    }
];

export const userColumns = [...columns, ...rowinfo];
