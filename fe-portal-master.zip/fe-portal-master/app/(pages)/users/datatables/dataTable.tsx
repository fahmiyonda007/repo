import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Button } from 'primereact/button';
import { Column } from 'primereact/column';
import { DataTable, DataTableFilterMeta } from 'primereact/datatable';
import { Toast } from 'primereact/toast';
import { Toolbar } from 'primereact/toolbar';
import React, { useEffect, useRef, useState } from 'react';
import { useAuth } from '../../../../layout/context/AuthContext';
import { Model } from '../../../../types/user';
import { renderHeader } from '../../../components/DataTableHeader';
import { deleteItemDialogFooter, deleteItemsDialogFooter } from '../../../components/DeleteDialogFooter';
import DeleteDialog from '../../../components/DeleteDialogTemplate';
import DeleteSelectedDialog from '../../../components/DeleteSelectedDialogTemplate';
import PaginatorTemplate from '../../../components/PaginatorTemplate';
import { UserService } from '../../../services/UserService';
import { userColumns } from './columns';
import { userFilter } from './filters';
import _ from 'lodash';
import { useMountEffect } from 'primereact/hooks';

const UserDataTable = () => {
    const [loading, setLoading] = useState(true);
    const [refresh, setRefresh] = useState(0);
    const [users, setUsers] = useState<Model.User[]>([]);
    const [data, setUser] = useState<Model.User>();
    const defaultFilters: DataTableFilterMeta = userFilter;
    const [filters, setFilters] = useState<DataTableFilterMeta>(defaultFilters);
    const [globalFilterValue, setGlobalFilterValue] = useState<string>('');
    const [selectedUsers, setSelectedUsers] = useState<Model.User[]>([]);
    const [deleteUserDialog, setDeleteUserDialog] = useState<boolean>(false);
    const [deleteUsersDialog, setDeleteUsersDialog] = useState<boolean>(false);
    const [first, setFirst] = useState<number>(0);
    const [rows, setRows] = useState<number>(5);
    const router = useRouter();
    const { user } = useAuth();
    const toast = useRef<Toast>(null);
    const columns = userColumns;

    const onGlobalFilterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        let _filters = { ...filters };

        // @ts-ignore
        _filters['global'].value = value;

        setFilters(_filters);
        setGlobalFilterValue(value);
    };

    const debouncedOnChange = _.debounce(onGlobalFilterChange, 1000);

    const confirmDeleteSelected = () => {
        setDeleteUsersDialog(true);
    };

    const editUser = (user: Model.User) => {
        router.push(`/users/${user.id}`);
    };

    const confirmDeleteUser = (user: Model.User) => {
        setUser(user);
        setDeleteUserDialog(true);
    };

    const hideDeleteUserDialog = () => {
        setDeleteUserDialog(false);
    };

    const hideDeleteUsersDialog = () => {
        setDeleteUsersDialog(false);
    };

    const deleteUser = () => {
        setDeleteUserDialog(false);
        setLoading(true);
        UserService.deleteUser(data?.id!, user?.token!).then((res) => {
            if (res) {
                onRefresh();
                toast.current?.show({ severity: 'success', summary: 'Successful', detail: 'User Deleted', life: 3000 });
            }
        });
    };

    const deleteSelectedUsers = () => {
        setDeleteUsersDialog(false);
        setSelectedUsers([]);
        onRefresh();
        //TODO: Create endpoint bulk delete with json params body
        // UserService.bulkDeleteUser(selectedUsers);
        toast.current?.show({ severity: 'success', summary: 'Successful', detail: 'Selected User has been Deleted', life: 3000 });
    };

    const actionBody = (rowData: Model.User) => {
        return (
            <React.Fragment>
                <Button icon="pi pi-pencil" rounded outlined className="mr-2" onClick={() => editUser(rowData)} />
                <Button icon="pi pi-trash" rounded outlined severity="danger" onClick={() => confirmDeleteUser(rowData)} />
            </React.Fragment>
        );
    };

    const leftToolbar = () => {
        return (
            <div className="flex flex-wrap gap-2">
                <Link href={'/users/create'}>
                    <Button loading={loading} label="New" icon="pi pi-plus" outlined></Button>
                </Link>
                {/* <Button label="Delete" icon="pi pi-trash" severity="danger" onClick={confirmDeleteSelected} disabled={!selectedUsers || !selectedUsers.length} /> */}
            </div>
        );
    };

    const rightToolbar = () => {
        return (
            <>
                <div className="flex flex-wrap gap-2">
                    <Button loading={loading} onClick={handleImportPdf} label="" icon="pi pi-file-pdf" className="p-button-help" tooltip="PDF Download" tooltipOptions={{ position: 'bottom' }} outlined />
                    <Button loading={loading} onClick={() => {}} label="" icon="pi pi-file-excel" className="p-button-success" tooltip="Excel Download" tooltipOptions={{ position: 'bottom' }} outlined />
                </div>
            </>
        );
    };

    const handleImportPdf = () => {
        setLoading(true);
        UserService.getUsers({ limit: 0, skip: 0, search: '' }, user?.token!)
            .then((data) => {
                const generatePDF = () => {
                    const pdf = new jsPDF();

                    autoTable(pdf, {
                        head: [['First Name', 'Last Name', 'Email', 'Phone', 'Gender']],
                        //@ts-ignore
                        body: data.users.map((x) => [x.firstName, x.lastName, x.email, x.phone, x.gender]),
                        tableWidth: 'auto',
                        theme: 'grid'
                    });

                    pdf.save(`users.pdf`);
                };

                generatePDF();
            })
            .catch((res) => {
                if (res) {
                    toast.current?.show({ severity: 'error', summary: 'error', detail: 'Failed!', life: 3000 });
                }
            })
            .finally(() => {
                setLoading(false);
            });
    };

    const header = renderHeader('Users', debouncedOnChange);
    const deleteUserDialogFooter = deleteItemDialogFooter(hideDeleteUserDialog, deleteUser);
    const deleteUsersDialogFooter = deleteItemsDialogFooter(hideDeleteUsersDialog, deleteSelectedUsers);

    const onPageChange = (event: any) => {
        setFirst(event.first);
        setRows(event.rows);
    };

    const onRefresh = () => {
        setRefresh((refresh) => refresh + 1);
    };

    useMountEffect(() => {
        //@ts-ignore
        defaultFilters.global.value = null
    });

    useEffect(() => {
        setLoading(true);
        UserService.getUsers({ limit: rows, skip: first, search: globalFilterValue }, user?.token!)
            .then((data) => {
                setUsers(data);
            })
            .catch((res) => {
                if (res) {
                    toast.current?.show({ severity: 'error', summary: 'error', detail: 'Failed!', life: 3000 });
                }
            })
            .finally(() => {
                setLoading(false);
            });
    }, [rows, first, globalFilterValue, user, refresh]);

    return (
        <>
            <Toast ref={toast}></Toast>

            <div className="card">
                <Toolbar className="mb-4" start={leftToolbar} end={rightToolbar}></Toolbar>
                <DataTable
                    value={
                        //@ts-ignore
                        users['users']
                    }
                    size="normal"
                    dataKey="id"
                    globalFilterFields={Object.keys(filters)}
                    filters={filters}
                    loading={loading}
                    header={header}
                    stripedRows
                    removableSort
                    scrollable
                    resizableColumns
                    // reorderableColumns
                    columnResizeMode="expand"
                    tableStyle={{ minWidth: '50rem' }}
                    selection={selectedUsers}
                    selectionMode={'checkbox'}
                    onSelectionChange={(e) => {
                        if (Array.isArray(e.value)) {
                            setSelectedUsers(e.value);
                        }
                    }}
                >
                    {/* <Column selectionMode="multiple" frozen headerStyle={{ width: '3rem' }}></Column> */}
                    {columns.map((col, i) => (
                        <Column key={col.field} field={col.field} header={col.header} filterPlaceholder={col.filterPlaceholder} sortable={col.sortable} filter={col.filter} body={col.body} frozen={col.frozen} />
                    ))}
                    <Column body={actionBody} exportable={false} style={{ minWidth: '12rem' }}></Column>
                </DataTable>

                <PaginatorTemplate
                    first={first}
                    rows={rows}
                    totalRecords={
                        //@ts-ignore
                        users['total']
                    }
                    onPageChange={onPageChange}
                    onRefresh={onRefresh}
                />
            </div>

            {/* delete 1 data in row */}
            <DeleteDialog deleteItemDialog={deleteUserDialog} deleteItemDialogFooter={deleteUserDialogFooter} hideDeleteItemDialog={hideDeleteUserDialog} item={data} name={data?.email} />

            {/* delete multiple data by selected rows */}
            <DeleteSelectedDialog deleteItemsDialog={deleteUsersDialog} deleteItemsDialogFooter={deleteUsersDialogFooter} hideDeleteItemsDialog={hideDeleteUsersDialog} selectedItems={selectedUsers} />
        </>
    );
};

export default UserDataTable;
