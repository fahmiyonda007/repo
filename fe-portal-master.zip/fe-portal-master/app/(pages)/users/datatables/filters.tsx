import { FilterMatchMode, FilterOperator } from 'primereact/api';

export const userFilter = {
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    firstName: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }]
    },
    lastName: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }]
    }
};
