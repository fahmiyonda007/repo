import Link from 'next/link';
import { DataView, DataViewLayoutOptions } from 'primereact/dataview';
import { Toast } from 'primereact/toast';
import { useContext, useEffect, useRef, useState } from 'react';
import { useAuth } from '../../layout/context/AuthContext';
import { LayoutContext } from '../../layout/context/layoutcontext';
import { Application } from '../../types/application';
import { ApplicationService } from '../services/ApplicationService';

export default function ApplicationList() {
    const [applications, setApplications] = useState<Application[]>([]);
    const [layout, setLayout] = useState<'list' | 'grid' | (string & Record<string, unknown>)>('grid');
    const { layoutConfig } = useContext(LayoutContext);
    const { user } = useAuth();
    const toast = useRef<Toast>(null);

    useEffect(() => {
        if (user?.token) {
            ApplicationService.getApplicationbyUser({ token: user?.token! })
                .then(async (res) => {
                    const data = (await res.json()) as unknown as Application[];
                    if (res.ok) {
                        setApplications(data);
                    } else {
                        toast.current?.show({
                            severity: 'error',
                            summary: 'error',
                            detail:
                                //@ts-ignore
                                data.message,
                            life: 3000
                        });
                    }
                })
                .catch((ex) => {
                    toast.current?.show({ severity: 'error', summary: 'error', detail: ex.message, life: 3000 });
                });
        }
    }, [user?.token]);

    const listItem = (application: Application) => {
        return (
            <Link href={application.url ? application.url : ''} target="_blank" className="col-12 text-700 hover:bg-primary-100">
                <div className="flex flex-column xl:flex-row xl:align-items-start p-4 gap-4 ">
                    <img className="w-9 sm:w-16rem xl:w-10rem block xl:block mx-auto border-round" src={`/layout/images/logo-${layoutConfig.colorScheme === 'light' ? 'dark' : 'white'}.png`} alt={application.applicationName} />
                    <div className="flex flex-column sm:flex-row justify-content-between align-items-center xl:align-items-start flex-1 gap-4">
                        <div className="flex flex-column align-items-center sm:align-items-start gap-3">
                            <div className="text-2xl font-bold text-900">{application.applicationName}</div>
                            <div className="flex align-items-center gap-3">
                                <span className="flex align-items-center gap-2">
                                    <i className="pi pi-bookmark"></i>
                                    <span className="font-semibold">{application.description}</span>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </Link>
        );
    };

    const gridItem = (application: Application) => {
        return (
            <Link href={application.url ? application.url : ''} target="_blank" className="col-12 sm:col-6 lg:col-12 xl:col-4 p-2 text-700 hover:bg-primary-100">
                <div className="p-4 border-1 surface-border surface-card border-round" style={{ height: '230px' }}>
                    <div className="flex flex-column align-items-center gap-3 py-5">
                        <img className="w-4 border-round" src={`/layout/images/logo-${layoutConfig.colorScheme === 'light' ? 'dark' : 'white'}.png`} alt={application.applicationName} />
                        <div className="text-2xl font-bold">{application.applicationName}</div>
                        <span className="font-semibold">{application.description}</span>
                    </div>
                </div>
            </Link>
        );
    };

    const itemTemplate = (application: Application, layout: string) => {
        if (!application) {
            return;
        }

        if (layout === 'list') return listItem(application);
        else if (layout === 'grid') return gridItem(application);
    };

    const header = () => {
        return (
            <div className="flex justify-content-between align-items-center">
                <span className="text-bold">Application List</span>
                {/* @ts-ignore */}
                <DataViewLayoutOptions layout={layout} onChange={(e) => setLayout(e.value)} />
            </div>
        );
    };

    return (
        <div className="card">
            <Toast ref={toast}></Toast>
            <DataView sortField="" value={applications} itemTemplate={itemTemplate} layout={layout} header={header()} />
        </div>
    );
}
