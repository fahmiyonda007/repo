import { InputText } from 'primereact/inputtext';
import { ChangeEventHandler } from 'react';

export const renderHeader = (tableName: string, onGlobalFilterChange: ChangeEventHandler<HTMLInputElement> | undefined) => {
    return (
        <div className="flex flex-wrap gap-2 align-items-center justify-content-between">
            <h4 className="m-0 text-color-secondary">{tableName}</h4>
            <span className="p-input-icon-left">
                <i className="pi pi-search" />
                <InputText id={`${tableName}-search`} onChange={onGlobalFilterChange} placeholder="Search..." />
            </span>
        </div>
    );
};
