import { AppMenuItem } from '../../types/layout';
import { Model, User } from '../../types/user';
import { apiUrl, appName } from '../constants/constants';

interface MetaPage {
    limit?: number;
    skip?: number;
    search?: string;
}

export const UserService = {
    async getUsers(prop: MetaPage, token: string) {
        const res = await fetch(`${apiUrl}users?search=${prop.search}&limit=${prop.limit}&skip=${prop.skip}`, {
            headers: {
                Authorization: `Bearer ${token}`,
                'Cache-Control': 'no-cache'
            }
        });
        const data = await res.json();
        return data as Model.User[];
    },

    async getUser({ id, token }: any) {
        const res = await fetch(`${apiUrl}users/${id}`, {
            headers: {
                Authorization: `Bearer ${token}`,
                'Cache-Control': 'no-cache'
            }
        });
        return res;
    },

    async addUser(prop: User, token: string) {
        const res = await fetch(`${apiUrl}users`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(prop)
        });

        return res;
    },

    async updateUser(id: number, prop: User, token: string) {
        const res = await fetch(`${apiUrl}users/${id}`, {
            method: 'PUT',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async deleteUser(id: number, token: string) {
        const res = await fetch(`${apiUrl}users/${id}`, {
            method: 'DELETE',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        const data = await res.json();
        return data as Model.User;
    },

    async userHasMenus(email: string, token: string) {
        const res = await fetch(`${apiUrl}users/menus`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email: email, application: appName })
        });
        return res;
    }
};
