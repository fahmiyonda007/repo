import { Permission } from '../../types/permission';
import { apiUrl } from '../constants/constants';

interface MetaPage {
    limit?: number;
    skip?: number;
    search?: string;
}

export const PermissionService = {
    async getPermissions(prop: MetaPage, token: string) {
        const res = await fetch(`${apiUrl}permissions?search=${prop.search}&limit=${prop.limit}&skip=${prop.skip}`, {
            headers: {
                Authorization: `Bearer ${token}`,
                'Cache-Control': 'no-cache'
            }
        });
        const data = await res.json();
        return data as Permission[];
    },

    async getPermission({ id, token }: any) {
        const res = await fetch(`${apiUrl}permissions/${id}`, {
            headers: {
                Authorization: `Bearer ${token}`,
                'Cache-Control': 'no-cache'
            }
        });
        return res;
    },

    async addPermission(prop: Permission, token: string) {
        const res = await fetch(`${apiUrl}permissions`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async updatePermission(id: number, prop: Permission, token: string) {
        const res = await fetch(`${apiUrl}permissions/${id}`, {
            method: 'PUT',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async deletePermission(id: number, token: string) {
        const res = await fetch(`${apiUrl}permissions/${id}`, {
            method: 'DELETE',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        const data = await res.json();
        return data as Permission;
    }
};
