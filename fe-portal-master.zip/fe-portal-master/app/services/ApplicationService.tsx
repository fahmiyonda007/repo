import { Application } from '../../types/application';
import { apiUrl } from '../constants/constants';

interface MetaPage {
    limit?: number;
    skip?: number;
    search?: string;
}

export const ApplicationService = {
    async getApplications(prop: MetaPage, token: string) {
        const res = await fetch(`${apiUrl}applications?search=${prop.search}&limit=${prop.limit}&skip=${prop.skip}`, {
            headers: {
                Authorization: `Bearer ${token}`,
                'Cache-Control': 'no-cache'
            }
        });
        const data = await res.json();
        return data as Application[];
    },

    async getApplicationbyUser({ token }: any) {
        const res = await fetch(`${apiUrl}applications/list`, {
            headers: {
                Authorization: `Bearer ${token}`,
                'Cache-Control': 'no-cache'
            }
        });
        return res;
    },

    async getApplication({ id, token }: any) {
        const res = await fetch(`${apiUrl}applications/${id}`, {
            headers: {
                Authorization: `Bearer ${token}`,
                'Cache-Control': 'no-cache'
            }
        });
        return res;
    },

    async addApplication(prop: Application, token: string) {
        const res = await fetch(`${apiUrl}applications`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async updateApplication(id: number, prop: Application, token: string) {
        const res = await fetch(`${apiUrl}applications/${id}`, {
            method: 'PUT',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async deleteApplication(id: number, token: string) {
        const res = await fetch(`${apiUrl}applications/${id}`, {
            method: 'DELETE',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        const data = await res.json();
        return data as Application;
    }
};
