import { Login, Model } from '../../types/auth';
import { User } from '../../types/user';
import { apiUrl } from '../constants/constants';

export const AuthService = {
    async login(login: Login) {
        const res = await fetch(`${apiUrl}auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(login)
        });
        const data = await res.json();
        return data as Model.Auth;
    },

    async loginGoogle(token: string) {
        const res = await fetch(`${apiUrl}auth/validate`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ access_token: token })
        });
        const data = await res.json();
        return data as User;
    }
};
