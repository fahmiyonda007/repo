import { TreeNode } from 'primereact/treenode';
import { Menu } from '../../types/menu';
import { apiUrl } from '../constants/constants';

interface MetaPage {
    limit?: number;
    skip?: number;
    search?: string;
}

export const MenuService = {
    async getMenus(prop: MetaPage, token: string) {
        const res = await fetch(`${apiUrl}menus?search=${prop.search}&limit=${prop.limit}&skip=${prop.skip}`, {
            headers: {
                Authorization: `Bearer ${token}`,
                'Cache-Control': 'no-cache'
            }
        });
        const data = await res.json();
        return data as Menu[];
    },

    async getMenu({ id, token }: any) {
        const res = await fetch(`${apiUrl}menus/${id}`, {
            headers: {
                Authorization: `Bearer ${token}`,
                'Cache-Control': 'no-cache'
            }
        });
        return res;
    },

    async addMenu(prop: Menu, token: string) {
        const res = await fetch(`${apiUrl}menus`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async updateMenu(id: number, prop: Menu, token: string) {
        const res = await fetch(`${apiUrl}menus/${id}`, {
            method: 'PUT',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async deleteMenu(id: number, token: string) {
        const res = await fetch(`${apiUrl}menus/${id}`, {
            method: 'DELETE',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        const data = await res.json();
        return data as Menu;
    },

    async getParentMenu({ level, application, token }: any) {
        const res = await fetch(`${apiUrl}menus/parent`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ level: level, application: application })
        });
        const data = await res.json();
        return data as Menu;
    },

    async getMenubyApplicationId({ applicationId, token }: any) {
        const res = await fetch(`${apiUrl}menus/order?applicationId=${applicationId}`, {
            headers: {
                Authorization: `Bearer ${token}`,
                'Cache-Control': 'no-cache'
            }
        });
        const data = await res.json();
        return data as TreeNode[];
    },

    async updateOrdering(applicationId: number, dragNode: TreeNode, dropIndex: number, dropNode: TreeNode, token: string) {
        const res = await fetch(`${apiUrl}menus/order`, {
            method: 'PUT',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                applicationId: applicationId,
                dragNode,
                dropIndex,
                dropNode
            })
        });
        return res;
    }
};
