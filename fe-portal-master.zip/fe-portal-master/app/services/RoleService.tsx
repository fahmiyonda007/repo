import { Role, RolePermission } from '../../types/role';
import { apiUrl } from '../constants/constants';

interface MetaPage {
    limit?: number;
    skip?: number;
    search?: string;
}

export const RoleService = {
    async getRoles(prop: MetaPage, token: string) {
        const res = await fetch(`${apiUrl}roles?search=${prop.search}&limit=${prop.limit}&skip=${prop.skip}`, {
            headers: {
                Authorization: `Bearer ${token}`,
                'Cache-Control': 'no-cache'
            }
        });
        const data = await res.json();
        return data as Role[];
    },

    async getRole({ id, token, search }: any) {
        const res = await fetch(`${apiUrl}roles/${id}?searchMenu=${search ? search : ''}`, {
            method: 'GET',
            headers: {
                Authorization: `Bearer ${token}`,
                'Cache-Control': 'no-cache'
            }
        });
        return res;
    },

    async addRole(prop: Role, token: string) {
        const res = await fetch(`${apiUrl}roles`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async updateRole(id: number, prop: Role, token: string) {
        const res = await fetch(`${apiUrl}roles/${id}`, {
            method: 'PUT',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async deleteRole(id: number, token: string) {
        const res = await fetch(`${apiUrl}roles/${id}`, {
            method: 'DELETE',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        const data = await res.json();
        return data as Role;
    },

    async updatePermissionbyRoleId(id: number, permissions: RolePermission, token: string) {
        const res = await fetch(`${apiUrl}roles/permissions/${id}`, {
            method: 'PUT',
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(permissions)
        });
        const data = await res.json();
        return data as Role;
    }
};
