# Changelog

## 1.0.0

-   Auth from [Google](https://google.com/)
-   RBAC Implemented
-   Remove auth dummy  

## 1.0.0-SNAPSHOT

-   Auth from [dummy json](https://dummyjson.com/)
-   Example Users module from [dummy json](https://dummyjson.com/)
-   auto exit when the app is inactive / idle
