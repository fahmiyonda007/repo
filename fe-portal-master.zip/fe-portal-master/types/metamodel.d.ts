export interface MetaModel {
    createdAt?: {
        Time: Date,
        Valid: boolean
    },
    createdBy?: string,
    updatedAt?: {
        Time: Date,
        Valid: boolean
    },
    updatedBy?: string,
    isDelete?: boolean
};

export interface JsonResponse {
    code?: number,
    message?: string,
}