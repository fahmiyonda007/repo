import { Application } from "./application";
import { JsonResponse, MetaModel } from "./metamodel";

export interface Menu extends JsonResponse {
    id: number;
    applicationId?: number;
    application?: Application;
    menuType: string;
    menuName: string;
    menuRoute: string;
    menuLevel: number;
    icon: string;
    orderId?: number;
    parentId?: number;
    parent?: {
        id: number;
        menuName: string;
    };
    rowInfo?: MetaModel;
};