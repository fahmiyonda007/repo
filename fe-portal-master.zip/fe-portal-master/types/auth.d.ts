declare namespace Model {
    type Auth = {
        token: string;
    };
}

export interface Login {
    username: string;
    password: string;
    expiresInMins?: Number;
}