import { LegacyRef } from 'react';
import AppMenu from './AppMenu';
import { useAuth } from './context/AuthContext';

interface AppSidebarProp {
    sideBarRef: LegacyRef<HTMLDivElement>;
}

const AppSidebar = (prop: AppSidebarProp) => {
    const { user } = useAuth();

    return (
        <>
            {user ? (
                <div ref={prop.sideBarRef} className="layout-sidebar">
                    <AppMenu />
                </div>
            ) : null}
        </>
    );
};

export default AppSidebar;
