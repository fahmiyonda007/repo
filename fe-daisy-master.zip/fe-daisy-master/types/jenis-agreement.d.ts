import { Menu } from "primereact/menu";
import { JsonResponse, MetaModel } from "./metamodel";

export interface JenisAgreement extends JsonResponse {
    id: number;
    name: string;
    rowInfo?: MetaModel;
};
