import { Menu } from "primereact/menu";
import { JsonResponse, MetaModel } from "./metamodel";

export interface Vendor extends JsonResponse {
    id: number;
    name: string;
    alamat: string;
    namaBank: string;
    noRekening: string;
    namaMarketing: string;
    noTelp: string;
    rowInfo?: MetaModel;
};
