import { Menu } from "primereact/menu";
import { JsonResponse, MetaModel } from "./metamodel";

export interface Pencatatan extends JsonResponse {
    id: number;
    code: string; 
    description: string; 
    rowInfo?: MetaModel;
};
