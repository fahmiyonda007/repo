import { Menu } from "primereact/menu";
import { JsonResponse, MetaModel } from "./metamodel";

export interface JenisBarang extends JsonResponse {
    id: number;
    name: string;
    rowInfo?: MetaModel;
};
