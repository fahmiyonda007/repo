import { Menu } from "primereact/menu";
import { JsonResponse, MetaModel } from "./metamodel";

export interface JenisAlert extends JsonResponse {
    id: number;
    name: string;
    rowInfo?: MetaModel;
};
