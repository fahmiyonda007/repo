import { Menu } from "primereact/menu";
import { JsonResponse, MetaModel } from "./metamodel";

export interface TypeBarang
 extends JsonResponse {
    id: number;
    name: string;
    rowInfo?: MetaModel;
};
