import { Application } from "./application";
import { JsonResponse, MetaModel } from "./metamodel";

export interface Menu extends JsonResponse {
    id: number;
    applicationId?: number;
    application?: Application;
    menuName: string;
    menuRoute: string;
    menuLevel: number;
    icon: string;
    orderId?: number;
    parentId?: number;
    parent?: {
        id: number;
        label: string;
    };
    rowInfo?: MetaModel;
};