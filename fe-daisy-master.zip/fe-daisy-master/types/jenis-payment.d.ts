import { Menu } from "primereact/menu";
import { JsonResponse, MetaModel } from "./metamodel";

export interface JenisPayment extends JsonResponse {
    id: number;
    name: string;
    rowInfo?: MetaModel;
};
