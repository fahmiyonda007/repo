import { Menu } from "primereact/menu";
import { JsonResponse, MetaModel } from "./metamodel";

export interface Alert extends JsonResponse {
    id: number;
    jenisAlert: string; 
    reminderType: string; 
    namaAlert: string; 
    tglExpired?: Date; 
    jangkaWaktu?: number; 
    keterangan: string; 
    email: string; 
    rowInfo?: MetaModel;
};
