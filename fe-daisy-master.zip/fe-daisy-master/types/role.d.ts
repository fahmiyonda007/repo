import { JsonResponse, MetaModel } from "./metamodel";

export interface Role extends JsonResponse {
    id: number;
    roleName: string;
    checked?: boolean;
    totalPermission?: number;
    rolePermission?: RolePermission;
    rowInfo?: MetaModel;
};

interface RolePermission {
    isAll: boolean;
    menu: {
        id: number;
        name: string;
        value: boolean;
        applicationId: number;
        applicationName: string;
        permission: {
            id: number;
            name: string;
            value: boolean;
        }[];
    }[];
}