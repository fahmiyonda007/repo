import Cookies from 'js-cookie';
import jwt from 'jsonwebtoken';
import { usePathname, useRouter } from 'next/navigation';
import { useMountEffect } from 'primereact/hooks';
import { Messages } from 'primereact/messages';
import { Toast, ToastMessage } from 'primereact/toast';
import { ReactNode, createContext, useContext, useRef, useState } from 'react';
import { appUrl, cookieAuthName, cookieAuthNameGoogle, expiresInMins } from '../../app/constants/constants';
import { AuthService } from '../../app/services/AuthService';
import { Login } from '../../types/auth';
import { User } from '../../types/user';

interface AuthContextProps {
    user: User | null;
    login: (data: Login) => Promise<void>;
    loginGoogle: (token: string) => Promise<void>;
    logout: (msg: ToastMessage) => void;
}

const AuthContext = createContext<AuthContextProps | undefined>(undefined);

interface AuthProviderProps {
    children: ReactNode;
}

const AuthProvider = ({ children }: AuthProviderProps) => {
    const [user, setUser] = useState<User | null>(null);
    const toast = useRef<Toast>(null);
    const msgs = useRef<Messages>(null);
    const router = useRouter();
    const pathName = usePathname();

    useMountEffect(() => {
        // Cek apakah ada data pengguna di penyimpanan lokal (misalnya, localStorage)
        const token = Cookies.get(cookieAuthName);
        const googleToken = Cookies.get(cookieAuthNameGoogle);
        if (token) {
            decodeToken(token);
        }

        if (googleToken) {
            decodeGoogle(googleToken);
        }
    });

    const login = async (data: Login) => {
        try {
            if (expiresInMins > 0) {
                data.expiresInMins = expiresInMins;
            }

            const response = await AuthService.login(data);

            if (response.token) {
                const dt = decodeToken(response.token);
                if (dt?.id) {
                    Cookies.set(cookieAuthName, response.token, { sameSite: 'Strict', secure: true, path: '/' });

                    toast.current?.show({ severity: 'success', summary: 'success', detail: 'Login Success!', life: 3000 });
                    router.push(Cookies.get('redirect-url')!);
                }
            } else {
                toast.current?.show({ severity: 'error', summary: 'error', detail: 'Login Failed!', life: 3000 });
            }
        } catch (error) {
            toast.current?.show({ severity: 'error', summary: 'error', detail: 'Login Failed!', life: 3000 });
        }
    };

    const loginGoogle = async (token: string) => {
        try {
            if (token) {
                const dt = await decodeGoogle(token);
                if (dt?.email) {
                    Cookies.set(cookieAuthNameGoogle, token, { secure: true, path: '/' });

                    toast.current?.show({ severity: 'success', summary: 'success', detail: 'Login Success!', life: 3000 });
                    router.push(Cookies.get('redirect-url')!);
                    Cookies.remove('redirect-url');
                }
            } else {
                toast.current?.show({ severity: 'error', summary: 'error', detail: 'Login Failed!', life: 3000 });
            }
        } catch (error) {}
    };

    const logout = (msg: ToastMessage) => {
        setUser(null);
        Cookies.remove(cookieAuthName);
        Cookies.remove(cookieAuthNameGoogle);
        toast.current?.show(msg);
        router.push(`${appUrl}/auth/login?redirectUrl=${appUrl + pathName}`);
    };

    const decodeGoogle = async (token: string): Promise<any> => {
        let user: User = {};
        await AuthService.loginGoogle(token).then((res) => {
            if (res.email) {
                user = {
                    id: res.id,
                    name: res.name,
                    email: res.email,
                    image: res.picture,
                    givenName: res.givenName,
                    familyName: res.familyName,
                    token,
                    emailVerified: res.emailVerified
                };
                setUser(user);
            } else {
                //@ts-ignore
                logout(res.error);
            }
        });
        return user;
    };

    const decodeToken = (token: string) => {
        try {
            const decodedToken = jwt.decode(token);

            if (typeof decodedToken === 'object' && decodedToken !== null) {
                const expires: Date = new Date(Number(decodedToken?.exp) * 1000);
                const user: User = {
                    id: decodedToken.id,
                    email: decodedToken.email,
                    gender: decodedToken.gender,
                    firstName: decodedToken.firstName,
                    lastName: decodedToken.lastName,
                    image: decodedToken.image,
                    exp: decodedToken.exp,
                    expires: expires,
                    token
                };

                setUser(user);

                return user;
            }
        } catch (error: any) {
            toast.current?.show({ severity: 'error', summary: 'error', detail: 'Login Failed!', life: 3000 });
        }
    };

    return (
        <AuthContext.Provider value={{ user, login, loginGoogle, logout }}>
            <Toast ref={toast}></Toast>
            <div className="flex justify-content-center">
                <Messages ref={msgs} />
            </div>
            {children}
        </AuthContext.Provider>
    );
};

const useAuth = () => {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth should be used in AuthProvider');
    }
    return context;
};

export { AuthProvider, useAuth };
