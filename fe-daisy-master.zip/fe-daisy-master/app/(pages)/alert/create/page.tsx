'use client';

import AlertFormPage from '../forms/form';

const AlertCreatePage = () => {
    return <AlertFormPage />;
};

export default AlertCreatePage;
