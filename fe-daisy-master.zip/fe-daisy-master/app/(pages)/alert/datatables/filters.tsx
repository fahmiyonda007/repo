import { FilterMatchMode, FilterOperator } from 'primereact/api';

export const alertFilter = {
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    namaAlert: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }]
    }
};
