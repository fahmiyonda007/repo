import { ColumnProps } from 'primereact/column';
import { rowinfo } from '../../../components/rowinfo';

const columns: ColumnProps[] = [
    {
        field: 'jenisAlert',
        header: 'Jenis Alert',
        filterField: 'jenisAlert',
        filterPlaceholder: 'Search by jenisAlert',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'reminderType',
        header: 'Reminder Type',
        filterField: 'reminderType',
        filterPlaceholder: 'Search by reminderType',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'namaAlert',
        header: 'Nama Alert',
        filterField: 'namaAlert',
        filterPlaceholder: 'Search by namaAlert',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'tglExpired',
        header: 'Tgl Expired',
        filterField: 'tglExpired',
        filterPlaceholder: 'Search by tglExpired',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'jangkaWaktu',
        header: 'Jangka Waktu',
        filterField: 'jangkaWaktu',
        filterPlaceholder: 'Search by jangkaWaktu',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'keterangan',
        header: 'Keterangan',
        filterField: 'keterangan',
        filterPlaceholder: 'Search by keterangan',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'email',
        header: 'Email',
        filterField: 'email',
        filterPlaceholder: 'Search by email',
        sortable: false,
        filter: false,
        frozen: false
    }
];

export const alertColumns = [...columns, ...rowinfo];
