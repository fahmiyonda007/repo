import * as Yup from 'yup';

export const AlertSchema = Yup.object().shape({
    jenisAlert: Yup.string().min(1, 'Too Short!').max(50, 'Too Long!').required('Required!'),
    reminderType: Yup.string().min(1, 'Too Short!').max(1000, 'Too Long!').required('Required!'),
    namaAlert: Yup.string().min(1, 'Too Short!').max(1000, 'Too Long!').required('Required!'),
    tglExpired: Yup.date().required('Required!'),
    jangkaWaktu: Yup.number().min(1, 'Too Short!').required('Required!'),
    keterangan: Yup.string().required('Required!'),
    email: Yup.string().email().required('Required!'),
});
