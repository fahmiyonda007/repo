'use client';
import PrivateRoute from '../components/PrivateRoute';
import RandomQuoteComponent from '../components/RandomQuote';

const Dashboard = () => {
    return (
        <PrivateRoute>
            <RandomQuoteComponent />
        </PrivateRoute>
    );
};

export default Dashboard;
