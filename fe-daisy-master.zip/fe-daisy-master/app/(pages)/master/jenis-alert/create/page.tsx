'use client';

import JenisAlertFormPage from '../forms/form';

const JenisAlertCreatePage = () => {
    return <JenisAlertFormPage />;
};

export default JenisAlertCreatePage;
