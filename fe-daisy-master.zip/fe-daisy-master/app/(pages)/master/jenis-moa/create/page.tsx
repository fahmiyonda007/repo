'use client';

import JenisMoaFormPage from '../forms/form';

const JenisMoaCreatePage = () => {
    return <JenisMoaFormPage />;
};

export default JenisMoaCreatePage;
