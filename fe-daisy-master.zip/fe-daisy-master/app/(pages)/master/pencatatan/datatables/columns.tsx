import { ColumnProps } from 'primereact/column';
import { rowinfo } from '../../../../components/rowinfo';

const columns: ColumnProps[] = [
    {
        field: 'code',
        header: 'Code',
        filterField: 'code',
        filterPlaceholder: 'Search by code',
        sortable: false,
        filter: false,
        frozen: false
    },
    {
        field: 'description',
        header: 'Description',
        filterField: 'description',
        filterPlaceholder: 'Search by description',
        sortable: false,
        filter: false,
        frozen: false
    }
];

export const pencatatanColumns = [...columns, ...rowinfo];
