import * as Yup from 'yup';

export const PencatatanSchema = Yup.object().shape({
    code: Yup.string().min(1, 'Too Short!').max(50, 'Too Long!').required('Required!'),
    description: Yup.string().min(1, 'Too Short!').max(1000, 'Too Long!').required('Required!'),
});
