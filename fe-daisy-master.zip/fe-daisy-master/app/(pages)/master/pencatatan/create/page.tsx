'use client';

import PencatatanFormPage from '../forms/form';

const PencatatanCreatePage = () => {
    return <PencatatanFormPage />;
};

export default PencatatanCreatePage;
