'use client';

import JenisBarangFormPage from '../forms/form';

const JenisBarangCreatePage = () => {
    return <JenisBarangFormPage />;
};

export default JenisBarangCreatePage;
