'use client';

import JenisAgreementFormPage from '../forms/form';

const JenisAgreementCreatePage = () => {
    return <JenisAgreementFormPage />;
};

export default JenisAgreementCreatePage;
