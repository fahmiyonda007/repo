import { format } from 'date-fns';
import { useFormik } from 'formik';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { Button } from 'primereact/button';
import { Chip } from 'primereact/chip';
import { Fieldset } from 'primereact/fieldset';
import { InputSwitch } from 'primereact/inputswitch';
import { InputText } from 'primereact/inputtext';
import { Message } from 'primereact/message';
import { Toast } from 'primereact/toast';
import { classNames } from 'primereact/utils';
import React, { useContext, useRef, useState } from 'react';
import { useAuth } from '../../../../../layout/context/AuthContext';
import { LayoutContext } from '../../../../../layout/context/layoutcontext';
import { JenisAgreement } from '../../../../../types/jenis-agreement';
import PrivateRoute from '../../../../components/PrivateRoute';
import { JenisAgreementService } from '../../../../services/JenisAgreementService';
import { JenisAgreementSchema } from './validation';
interface metaProps {
    data?: JenisAgreement;
}

const JenisAgreementFormPage = (props: metaProps) => {
    const toast = useRef<Toast>(null);
    const { data } = props;
    const [btnLoading, setBtnLoading] = useState(false);
    const { setMessage } = useContext(LayoutContext);
    const router = useRouter();
    const pathName = usePathname();
    const { user } = useAuth();

    const legendTemplate = (
        <div className="flex align-items-center text-primary">
            <span className="pi pi-plus mr-2"></span>
            <span className="font-bold text-lg">Form {!data?.name ? 'Create' : `Edit`}</span>
        </div>
    );

    const formik = useFormik({
        initialValues: {
            id: data?.id || 0,
            name: data?.name || ''
        },
        enableReinitialize: true,
        validationSchema: JenisAgreementSchema,
        onSubmit: (form: JenisAgreement) => {
            setBtnLoading(true);
            if (!data) {
                JenisAgreementService.addJenisAgreement(form, { token: user?.token!, requestPath: pathName })
                    .then(async (res) => {
                        const data = (await res.json()) as unknown as JenisAgreement;
                        if (res.ok) {
                            setMessage({
                                sticky: false,
                                life: 5000,
                                severity: 'success',
                                content: (
                                    <React.Fragment>
                                        <i className="pi pi-check"></i>
                                        <div className="ml-2">{`Jenis Agreement  ${data.name} has been created`}</div>
                                    </React.Fragment>
                                ),
                                closable: true
                            });
                            router.push('/master/jenis-agreement');
                        } else {
                            toast.current?.show({ severity: 'error', summary: 'Error', detail: data.message });
                        }
                    })
                    .catch((ex) => {
                        toast.current?.show({ severity: 'error', summary: 'Error', detail: 'Failed!' });
                    })
                    .finally(() => {
                        setBtnLoading(false);
                    });
            } else {
                JenisAgreementService.updateJenisAgreement(data?.id, form, { token: user?.token!, requestPath: pathName })
                    .then(async (res) => {
                        const data = (await res.json()) as unknown as JenisAgreement;
                        if (res.ok) {
                            setMessage({
                                sticky: false,
                                life: 5000,
                                severity: 'success',
                                content: (
                                    <React.Fragment>
                                        <i className="pi pi-check"></i>
                                        <div className="ml-2">{`Jenis Agreement  ${data.name} has been updated`}</div>
                                    </React.Fragment>
                                ),
                                closable: true
                            });
                            router.push('/master/jenis-agreement');
                        } else {
                            toast.current?.show({ severity: 'error', summary: 'Error', detail: data.message });
                        }
                    })
                    .catch((ex) => {
                        toast.current?.show({ severity: 'error', summary: 'Error', detail: 'Failed!' });
                    })
                    .finally(() => {
                        setBtnLoading(false);
                    });
            }
        }
    });
    const { errors, touched, values, handleChange, handleSubmit } = formik;

    //@ts-ignore
    const isFormFieldInvalid = (name) => !!(touched[name] && errors[name]);
    const getFormErrorMessage = (name: any) => {
        return isFormFieldInvalid(name) ? (
            <>
                {/* @ts-ignore */}
                <Message severity="error" text={errors[name]} className="justify-content-start" />
            </>
        ) : (
            ''
        );
    };

    return (
        <PrivateRoute>
            <form onSubmit={handleSubmit}>
                <div className="grid">
                    <Toast ref={toast}></Toast>
                    <div className={classNames(!data ? 'col-12' : 'col-8')}>
                        <Fieldset legend={legendTemplate}>
                            <div className="col-12">
                                <div className="p-fluid formgrid grid">
                                    <div className="field col-12 md:col-4">
                                        <label htmlFor="name">Name</label>
                                        <InputText
                                            id="name"
                                            type="text"
                                            value={values.name}
                                            onChange={(e) => {
                                                formik.setFieldValue('name', e.target.value);
                                            }}
                                            className={classNames({ 'p-invalid': isFormFieldInvalid('name') })}
                                        />
                                        {getFormErrorMessage('name')}
                                    </div>
                                </div>
                            </div>
                            <div className="col-12">
                                <div className="p-fluid formgrid grid flex flex-wrap gap-2">
                                    <div className="field">
                                        <Link href={'/master/jenis-agreement'}>
                                            <Button type="button" label="Cancel" icon="pi pi-times" severity="danger" loading={btnLoading} outlined></Button>
                                        </Link>
                                    </div>

                                    <div className="field">
                                        <Button type="submit" label={data?.id ? 'Update' : 'Save'} icon="pi pi-check" severity="info" loading={btnLoading}></Button>
                                    </div>
                                </div>
                            </div>
                        </Fieldset>
                    </div>
                    <div className={classNames('col-4', !data ? 'hidden' : '')}>
                        <Fieldset legend="Information">
                            <div className="card flex flex-wrap gap-2">
                                <Chip label={`Created by: ${data?.rowInfo?.createdBy}`} />
                                <Chip label={`Created at: ${data?.rowInfo?.createdAt?.Time! ? format(new Date(data?.rowInfo?.createdAt?.Time!), 'dd-MM-yyyy') : null}`} />
                                <Chip label={`Updated by: ${data?.rowInfo?.updatedBy}`} />
                                <Chip label={`Updated at: ${data?.rowInfo?.updatedAt?.Time! ? format(new Date(data?.rowInfo?.updatedAt?.Time!), 'dd-MM-yyyy') : null}`} />
                            </div>
                        </Fieldset>
                    </div>
                </div>
            </form>
        </PrivateRoute>
    );
};

export default JenisAgreementFormPage;
