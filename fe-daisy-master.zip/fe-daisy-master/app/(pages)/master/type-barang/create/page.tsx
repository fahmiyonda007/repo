'use client';

import TypeBarangFormPage from '../forms/form';

const TypeBarangCreatePage = () => {
    return <TypeBarangFormPage />;
};

export default TypeBarangCreatePage;
