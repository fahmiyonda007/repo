import { FilterMatchMode, FilterOperator } from 'primereact/api';

export const jenisPaymentFilter = {
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    name: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }]
    }
};
