import { ColumnProps } from 'primereact/column';
import { rowinfo } from '../../../../components/rowinfo';

const columns: ColumnProps[] = [
    {
        field: 'name',
        header: 'Name',
        filterField: 'name',
        filterPlaceholder: 'Search by name',
        sortable: false,
        filter: false,
        frozen: false
    }
];

export const jenisPaymentColumns = [...columns, ...rowinfo];
