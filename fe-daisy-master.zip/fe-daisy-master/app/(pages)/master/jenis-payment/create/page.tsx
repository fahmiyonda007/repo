'use client';

import JenisPaymentFormPage from '../forms/form';

const JenisPaymentCreatePage = () => {
    return <JenisPaymentFormPage />;
};

export default JenisPaymentCreatePage;
