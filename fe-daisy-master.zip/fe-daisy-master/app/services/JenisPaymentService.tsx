import { JenisPayment } from '../../types/jenis-payment';
import { JsonRequest } from '../../types/metamodel';
import { daisyApi } from '../constants/constants';

interface MetaPage {
    limit?: number;
    skip?: number;
    search?: string;
}

export const JenisPaymentService = {
    async getJenisPayments(prop: MetaPage, req: JsonRequest) {
        const res = await fetch(`${daisyApi}JenisPayment?search=${prop.search}&limit=${prop.limit}&skip=${prop.skip}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache',
                'Request-Path': req.requestPath
            }
        });
        const data = await res.json();
        return data as JenisPayment[];
    },

    async getJenisPayment({ id }: any, req: JsonRequest) {
        const res = await fetch(`${daisyApi}JenisPayment/${id}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache',
                'Request-Path': req.requestPath
            }
        });
        return res;
    },

    async addJenisPayment(prop: JenisPayment, req: JsonRequest) {
        const res = await fetch(`${daisyApi}JenisPayment`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async updateJenisPayment(id: number, prop: JenisPayment, req: JsonRequest) {
        const res = await fetch(`${daisyApi}JenisPayment/${id}`, {
            method: 'PUT',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async deleteJenisPayment(id: number, req: JsonRequest) {
        const res = await fetch(`${daisyApi}JenisPayment/${id}`, {
            method: 'DELETE',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            }
        });
        const data = await res.json();
        return data as JenisPayment;
    }
};
