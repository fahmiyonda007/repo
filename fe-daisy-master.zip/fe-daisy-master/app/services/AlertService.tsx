import { Alert } from '../../types/daisy-alert';
import { JsonRequest } from '../../types/metamodel';
import { daisyApi } from '../constants/constants';

interface MetaPage {
    limit?: number;
    skip?: number;
    search?: string;
}

export const AlertService = {
    async getAlerts(prop: MetaPage, req: JsonRequest) {
        const res = await fetch(`${daisyApi}Alert?search=${prop.search}&limit=${prop.limit}&skip=${prop.skip}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache',
                'Request-Path': req.requestPath
            }
        });
        const data = await res.json();
        return data as Alert[];
    },

    async getAlert({ id }: any, req: JsonRequest) {
        const res = await fetch(`${daisyApi}Alert/${id}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache',
                'Request-Path': req.requestPath
            }
        });
        return res;
    },

    async addAlert(prop: Alert, req: JsonRequest) {
        const res = await fetch(`${daisyApi}Alert`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async updateAlert(id: number, prop: Alert, req: JsonRequest) {
        const res = await fetch(`${daisyApi}Alert/${id}`, {
            method: 'PUT',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async deleteAlert(id: number, req: JsonRequest) {
        const res = await fetch(`${daisyApi}Alert/${id}`, {
            method: 'DELETE',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            }
        });
        const data = await res.json();
        return data as Alert;
    }
};
