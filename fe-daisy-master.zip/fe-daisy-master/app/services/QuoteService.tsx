export const QuoteService = {
    async getRandomQuote({ token }: any) {
        const res = await fetch(`https://dummyjson.com/quotes/random`, {
            headers: {
                Authorization: `Bearer ${token}`,
                'Cache-Control': 'no-cache'
            }
        });
        const data = await res.json();
        return data as Model.Quote;
    }
};
