import { JsonRequest } from '../../types/metamodel';
import { Pencatatan } from '../../types/pencatatan';
import { daisyApi } from '../constants/constants';

interface MetaPage {
    limit?: number;
    skip?: number;
    search?: string;
}

export const PencatatanService = {
    async getPencatatans(prop: MetaPage, req: JsonRequest) {
        const res = await fetch(`${daisyApi}Pencatatan?search=${prop.search}&limit=${prop.limit}&skip=${prop.skip}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache',
                'Request-Path': req.requestPath
            }
        });
        const data = await res.json();
        return data as Pencatatan[];
    },

    async getPencatatan({ id }: any, req: JsonRequest) {
        const res = await fetch(`${daisyApi}Pencatatan/${id}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache',
                'Request-Path': req.requestPath
            }
        });
        return res;
    },

    async addPencatatan(prop: Pencatatan, req: JsonRequest) {
        const res = await fetch(`${daisyApi}Pencatatan`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async updatePencatatan(id: number, prop: Pencatatan, req: JsonRequest) {
        const res = await fetch(`${daisyApi}Pencatatan/${id}`, {
            method: 'PUT',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async deletePencatatan(id: number, req: JsonRequest) {
        const res = await fetch(`${daisyApi}Pencatatan/${id}`, {
            method: 'DELETE',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            }
        });
        const data = await res.json();
        return data as Pencatatan;
    }
};
