import { JenisBarang } from '../../types/jenis-barang';
import { JsonRequest } from '../../types/metamodel';
import { daisyApi } from '../constants/constants';

interface MetaPage {
    limit?: number;
    skip?: number;
    search?: string;
}

export const JenisBarangService = {
    async getJenisBarangs(prop: MetaPage, req: JsonRequest) {
        const res = await fetch(`${daisyApi}JenisBarang?search=${prop.search}&limit=${prop.limit}&skip=${prop.skip}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache',
                'Request-Path': req.requestPath
            }
        });
        const data = await res.json();
        return data as JenisBarang[];
    },

    async getJenisBarang({ id }: any, req: JsonRequest) {
        const res = await fetch(`${daisyApi}JenisBarang/${id}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache',
                'Request-Path': req.requestPath
            }
        });
        return res;
    },

    async addJenisBarang(prop: JenisBarang, req: JsonRequest) {
        const res = await fetch(`${daisyApi}JenisBarang`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async updateJenisBarang(id: number, prop: JenisBarang, req: JsonRequest) {
        const res = await fetch(`${daisyApi}JenisBarang/${id}`, {
            method: 'PUT',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async deleteJenisBarang(id: number, req: JsonRequest) {
        const res = await fetch(`${daisyApi}JenisBarang/${id}`, {
            method: 'DELETE',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            }
        });
        const data = await res.json();
        return data as JenisBarang;
    }
};
