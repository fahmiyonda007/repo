import { JsonRequest } from '../../types/metamodel';
import { TypeBarang } from '../../types/type-barang';
import { daisyApi } from '../constants/constants';

interface MetaPage {
    limit?: number;
    skip?: number;
    search?: string;
}

export const TypeBarangService = {
    async getTypeBarangs(prop: MetaPage, req: JsonRequest) {
        const res = await fetch(`${daisyApi}TypeBarang?search=${prop.search}&limit=${prop.limit}&skip=${prop.skip}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache',
                'Request-Path': req.requestPath
            }
        });
        const data = await res.json();
        return data as TypeBarang[];
    },

    async getTypeBarang({ id }: any, req: JsonRequest) {
        const res = await fetch(`${daisyApi}TypeBarang/${id}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache',
                'Request-Path': req.requestPath
            }
        });
        return res;
    },

    async addTypeBarang(prop: TypeBarang, req: JsonRequest) {
        const res = await fetch(`${daisyApi}TypeBarang`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async updateTypeBarang(id: number, prop: TypeBarang, req: JsonRequest) {
        const res = await fetch(`${daisyApi}TypeBarang/${id}`, {
            method: 'PUT',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async deleteTypeBarang(id: number, req: JsonRequest) {
        const res = await fetch(`${daisyApi}TypeBarang/${id}`, {
            method: 'DELETE',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            }
        });
        const data = await res.json();
        return data as TypeBarang;
    }
};
