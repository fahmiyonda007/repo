import { JenisAgreement } from '../../types/jenis-agreement';
import { JsonRequest } from '../../types/metamodel';
import { daisyApi } from '../constants/constants';

interface MetaPage {
    limit?: number;
    skip?: number;
    search?: string;
}

export const JenisAgreementService = {
    async getJenisAgreements(prop: MetaPage, req: JsonRequest) {
        const res = await fetch(`${daisyApi}JenisAgreement?search=${prop.search}&limit=${prop.limit}&skip=${prop.skip}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache',
                'Request-Path': req.requestPath
            }
        });
        const data = await res.json();
        return data as JenisAgreement[];
    },

    async getJenisAgreement({ id }: any, req: JsonRequest) {
        const res = await fetch(`${daisyApi}JenisAgreement/${id}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache',
                'Request-Path': req.requestPath
            }
        });
        return res;
    },

    async addJenisAgreement(prop: JenisAgreement, req: JsonRequest) {
        const res = await fetch(`${daisyApi}JenisAgreement`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async updateJenisAgreement(id: number, prop: JenisAgreement, req: JsonRequest) {
        const res = await fetch(`${daisyApi}JenisAgreement/${id}`, {
            method: 'PUT',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async deleteJenisAgreement(id: number, req: JsonRequest) {
        const res = await fetch(`${daisyApi}JenisAgreement/${id}`, {
            method: 'DELETE',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            }
        });
        const data = await res.json();
        return data as JenisAgreement;
    }
};
