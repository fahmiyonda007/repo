import { JsonRequest } from '../../types/metamodel';
import { Vendor } from '../../types/vendor';
import { daisyApi } from '../constants/constants';

interface MetaPage {
    limit?: number;
    skip?: number;
    search?: string;
}

export const VendorService = {
    async getVendors(prop: MetaPage, req: JsonRequest) {
        const res = await fetch(`${daisyApi}vendor?search=${prop.search}&limit=${prop.limit}&skip=${prop.skip}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache',
                'Request-Path': req.requestPath
            }
        });
        const data = await res.json();
        return data as Vendor[];
    },

    async getVendor({ id }: any, req: JsonRequest) {
        const res = await fetch(`${daisyApi}vendor/${id}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache',
                'Request-Path': req.requestPath
            }
        });
        return res;
    },

    async addVendor(prop: Vendor, req: JsonRequest) {
        const res = await fetch(`${daisyApi}vendor`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async updateVendor(id: number, prop: Vendor, req: JsonRequest) {
        const res = await fetch(`${daisyApi}vendor/${id}`, {
            method: 'PUT',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async deleteVendor(id: number, req: JsonRequest) {
        const res = await fetch(`${daisyApi}vendor/${id}`, {
            method: 'DELETE',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            }
        });
        const data = await res.json();
        return data as Vendor;
    }
};
