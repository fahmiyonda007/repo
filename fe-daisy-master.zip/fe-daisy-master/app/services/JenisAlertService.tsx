import { JenisAlert } from '../../types/jenis-alert';
import { JsonRequest } from '../../types/metamodel';
import { daisyApi } from '../constants/constants';

interface MetaPage {
    limit?: number;
    skip?: number;
    search?: string;
}

export const JenisAlertService = {
    async getJenisAlerts(prop: MetaPage, req: JsonRequest) {
        const res = await fetch(`${daisyApi}JenisAlert?search=${prop.search}&limit=${prop.limit}&skip=${prop.skip}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache',
                'Request-Path': req.requestPath
            }
        });
        const data = await res.json();
        return data as JenisAlert[];
    },

    async getJenisAlert({ id }: any, req: JsonRequest) {
        const res = await fetch(`${daisyApi}JenisAlert/${id}`, {
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Cache-Control': 'no-cache',
                'Request-Path': req.requestPath
            }
        });
        return res;
    },

    async addJenisAlert(prop: JenisAlert, req: JsonRequest) {
        const res = await fetch(`${daisyApi}JenisAlert`, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async updateJenisAlert(id: number, prop: JenisAlert, req: JsonRequest) {
        const res = await fetch(`${daisyApi}JenisAlert/${id}`, {
            method: 'PUT',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            },
            body: JSON.stringify(prop)
        });
        return res;
    },

    async deleteJenisAlert(id: number, req: JsonRequest) {
        const res = await fetch(`${daisyApi}JenisAlert/${id}`, {
            method: 'DELETE',
            headers: {
                Authorization: `Bearer ${req.token}`,
                'Content-Type': 'application/json',
                'Request-Path': req.requestPath
            }
        });
        const data = await res.json();
        return data as JenisAlert;
    }
};
