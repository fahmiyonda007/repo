import { usePathname, useRouter } from 'next/navigation';
import React, { useEffect } from 'react';
import { useIdleTimer } from 'react-idle-timer';
import { useAuth } from '../../layout/context/AuthContext';
import { appLifetime, appThrottle, appUrl } from '../constants/constants';

interface metaProps {
    children: React.ReactNode;
}

const PrivateRoute = (props: metaProps) => {
    const router = useRouter();
    const { user, logout } = useAuth();
    const pathName = usePathname();

    const onIdle = () => {
        logout({ severity: 'warn', summary: 'Warning', detail: 'Expired session. Please re-login', life: 10000 });
    };

    useIdleTimer({
        onIdle,
        timeout: appLifetime,
        throttle: appThrottle
    });

    useEffect(() => {
        if (!user?.email) {
            router.push(`${appUrl}/auth/login?redirectUrl=${appUrl + pathName}`);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [router, user]);

    return <>{user ? props.children : null}</>;
};

export default PrivateRoute;
