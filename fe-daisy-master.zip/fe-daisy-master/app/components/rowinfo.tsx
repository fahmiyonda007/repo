import { format } from 'date-fns';
import { ColumnProps } from 'primereact/column';

export const rowinfo: ColumnProps[] = [
    {
        field: 'rowInfo.createdAt.Time',
        header: 'Created At',
        filterField: 'createdAt',
        filterPlaceholder: 'Search by created at',
        sortable: false,
        filter: false,
        body: (rowData: any) => {
            return <div>{format(new Date(rowData.rowInfo?.createdAt?.Time!), 'dd-MM-yyyy HH:mm')}</div>;
        }
    },
    {
        field: 'rowInfo.createdBy',
        header: 'Created By',
        filterField: 'createdBy',
        filterPlaceholder: 'Search by created by',
        sortable: false,
        filter: false
    },
    {
        field: 'rowInfo.updatedAt.Time',
        header: 'Update At',
        filterField: 'updatedAt',
        filterPlaceholder: 'Search by updated at',
        sortable: false,
        filter: false,
        body: (rowData: any) => {
            return <div>{format(new Date(rowData.rowInfo?.updatedAt?.Time!), 'dd-MM-yyyy HH:mm')}</div>;
        }
    },
    {
        field: 'rowInfo.updatedBy',
        header: 'Updated By',
        filterField: 'updatedBy',
        filterPlaceholder: 'Search by updated by',
        sortable: false,
        filter: false
    }
];
